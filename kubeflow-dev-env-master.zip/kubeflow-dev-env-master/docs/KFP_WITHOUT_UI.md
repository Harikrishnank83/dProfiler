# Working with Kubeflow Pipelines Without UI

**Guide for API-First Development**

This guide explains how to build, deploy, monitor, and debug Kubeflow Pipelines without relying on the UI. Perfect for automation, CI/CD, and programmatic workflows.

---

## Table of Contents

1. [Overview](#overview)
2. [Can You Work Without the UI?](#can-you-work-without-the-ui)
3. [Installation (API-Only Mode)](#installation-api-only-mode)
4. [Building Pipelines](#building-pipelines)
5. [Deploying Pipelines](#deploying-pipelines)
6. [Monitoring Runs](#monitoring-runs)
7. [Debugging](#debugging)
8. [Advanced Topics](#advanced-topics)

---

## Overview

### What is KFP UI?

The Kubeflow Pipelines UI (`ml-pipeline-ui`) is a web interface that provides:
- Visual pipeline editor
- Run monitoring dashboard
- Artifact visualization
- Experiment management
- Graph visualization

### What is KFP Backend?

The KFP backend consists of:
- **API Server** (`ml-pipeline`) - REST API for all operations
- **Persistence Agent** - Saves run state to database
- **Scheduled Workflow** - Handles recurring runs
- **Viewer CRD** - Handles artifact visualization
- **MySQL** - Stores metadata
- **MinIO** - Stores artifacts

**Key Point:** The backend is what actually runs your pipelines. The UI is just a client that calls the API.

---

## Can You Work Without the UI?

### YES! ✅ Absolutely!

The UI is **completely optional**. You can:

✅ **Build** pipelines using Python SDK  
✅ **Compile** pipelines to YAML  
✅ **Deploy** pipelines via KFP SDK or kubectl  
✅ **Monitor** runs via kubectl, SDK, or logs  
✅ **Debug** using pod logs and Kubernetes tools  
✅ **Retrieve** artifacts from MinIO  
✅ **Manage** experiments programmatically  

### When to Use API-Only Mode

**Good for:**
- CI/CD pipelines
- Automated workflows
- Production deployments
- Serverless environments
- Resource-constrained systems
- Security-sensitive environments
- Script-based workflows

**UI is better for:**
- Visual pipeline development
- Interactive exploration
- Quick debugging
- Team demonstrations
- Learning KFP concepts

---

## Installation (API-Only Mode)

### Option 1: Wizard (Recommended)

```bash
./install-wizard.sh

# When prompted:
# 1. Select mode: 4 (API-Only)
# 2. Choose versions
# 3. Confirm
```

### Option 2: Traditional Install

```bash
# Standard install includes UI, but you can just not use it
./install.sh --mode minimal --k8s 1.28.5 --kfp 2.1.0
```

### Verify Installation

```bash
# Check KFP backend pods (UI pods can be ignored)
kubectl get pods -n kubeflow

# You should see:
# - ml-pipeline-*                (API server)
# - ml-pipeline-persistenceagent (saves state)
# - ml-pipeline-scheduledworkflow (recurring runs)
# - mysql-*                      (metadata storage)
# - minio-*                      (artifact storage)
# - (ml-pipeline-ui)             (optional, can ignore)
```

### Install KFP SDK

```bash
# Install the Python SDK
pip install kfp

# Or add to requirements.txt
echo "kfp>=2.0.0" >> requirements.txt
pip install -r requirements.txt
```

---

## Building Pipelines

### Basic Pipeline Structure

```python
#!/usr/bin/env python3
"""Example KFP pipeline without UI dependency."""

from kfp import dsl, compiler
from kfp.dsl import component, pipeline

@component(base_image="python:3.10-slim")
def process_data(input_path: str) -> str:
    """Process data component."""
    # Your data processing code
    return "processed_data.csv"

@component(base_image="python:3.10-slim")
def train_model(data_path: str) -> float:
    """Train model component."""
    # Your training code
    accuracy = 0.95
    return accuracy

@pipeline(
    name="Training Pipeline",
    description="ML training pipeline"
)
def training_pipeline(input_data: str = "data.csv"):
    """Main pipeline."""
    process_task = process_data(input_path=input_data)
    train_task = train_model(data_path=process_task.output)

if __name__ == "__main__":
    # Compile to YAML
    compiler.Compiler().compile(
        pipeline_func=training_pipeline,
        package_path="training_pipeline.yaml"
    )
    print("Pipeline compiled to: training_pipeline.yaml")
```

### Compile Pipeline

```bash
# Compile to YAML
python my_pipeline.py

# Or use SDK directly
python -c "
from kfp import compiler
from my_pipeline import training_pipeline

compiler.Compiler().compile(
    pipeline_func=training_pipeline,
    package_path='pipeline.yaml'
)
"
```

---

## Deploying Pipelines

### Method 1: KFP SDK (Recommended)

```python
#!/usr/bin/env python3
"""Deploy pipeline using KFP SDK."""

import kfp
from my_pipeline import training_pipeline

# Connect to KFP API server
# Note: No UI needed! This connects to the backend API
client = kfp.Client(
    host="http://localhost:8888"  # API server port, NOT UI port
)

# Create a run
run = client.create_run_from_pipeline_func(
    pipeline_func=training_pipeline,
    arguments={
        "input_data": "s3://bucket/data.csv"
    },
    run_name="my-training-run",
    experiment_name="my-experiment"
)

print(f"Run created: {run.run_id}")
print(f"Run name: {run.run_name}")
```

### Method 2: kubectl (Direct Kubernetes)

```bash
# Compile pipeline first
python my_pipeline.py

# Apply the workflow directly
kubectl apply -f training_pipeline.yaml -n kubeflow

# Or use kfp CLI
kfp pipeline upload \
  --pipeline-name "Training Pipeline" \
  training_pipeline.yaml
```

### Method 3: Automation Script

```python
#!/usr/bin/env python3
"""Automated pipeline deployment script."""

import kfp
import sys
from datetime import datetime

def deploy_pipeline(pipeline_func, params=None):
    """Deploy pipeline and return run ID."""
    
    # Connect to KFP
    client = kfp.Client(host="http://localhost:8888")
    
    # Create experiment if doesn't exist
    experiment_name = "automated-runs"
    try:
        experiment = client.get_experiment(experiment_name=experiment_name)
    except:
        experiment = client.create_experiment(name=experiment_name)
    
    # Create run
    run_name = f"run-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    run = client.create_run_from_pipeline_func(
        pipeline_func=pipeline_func,
        arguments=params or {},
        run_name=run_name,
        experiment_name=experiment_name
    )
    
    return run.run_id, run_name

if __name__ == "__main__":
    from my_pipeline import training_pipeline
    
    run_id, run_name = deploy_pipeline(
        training_pipeline,
        params={"input_data": sys.argv[1] if len(sys.argv) > 1 else "data.csv"}
    )
    
    print(f"✅ Pipeline deployed")
    print(f"   Run ID: {run_id}")
    print(f"   Run name: {run_name}")
```

---

## Monitoring Runs

### Method 1: KFP SDK

```python
#!/usr/bin/env python3
"""Monitor pipeline runs using SDK."""

import kfp
import time

def monitor_run(run_id):
    """Monitor a pipeline run."""
    client = kfp.Client(host="http://localhost:8888")
    
    while True:
        # Get run details
        run = client.get_run(run_id)
        status = run.run.status
        
        print(f"Run status: {status}")
        
        if status in ["Succeeded", "Failed", "Skipped", "Error"]:
            print(f"✅ Run finished with status: {status}")
            break
        
        time.sleep(10)
    
    return status

# List all runs
client = kfp.Client(host="http://localhost:8888")
runs = client.list_runs(experiment_id="my-experiment-id")

for run in runs.runs:
    print(f"Run: {run.name} - Status: {run.status}")
```

### Method 2: kubectl (Kubernetes Native)

```bash
# Watch all workflow pods
kubectl get pods -n kubeflow -w

# Get detailed pod status
kubectl get pods -n kubeflow -l workflows.argoproj.io/workflow

# Describe a specific run
kubectl describe workflow <workflow-name> -n kubeflow

# Watch workflows in real-time
kubectl get workflows -n kubeflow -w

# Get workflow status
kubectl get workflows -n kubeflow -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.status.phase}{"\n"}{end}'
```

### Method 3: Argo CLI

```bash
# Install Argo CLI
brew install argo  # macOS
# or download from: https://github.com/argoproj/argo-workflows/releases

# List workflows
argo list -n kubeflow

# Watch a workflow
argo watch <workflow-name> -n kubeflow

# Get logs
argo logs <workflow-name> -n kubeflow

# Get workflow status
argo get <workflow-name> -n kubeflow
```

### Method 4: Custom Monitoring Script

```python
#!/usr/bin/env python3
"""Custom monitoring dashboard without UI."""

import kfp
import time
from datetime import datetime, timedelta
from tabulate import tabulate

def get_run_summary(client, hours=24):
    """Get summary of recent runs."""
    
    # Get experiments
    experiments = client.list_experiments().experiments
    
    summary = []
    for exp in experiments:
        # Get runs from last 24 hours
        runs = client.list_runs(
            experiment_id=exp.id,
            page_size=100
        ).runs or []
        
        for run in runs:
            # Filter by time
            created = datetime.fromisoformat(run.created_at.replace('Z', '+00:00'))
            if datetime.now() - created.replace(tzinfo=None) < timedelta(hours=hours):
                summary.append([
                    run.name,
                    exp.name,
                    run.status,
                    created.strftime('%Y-%m-%d %H:%M')
                ])
    
    return summary

# Usage
client = kfp.Client(host="http://localhost:8888")
summary = get_run_summary(client, hours=24)

print("\n📊 Pipeline Runs (Last 24 hours)")
print(tabulate(
    summary,
    headers=["Run Name", "Experiment", "Status", "Created"],
    tablefmt="grid"
))
```

---

## Debugging

### 1. Pod Logs

```bash
# List pods for a workflow
kubectl get pods -n kubeflow -l workflows.argoproj.io/workflow=<workflow-name>

# Get logs from a specific step
kubectl logs <pod-name> -n kubeflow

# Follow logs in real-time
kubectl logs -f <pod-name> -n kubeflow

# Get logs from all containers in a pod
kubectl logs <pod-name> -n kubeflow --all-containers=true

# Get previous container logs (if crashed)
kubectl logs <pod-name> -n kubeflow --previous
```

### 2. Workflow Events

```bash
# Get workflow events
kubectl get events -n kubeflow --field-selector involvedObject.name=<workflow-name>

# Watch events
kubectl get events -n kubeflow -w

# Get events sorted by time
kubectl get events -n kubeflow --sort-by='.lastTimestamp'
```

### 3. KFP SDK Debugging

```python
#!/usr/bin/env python3
"""Debug failed runs using SDK."""

import kfp

def debug_run(run_id):
    """Get detailed debug info for a run."""
    client = kfp.Client(host="http://localhost:8888")
    
    # Get run details
    run = client.get_run(run_id)
    
    print(f"Run ID: {run_id}")
    print(f"Status: {run.run.status}")
    print(f"Error: {run.run.error if run.run.error else 'None'}")
    
    # Get workflow manifest
    workflow = client.get_workflow(run_id)
    print(f"\nWorkflow name: {workflow['metadata']['name']}")
    print(f"Workflow status: {workflow['status']['phase']}")
    
    # List all nodes (steps) in the workflow
    nodes = workflow['status'].get('nodes', {})
    print(f"\n📋 Steps:")
    for node_id, node in nodes.items():
        print(f"  - {node['displayName']}: {node['phase']}")
        if node['phase'] == 'Failed':
            print(f"    Error: {node.get('message', 'Unknown')}")

# Usage
debug_run("my-failed-run-id")
```

### 4. Interactive Debugging

```bash
# Exec into a running pod for debugging
kubectl exec -it <pod-name> -n kubeflow -- /bin/bash

# Copy files from pod
kubectl cp kubeflow/<pod-name>:/path/to/file ./local-file

# Port forward to MinIO (to access artifacts)
kubectl port-forward svc/minio-service 9000:9000 -n kubeflow

# Access MinIO console
open http://localhost:9000
# Default credentials: minio / minio123
```

### 5. Artifact Inspection

```python
#!/usr/bin/env python3
"""Access artifacts without UI."""

import kfp
from minio import Minio

def get_artifacts(run_id):
    """Download artifacts from a run."""
    
    # Get run details
    client = kfp.Client(host="http://localhost:8888")
    run = client.get_run(run_id)
    
    # Connect to MinIO
    minio_client = Minio(
        "localhost:9000",
        access_key="minio",
        secret_key="minio123",
        secure=False
    )
    
    # List artifacts
    bucket = "mlpipeline"
    prefix = f"{run_id}/"
    
    objects = minio_client.list_objects(bucket, prefix=prefix, recursive=True)
    
    for obj in objects:
        print(f"Artifact: {obj.object_name}")
        # Download if needed
        # minio_client.fget_object(bucket, obj.object_name, "local_path")

# Usage
get_artifacts("my-run-id")
```

---

## Advanced Topics

### 1. Programmatic Experiment Management

```python
import kfp

client = kfp.Client(host="http://localhost:8888")

# Create experiment
experiment = client.create_experiment(
    name="my-experiment",
    description="Automated ML experiments"
)

# List experiments
experiments = client.list_experiments()
for exp in experiments.experiments:
    print(f"{exp.name}: {exp.id}")

# Archive experiment
client.archive_experiment(experiment_id="exp-id")
```

### 2. Recurring Runs (Scheduled)

```python
import kfp

client = kfp.Client(host="http://localhost:8888")

# Create recurring run (cron schedule)
job = client.create_recurring_run(
    experiment_id="exp-id",
    job_name="daily-training",
    pipeline_id="pipeline-id",
    cron_expression="0 0 * * *",  # Daily at midnight
    max_concurrency=1,
    enabled=True
)

# List recurring runs
jobs = client.list_recurring_runs()
for job in jobs.jobs:
    print(f"{job.name}: {job.status}")

# Disable/enable job
client.disable_job(job_id="job-id")
client.enable_job(job_id="job-id")
```

### 3. Metrics and Logging

```python
# In your component code
from kfp import dsl

@dsl.component
def train_model():
    """Component that logs metrics."""
    from kfp.dsl import Metrics
    
    # Your training code
    accuracy = 0.95
    f1_score = 0.93
    
    # Log metrics (these are stored without UI)
    metrics = Metrics()
    metrics.log_metric("accuracy", accuracy)
    metrics.log_metric("f1_score", f1_score)
    
    # Metrics are saved to MinIO automatically
```

### 4. CI/CD Integration

```yaml
# .github/workflows/deploy-pipeline.yml
name: Deploy KFP Pipeline

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install KFP SDK
        run: pip install kfp
      
      - name: Port forward to KFP API (if needed)
        run: |
          kubectl port-forward svc/ml-pipeline 8888:8888 -n kubeflow &
          sleep 5
      
      - name: Deploy pipeline
        run: |
          python deploy_pipeline.py
        env:
          KFP_HOST: http://localhost:8888
```

### 5. REST API Direct Access

```python
import requests

# Direct API calls (no SDK)
base_url = "http://localhost:8888"

# List pipelines
response = requests.get(f"{base_url}/apis/v1beta1/pipelines")
pipelines = response.json()

# Upload pipeline
files = {'uploadfile': open('pipeline.yaml', 'rb')}
data = {'name': 'My Pipeline'}
response = requests.post(
    f"{base_url}/apis/v1beta1/pipelines/upload",
    files=files,
    data=data
)

# Create run
run_data = {
    "name": "test-run",
    "pipeline_spec": {...}
}
response = requests.post(
    f"{base_url}/apis/v1beta1/runs",
    json=run_data
)
```

---

## Complete Example: End-to-End Workflow

```python
#!/usr/bin/env python3
"""
Complete example: Build, deploy, monitor, and debug pipeline without UI.
"""

import kfp
from kfp import dsl, compiler
import time
import sys

# 1. BUILD: Define pipeline
@dsl.component(base_image="python:3.10-slim")
def data_loader() -> str:
    return "data loaded"

@dsl.component(base_image="python:3.10-slim")
def trainer(data: str) -> float:
    return 0.95

@dsl.pipeline(name="Example Pipeline")
def example_pipeline():
    load_task = data_loader()
    train_task = trainer(data=load_task.output)

# 2. COMPILE: Generate YAML
def compile_pipeline():
    compiler.Compiler().compile(
        pipeline_func=example_pipeline,
        package_path="example_pipeline.yaml"
    )
    print("✅ Pipeline compiled")

# 3. DEPLOY: Submit to KFP
def deploy_pipeline():
    client = kfp.Client(host="http://localhost:8888")
    run = client.create_run_from_pipeline_func(
        pipeline_func=example_pipeline,
        run_name="example-run"
    )
    print(f"✅ Pipeline deployed: {run.run_id}")
    return run.run_id

# 4. MONITOR: Watch execution
def monitor_pipeline(run_id):
    client = kfp.Client(host="http://localhost:8888")
    
    while True:
        run = client.get_run(run_id)
        status = run.run.status
        print(f"   Status: {status}")
        
        if status in ["Succeeded", "Failed"]:
            break
        
        time.sleep(5)
    
    print(f"✅ Pipeline finished: {status}")
    return status

# 5. DEBUG: Get logs if failed
def debug_pipeline(run_id):
    client = kfp.Client(host="http://localhost:8888")
    workflow = client.get_workflow(run_id)
    
    nodes = workflow['status'].get('nodes', {})
    for node_id, node in nodes.items():
        if node['phase'] == 'Failed':
            print(f"❌ Failed step: {node['displayName']}")
            print(f"   Error: {node.get('message', 'Unknown')}")

# Main workflow
if __name__ == "__main__":
    print("🚀 Starting automated pipeline workflow\n")
    
    # Build and compile
    compile_pipeline()
    
    # Deploy
    run_id = deploy_pipeline()
    
    # Monitor
    status = monitor_pipeline(run_id)
    
    # Debug if failed
    if status == "Failed":
        debug_pipeline(run_id)
        sys.exit(1)
    
    print("\n🎉 Pipeline completed successfully!")
```

---

## Summary: UI vs API Comparison

| Task | With UI | Without UI (API) |
|------|---------|------------------|
| **Build Pipeline** | Visual editor or Python | Python SDK |
| **Deploy Pipeline** | Upload YAML or click | `client.create_run()` or kubectl |
| **Monitor Runs** | Dashboard | `client.get_run()`, kubectl, Argo CLI |
| **View Logs** | Click on step | `kubectl logs`, SDK |
| **Debug Failures** | Visual error display | `kubectl describe`, SDK |
| **Access Artifacts** | Download button | MinIO client, SDK |
| **Manage Experiments** | UI navigation | `client.create_experiment()` |
| **Schedule Runs** | UI form | `client.create_recurring_run()` |
| **View Metrics** | Graphs | MinIO, kubectl |

---

## Key Takeaways

✅ **UI is optional** - The backend API provides full functionality  
✅ **SDK is powerful** - `kfp.Client` can do everything the UI does  
✅ **kubectl works** - Standard Kubernetes tools apply  
✅ **Automation-friendly** - Perfect for CI/CD and scripts  
✅ **Production-ready** - Many organizations run KFP without UI  

---

## Next Steps

1. **Install KFP SDK**: `pip install kfp`
2. **Try the examples** in this guide
3. **Build your first API-only pipeline**
4. **Set up monitoring scripts**
5. **Integrate with your CI/CD**

---

## Resources

- **KFP SDK Documentation**: https://kubeflow-pipelines.readthedocs.io/
- **KFP API Reference**: https://www.kubeflow.org/docs/components/pipelines/v2/reference/api/
- **Argo Workflows**: https://argoproj.github.io/argo-workflows/
- **Example pipelines**: `/pipelines/` directory in this repo
- **More debugging tips**: `docs/TROUBLESHOOTING.md`

---

**You don't need a UI to be a KFP power user!** 🚀
