# Frequently Asked Questions

## Installation

### Q: How much disk space do I need?
**A:** About 5-10GB for the base installation, plus space for your data and models.

### Q: How much RAM do I need?
**A:** At least 8GB, with 16GB recommended. Docker should be allocated at least 4GB.

### Q: Does this work on Windows?
**A:** Yes, through WSL2. Install Docker Desktop with WSL2 backend, then follow Linux instructions inside WSL2.

### Q: Can I run this on a remote server?
**A:** Yes! Use SSH port forwarding: `ssh -L 8080:localhost:8080 your-server`

## Usage

### Q: How do I stop everything?
**A:** Run `make cluster-destroy` to remove the cluster, or just stop Docker.

### Q: Where are my pipeline outputs stored?
**A:** In MinIO (S3-compatible storage). Access via the UI or at localhost:9001 (login: minio/minio123).

### Q: Can I use my own data?
**A:** Yes! Put files in the `data/` directory and reference them in your components.

### Q: How do I run multiple experiments?
**A:** Create different runs of the same pipeline with different parameters. Use Experiments to group related runs.

## Development

### Q: How do I create a new component?
**A:** 
1. Copy the template: `cp -r components/component-template components/my-comp`
2. Edit `src/main.py` with your logic
3. Build: `make build-component COMPONENT=my-comp`

### Q: How do I debug a failing component?
**A:**
1. Check logs: `make logs RUN_ID=<id>`
2. Debug locally: `make debug-component COMPONENT=<name>`
3. Run the component's Python code directly

### Q: Can I use GPU?
**A:** Not by default. GPU support requires additional k3d configuration and NVIDIA drivers.

## Troubleshooting

### Q: Pipeline stuck on "Running"
**A:** Check pod status with `kubectl get pods -n kubeflow`. Look for ImagePullBackOff or CrashLoopBackOff.

### Q: "Connection refused" error
**A:** Make sure port-forward is running: `make port-forward`

### Q: Components can't find my images
**A:** Build first: `make build-all`

### Q: Out of memory errors
**A:** Increase Docker Desktop memory allocation (Settings > Resources).

### Q: Cluster won't start
**A:** Try: `make cluster-destroy && make cluster-create`

## Versions & Compatibility

### Q: Which K8s versions are supported?
**A:** 1.26, 1.27, 1.28, 1.29. See `make show-compatibility` for details.

### Q: Can I switch Kubeflow versions?
**A:** Yes! Use `make cluster-upgrade KFP=2.2.0` or `make cluster-recreate`.

### Q: Which Python version is used?
**A:** Python 3.10 in the component containers.

## Architecture

### Q: What's the difference between k3d, k3s, and k8s?
**A:** 
- **k8s** = Kubernetes (the full system)
- **k3s** = Lightweight Kubernetes (by Rancher)
- **k3d** = k3s in Docker (runs k3s as containers)

### Q: Why k3d instead of minikube?
**A:** k3d is faster, lighter, and easier to manage multiple clusters.

### Q: What's the registry for?
**A:** Stores Docker images locally. Your components are pushed there so the cluster can pull them.

## Need More Help?

- Submit an issue: [GitHub Issues](https://github.com/.../issues/new/choose)
- Check the [Troubleshooting Guide](TROUBLESHOOTING.md)
- Read the [User Guide](USER_GUIDE.md)
