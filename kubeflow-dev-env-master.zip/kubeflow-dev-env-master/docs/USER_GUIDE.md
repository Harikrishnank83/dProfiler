# User Guide for Data Scientists

This guide is for data scientists who want to use Kubeflow Pipelines without deep knowledge of Kubernetes.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Understanding the UI](#understanding-the-ui)
3. [Running Pipelines](#running-pipelines)
4. [Creating Custom Components](#creating-custom-components)
5. [Working with Data](#working-with-data)
6. [Common Tasks](#common-tasks)
7. [Troubleshooting](#troubleshooting)

## Getting Started

### What is This Tool?

This is a local development environment for running ML pipelines. Think of it as:
- A way to run your ML experiments in reproducible containers
- A visual UI to track experiments
- A platform that can scale from your laptop to the cloud

### Installation

```bash
./install.sh --mode dev
```

This command sets up everything you need. It takes about 5 minutes.

### Accessing the UI

```bash
make port-forward
```

Then open http://localhost:8080

## Understanding the UI

### Main Sections

1. **Pipelines**: View and manage pipeline definitions
2. **Experiments**: Group related pipeline runs
3. **Runs**: Individual pipeline executions
4. **Artifacts**: Data and models produced by runs

### Running a Pipeline

1. Click "Pipelines" in the left menu
2. Click on a pipeline (e.g., "GBM Training Pipeline")
3. Click "Create Run"
4. Set parameters (or use defaults)
5. Click "Start"

### Viewing Results

1. Go to "Runs"
2. Click on your run
3. See the DAG visualization
4. Click on components to see logs and outputs

## Running Pipelines

### Available Pipelines

| Pipeline | Description | Based On |
|----------|-------------|----------|
| GBM Training | Train gradient boosting models | hw1 notebook |
| Model Comparison | Compare different model types | hw1 Q2-5 |

### GBM Training Pipeline Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| dataset | breast_cancer | Dataset to use |
| model_type | gradient_boosting | Type of model |
| n_estimators | 100 | Number of trees |
| max_depth | 5 | Maximum tree depth |
| learning_rate | 0.1 | Learning rate |
| test_size | 0.2 | Test set proportion |

### Running from Command Line

```bash
# Deploy and run
make run-pipeline PIPELINE=gbm-training
```

## Creating Custom Components

### From Your Notebook

1. Copy the component template:
```bash
cp -r components/component-template components/my-component
```

2. Edit `src/main.py` with your logic:
```python
def my_processing(data, param1, param2):
    # Your code here
    return processed_data
```

3. Build and test:
```bash
make build-component COMPONENT=my-component
make test-component COMPONENT=my-component
```

### Using Your Component in a Pipeline

```python
from kfp import dsl

@dsl.pipeline(name="My Pipeline")
def my_pipeline():
    step1 = load_data_op()
    step2 = my_component_op(input=step1.output)
```

## Working with Data

### Where is My Data?

- **Input data**: Loaded from sklearn datasets or your files
- **Artifacts**: Stored in MinIO (S3-compatible storage)
- **Models**: Saved as pickle files

### Accessing Artifacts

1. Go to the Run details
2. Click on a component
3. Click "Artifacts" tab
4. Download or view

### Using Your Own Data

1. Place files in `data/` directory
2. Mount in your component
3. Reference the path in your code

## Common Tasks

### Comparing Model Performance

1. Run the Model Comparison pipeline
2. View metrics for each model type
3. Compare accuracy, F1, etc.

### Hyperparameter Tuning

1. Run multiple experiments with different parameters
2. View results in the UI
3. Compare across runs

### Saving Best Model

Models are automatically saved as artifacts. To retrieve:

1. Go to Run > Component > Artifacts
2. Download the model pickle file

## Troubleshooting

### Pipeline Stuck on "Running"

**Check pod status:**
```bash
kubectl get pods -n kubeflow
```

**View logs:**
```bash
make logs RUN_ID=<your-run-id>
```

### "Image not found" Error

**Build the component:**
```bash
make build-component COMPONENT=<name>
```

### Out of Memory

**Increase Docker resources:**
1. Open Docker Desktop
2. Go to Settings > Resources
3. Increase Memory to at least 4GB

### Need to Start Fresh

```bash
make cluster-destroy
./install.sh --mode dev
```

## Getting Help

- **Check the glossary**: [GLOSSARY.md](GLOSSARY.md) for K8s terminology
- **FAQ**: [FAQ.md](FAQ.md) for common questions
- **Submit an issue**: Use the Pipeline Issue template
