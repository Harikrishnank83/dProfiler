# Documentation

Welcome to the Kubeflow Development Environment documentation!

## Quick Links

| Document | Description | Audience |
|----------|-------------|----------|
| [QUICKSTART.md](QUICKSTART.md) | 5-minute setup guide | Everyone |
| [USER_GUIDE.md](USER_GUIDE.md) | Using the platform | Data Scientists |
| [GLOSSARY.md](GLOSSARY.md) | K8s terminology | Beginners |
| [FAQ.md](FAQ.md) | Common questions | Everyone |
| [TROUBLESHOOTING.md](TROUBLESHOOTING.md) | Fixing issues | Everyone |

## For Data Scientists

Start here:
1. [5-Minute Quickstart](QUICKSTART.md) - Get running fast
2. [User Guide](USER_GUIDE.md) - Learn to use the platform
3. [Glossary](GLOSSARY.md) - Understand the terminology

## For Developers

1. [Developer Guide](DEVELOPER_GUIDE.md) - Contributing code
2. [Architecture](ARCHITECTURE.md) - System design
3. [Testing](TESTING.md) - Running tests

## For Administrators

1. [Setup Guide](SETUP.md) - Detailed installation
2. [Version Management](VERSION_MANAGEMENT.md) - Managing versions
3. [Admin Guide](ADMIN_GUIDE.md) - Operations

## Tutorials

- [First Pipeline](tutorials/01-first-pipeline.md)
- [Custom Component](tutorials/02-custom-component.md)
- [Hyperparameter Tuning](tutorials/03-hyperparameter-tuning.md)

## Getting Help

- Check [FAQ.md](FAQ.md)
- See [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
- Submit an issue on GitHub
