# Unified GBM Component Architecture

## Executive Summary

This document outlines the architecture for a **Unified GBM (Gradient Boosting Machine) Component** for Kubeflow Pipelines. The component abstracts compute backends (Ray, Dask) and ML estimators (XGBoost, LightGBM, CatBoost, Scikit-learn GBM) into a reusable, standardized interface that data scientists can use to accelerate their ML workflows.

## Design Principles

1. **Abstraction over Implementation**: Users interact with high-level APIs; compute and estimator details are hidden
2. **Plug-and-Play Estimators**: Swap estimators without changing pipeline code
3. **Scalable by Default**: Automatic scaling with Ray/Dask for large datasets
4. **Standardized I/O**: Consistent data reading/writing across formats
5. **Production-Ready**: Built-in CV, early stopping, feature selection, and evaluation

---

## Architecture Layers

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           KUBEFLOW PIPELINE LAYER                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  GBM Training Pipeline | Hyperparameter Tuning Pipeline | Inference │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
├─────────────────────────────────────────────────────────────────────────────┤
│                          UNIFIED GBM COMPONENT LAYER                        │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ UnifiedGBMComponent                                                    │ │
│  │  - fit()      - predict()     - rfe()          - tune()              │ │
│  │  - cv_score() - evaluate()    - feature_importance()                  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│                          ESTIMATOR ABSTRACTION LAYER                        │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────────┐   │
│  │   XGBoost    │ │   LightGBM   │ │   CatBoost   │ │ Sklearn GBM/HGBM │   │
│  │   Adapter    │ │   Adapter    │ │   Adapter    │ │     Adapter      │   │
│  └──────────────┘ └──────────────┘ └──────────────┘ └──────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│                           COMPUTE ABSTRACTION LAYER                         │
│  ┌─────────────────────────┐          ┌─────────────────────────┐          │
│  │      Ray Backend        │          │      Dask Backend       │          │
│  │  - RayTrain/Tune        │          │  - Dask-ML              │          │
│  │  - Distributed Training │          │  - Distributed Data     │          │
│  └─────────────────────────┘          └─────────────────────────┘          │
│  ┌─────────────────────────┐                                               │
│  │     Local Backend       │   (for development/small datasets)            │
│  └─────────────────────────┘                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                           I/O STANDARDIZATION LAYER                         │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ DataLoader                                                             │ │
│  │  - read_parquet() - read_csv() - read_delta() - read_from_warehouse() │ │
│  │  - write_parquet() - write_csv() - to_artifact()                       │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Schema & Validation                                                    │ │
│  │  - FeatureSchema - TargetSchema - DataContract - Drift Detection      │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│                              INFRASTRUCTURE LAYER                           │
│  ┌─────────────────────────────────────────────────────────────────────────┐│
│  │ Kubernetes (K3d/EKS/GKE) | Ray Operator | Dask Operator | MinIO/S3    ││
│  └─────────────────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Layer 1: I/O Standardization Layer

### Purpose
Provide a unified interface for reading and writing data, abstracting away format differences and compute backend specifics.

### Components

#### 1.1 DataLoader Class

```python
from unified_gbm.io import DataLoader

# Unified API regardless of format or backend
loader = DataLoader(compute_backend="ray")  # or "dask" or "local"

# Reading data - same API for all formats
df = loader.read(
    path="s3://bucket/data/train.parquet",
    format="parquet",  # auto-detected if not specified
    columns=["feature1", "feature2", "target"],
    filters=[("date", ">=", "2024-01-01")],
    schema=FeatureSchema  # optional validation
)

# Writing data
loader.write(
    data=df,
    path="s3://bucket/outputs/predictions.parquet",
    format="parquet",
    partition_by=["date"]
)
```

#### 1.2 Supported Formats

| Format   | Read | Write | Distributed | Notes |
|----------|------|-------|-------------|-------|
| Parquet  | ✅   | ✅    | ✅          | Recommended for large datasets |
| CSV      | ✅   | ✅    | ✅          | Header detection, type inference |
| Delta    | ✅   | ✅    | ✅          | Version history, ACID |
| JSON     | ✅   | ✅    | ⚠️          | Line-delimited for scale |
| Pickle   | ✅   | ✅    | ❌          | For model artifacts only |

#### 1.3 Schema Validation

```python
from unified_gbm.io.schema import FeatureSchema, field

class CustomerChurnSchema(FeatureSchema):
    """Schema for customer churn prediction dataset"""
    customer_id: str = field(primary_key=True)
    tenure: int = field(min_value=0, max_value=100)
    monthly_charges: float = field(min_value=0)
    total_charges: float = field(min_value=0)
    contract_type: str = field(enum=["Month-to-month", "One year", "Two year"])
    churn: int = field(target=True, enum=[0, 1])

# Validation happens automatically on read
df = loader.read("data.parquet", schema=CustomerChurnSchema)
```

---

## Layer 2: Compute Abstraction Layer

### Purpose
Abstract the complexity of distributed computing, allowing seamless switching between local, Ray, and Dask backends.

### Components

#### 2.1 ComputeBackend Interface

```python
from abc import ABC, abstractmethod

class ComputeBackend(ABC):
    """Abstract interface for compute backends"""
    
    @abstractmethod
    def initialize(self, config: ComputeConfig) -> None:
        """Initialize the compute cluster"""
        pass
    
    @abstractmethod
    def distribute_data(self, df: DataFrame) -> DistributedDataFrame:
        """Convert local data to distributed format"""
        pass
    
    @abstractmethod
    def train_distributed(
        self, 
        estimator: EstimatorAdapter,
        X: DistributedDataFrame,
        y: DistributedSeries,
        **kwargs
    ) -> TrainedModel:
        """Train model in distributed fashion"""
        pass
    
    @abstractmethod
    def hyperparameter_tune(
        self,
        estimator_class: Type[EstimatorAdapter],
        X: DistributedDataFrame,
        y: DistributedSeries,
        param_space: Dict,
        n_trials: int,
        cv: int
    ) -> TuneResult:
        """Distributed hyperparameter tuning"""
        pass
```

#### 2.2 Backend Implementations

**Ray Backend** (recommended for hyperparameter tuning):
```python
class RayBackend(ComputeBackend):
    def initialize(self, config: ComputeConfig) -> None:
        import ray
        ray.init(
            address=config.cluster_address or "auto",
            num_cpus=config.num_cpus,
            num_gpus=config.num_gpus
        )
    
    def hyperparameter_tune(self, ...):
        from ray import tune
        from ray.tune.sklearn import TuneSearchCV
        # Use Ray Tune for distributed HPO
```

**Dask Backend** (recommended for large data preprocessing):
```python
class DaskBackend(ComputeBackend):
    def initialize(self, config: ComputeConfig) -> None:
        from dask.distributed import Client
        self.client = Client(config.cluster_address or "local")
    
    def distribute_data(self, df):
        import dask.dataframe as dd
        return dd.from_pandas(df, npartitions=self.config.npartitions)
```

#### 2.3 Compute Configuration

```python
from unified_gbm.compute import ComputeConfig

# Auto-select based on data size
config = ComputeConfig.auto(data_size_gb=50)

# Or explicit configuration
config = ComputeConfig(
    backend="ray",
    cluster_address="ray://ray-head:10001",  # K8s service
    num_cpus=32,
    num_gpus=4,
    memory_per_worker="8GB"
)
```

---

## Layer 3: Estimator Abstraction Layer

### Purpose
Provide a unified interface for all GBM estimators with consistent APIs for training, prediction, and feature importance.

### Components

#### 3.1 EstimatorAdapter Interface

```python
class EstimatorAdapter(ABC):
    """Unified interface for all GBM estimators"""
    
    # Unified parameter mapping
    PARAM_MAP = {
        "n_estimators": "n_estimators",
        "learning_rate": "learning_rate",
        "max_depth": "max_depth",
        "min_samples_leaf": "min_child_weight",
        "subsample": "subsample",
        "colsample": "colsample_bytree"
    }
    
    @abstractmethod
    def fit(self, X, y, eval_set=None, early_stopping_rounds=None) -> "EstimatorAdapter":
        pass
    
    @abstractmethod
    def predict(self, X) -> np.ndarray:
        pass
    
    @abstractmethod
    def predict_proba(self, X) -> np.ndarray:
        pass
    
    @abstractmethod
    def get_feature_importance(self, importance_type="gain") -> Dict[str, float]:
        pass
    
    @abstractmethod
    def save(self, path: str) -> None:
        pass
    
    @classmethod
    @abstractmethod
    def load(cls, path: str) -> "EstimatorAdapter":
        pass
```

#### 3.2 Supported Estimators

```python
from unified_gbm.estimators import (
    XGBoostAdapter,
    LightGBMAdapter,
    CatBoostAdapter,
    SklearnGBMAdapter,
    HistGradientBoostingAdapter
)

# All estimators have the same interface
estimator = XGBoostAdapter(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=6
)

# Switch estimators without changing code
estimator = LightGBMAdapter(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=6
)
```

#### 3.3 Parameter Translation

```python
class ParameterTranslator:
    """Translate unified parameters to estimator-specific parameters"""
    
    TRANSLATIONS = {
        "xgboost": {
            "min_samples_leaf": "min_child_weight",
            "colsample": "colsample_bytree",
            "l2_regularization": "reg_lambda"
        },
        "lightgbm": {
            "min_samples_leaf": "min_child_samples",
            "colsample": "feature_fraction",
            "l2_regularization": "reg_lambda"
        },
        "catboost": {
            "learning_rate": "learning_rate",
            "max_depth": "depth",
            "l2_regularization": "l2_leaf_reg"
        }
    }
```

---

## Layer 4: Unified GBM Component Layer

### Purpose
High-level component that combines all layers into a single, easy-to-use Kubeflow component.

### Core Functionality

#### 4.1 UnifiedGBMComponent Class

```python
from unified_gbm import UnifiedGBMComponent

gbm = UnifiedGBMComponent(
    estimator="xgboost",        # or "lightgbm", "catboost", "sklearn_gbm"
    compute_backend="ray",      # or "dask", "local"
    task="classification"       # or "regression"
)
```

#### 4.2 Fit with Train/Eval Split

```python
# Automatic train/eval split with stratification
model = gbm.fit(
    data="s3://bucket/train.parquet",
    target_column="churn",
    feature_columns=["tenure", "monthly_charges", "contract_type"],
    eval_split=0.2,              # 20% for evaluation
    eval_metric="auc",           # or "logloss", "rmse", etc.
    early_stopping_rounds=50,    # Stop if no improvement
    stratify=True                # Stratified split for classification
)
```

#### 4.3 Cross-Validation

```python
# K-Fold Cross Validation
cv_results = gbm.cross_validate(
    data="s3://bucket/train.parquet",
    target_column="churn",
    cv=5,                        # 5-fold CV
    cv_strategy="stratified",    # or "kfold", "timeseries", "group"
    return_train_score=True,
    scoring=["accuracy", "roc_auc", "f1"]
)

print(cv_results)
# Output:
# {
#     "mean_test_accuracy": 0.85,
#     "std_test_accuracy": 0.02,
#     "mean_test_roc_auc": 0.92,
#     "std_test_roc_auc": 0.01,
#     ...
# }
```

#### 4.4 Recursive Feature Elimination (RFE)

```python
# Feature selection using RFE
rfe_results = gbm.rfe(
    data="s3://bucket/train.parquet",
    target_column="churn",
    n_features_to_select=10,     # Select top 10 features
    step=5,                      # Remove 5 features per iteration
    cv=3,                        # Use 3-fold CV for evaluation
    scoring="roc_auc"
)

print(rfe_results.selected_features)
# ['tenure', 'monthly_charges', 'total_charges', ...]

print(rfe_results.feature_ranking)
# {'tenure': 1, 'monthly_charges': 1, 'contract_type': 3, ...}
```

#### 4.5 Hyperparameter Tuning

```python
# Distributed hyperparameter tuning
tune_results = gbm.tune(
    data="s3://bucket/train.parquet",
    target_column="churn",
    param_space={
        "n_estimators": tune.choice([100, 200, 500]),
        "learning_rate": tune.loguniform(0.01, 0.3),
        "max_depth": tune.randint(3, 10),
        "subsample": tune.uniform(0.6, 1.0),
        "colsample": tune.uniform(0.6, 1.0)
    },
    n_trials=100,
    cv=5,
    search_algorithm="optuna",   # or "hyperopt", "grid", "random"
    early_stopping_rounds=50,
    max_concurrent_trials=10     # Distributed execution
)

print(tune_results.best_params)
print(tune_results.best_score)
print(tune_results.all_trials_df)
```

#### 4.6 Prediction

```python
# Batch prediction on new data
predictions = gbm.predict(
    model=model,                         # or model_path="s3://bucket/model.pkl"
    data="s3://bucket/test.parquet",
    output_path="s3://bucket/predictions.parquet",
    include_probabilities=True,
    batch_size=10000
)
```

#### 4.7 Model Evaluation

```python
# Comprehensive evaluation
eval_results = gbm.evaluate(
    model=model,
    data="s3://bucket/test.parquet",
    target_column="churn",
    metrics=["accuracy", "precision", "recall", "f1", "roc_auc", "confusion_matrix"],
    threshold=0.5,                # For classification
    generate_report=True
)

print(eval_results.metrics)
print(eval_results.confusion_matrix)
print(eval_results.roc_curve)
```

---

## Layer 5: Kubeflow Pipeline Layer

### Purpose
Define reusable Kubeflow pipeline templates that data scientists can customize.

### Pipeline Templates

#### 5.1 Standard Training Pipeline

```python
from kfp import dsl
from unified_gbm.pipelines import (
    load_data_op,
    feature_engineering_op,
    train_gbm_op,
    evaluate_op,
    deploy_op
)

@dsl.pipeline(
    name="GBM Training Pipeline",
    description="End-to-end GBM training with evaluation"
)
def gbm_training_pipeline(
    data_path: str,
    target_column: str,
    estimator: str = "xgboost",
    compute_backend: str = "ray",
    model_output_path: str = ""
):
    # Load and validate data
    data = load_data_op(
        path=data_path,
        format="parquet"
    )
    
    # Feature engineering
    features = feature_engineering_op(
        data=data.output,
        target_column=target_column
    )
    
    # Train model
    model = train_gbm_op(
        data=features.output,
        target_column=target_column,
        estimator=estimator,
        compute_backend=compute_backend,
        eval_split=0.2,
        early_stopping_rounds=50
    )
    
    # Evaluate
    evaluation = evaluate_op(
        model=model.output,
        test_data=features.outputs["test_data"]
    )
    
    # Conditional deployment
    with dsl.Condition(evaluation.outputs["roc_auc"] > 0.8):
        deploy_op(model=model.output, output_path=model_output_path)
```

#### 5.2 Hyperparameter Tuning Pipeline

```python
@dsl.pipeline(name="GBM Hyperparameter Tuning")
def gbm_tuning_pipeline(
    data_path: str,
    target_column: str,
    n_trials: int = 100,
    estimator: str = "xgboost"
):
    # Data loading
    data = load_data_op(path=data_path)
    
    # Hyperparameter tuning with Ray
    tune_result = tune_gbm_op(
        data=data.output,
        target_column=target_column,
        estimator=estimator,
        n_trials=n_trials,
        compute_backend="ray"
    ).set_cpu_request("4").set_memory_request("16Gi")
    
    # Train final model with best params
    final_model = train_gbm_op(
        data=data.output,
        target_column=target_column,
        params=tune_result.outputs["best_params"]
    )
```

#### 5.3 Feature Selection Pipeline

```python
@dsl.pipeline(name="Feature Selection with RFE")
def feature_selection_pipeline(
    data_path: str,
    target_column: str,
    n_features: int = 20
):
    data = load_data_op(path=data_path)
    
    rfe_result = rfe_op(
        data=data.output,
        target_column=target_column,
        n_features_to_select=n_features,
        step=5,
        cv=5
    )
    
    # Compare models with/without feature selection
    full_model = train_gbm_op(data=data.output)
    selected_model = train_gbm_op(
        data=data.output,
        feature_columns=rfe_result.outputs["selected_features"]
    )
    
    compare_op(
        models=[full_model.output, selected_model.output],
        names=["full_features", "selected_features"]
    )
```

---

## Implementation Phases

### Phase 1: Foundation (Weeks 1-2)
- [ ] I/O Layer: DataLoader with Parquet/CSV support
- [ ] Schema validation framework
- [ ] Local compute backend
- [ ] XGBoost adapter with basic fit/predict

### Phase 2: Core Components (Weeks 3-4)
- [ ] LightGBM and CatBoost adapters
- [ ] Cross-validation implementation
- [ ] Early stopping support
- [ ] Feature importance extraction

### Phase 3: Distributed Computing (Weeks 5-6)
- [ ] Ray backend integration
- [ ] Dask backend integration
- [ ] Distributed data loading
- [ ] Ray Tune hyperparameter tuning

### Phase 4: Advanced Features (Weeks 7-8)
- [ ] RFE feature selection
- [ ] Model evaluation suite
- [ ] Kubeflow component packaging
- [ ] Pipeline templates

### Phase 5: Production Readiness (Weeks 9-10)
- [ ] Documentation and examples
- [ ] CI/CD integration
- [ ] Monitoring and logging
- [ ] Performance benchmarks

---

## Directory Structure

```
unified-gbm/
├── src/
│   └── unified_gbm/
│       ├── __init__.py
│       ├── component.py              # UnifiedGBMComponent
│       ├── io/
│       │   ├── __init__.py
│       │   ├── loader.py             # DataLoader
│       │   ├── schema.py             # FeatureSchema
│       │   └── formats/
│       │       ├── parquet.py
│       │       ├── csv.py
│       │       └── delta.py
│       ├── compute/
│       │   ├── __init__.py
│       │   ├── base.py               # ComputeBackend ABC
│       │   ├── local.py
│       │   ├── ray_backend.py
│       │   └── dask_backend.py
│       ├── estimators/
│       │   ├── __init__.py
│       │   ├── base.py               # EstimatorAdapter ABC
│       │   ├── xgboost.py
│       │   ├── lightgbm.py
│       │   ├── catboost.py
│       │   └── sklearn.py
│       ├── training/
│       │   ├── __init__.py
│       │   ├── trainer.py
│       │   ├── cv.py                 # Cross-validation
│       │   ├── early_stopping.py
│       │   └── rfe.py                # Feature elimination
│       ├── tuning/
│       │   ├── __init__.py
│       │   ├── tuner.py
│       │   └── search_spaces.py
│       ├── evaluation/
│       │   ├── __init__.py
│       │   ├── metrics.py
│       │   └── reports.py
│       └── pipelines/
│           ├── __init__.py
│           ├── components/           # KFP component definitions
│           │   ├── load_data.py
│           │   ├── train.py
│           │   ├── tune.py
│           │   └── evaluate.py
│           └── templates/            # Pipeline templates
│               ├── training.py
│               ├── tuning.py
│               └── feature_selection.py
├── tests/
├── examples/
│   ├── notebooks/
│   └── pipelines/
├── docs/
├── Dockerfile
├── pyproject.toml
└── README.md
```

---

## API Quick Reference

```python
from unified_gbm import UnifiedGBMComponent
from unified_gbm.io import DataLoader
from unified_gbm.compute import ComputeConfig

# Initialize
gbm = UnifiedGBMComponent(
    estimator="xgboost",      # xgboost | lightgbm | catboost | sklearn_gbm
    compute_backend="ray",    # ray | dask | local
    task="classification"     # classification | regression
)

# Core Operations
gbm.fit(data, target_column, eval_split=0.2, early_stopping_rounds=50)
gbm.predict(model, data, output_path)
gbm.cross_validate(data, target_column, cv=5, scoring=["roc_auc"])
gbm.rfe(data, target_column, n_features_to_select=10)
gbm.tune(data, target_column, param_space, n_trials=100)
gbm.evaluate(model, data, target_column, metrics=["accuracy", "roc_auc"])

# I/O Operations
loader = DataLoader(compute_backend="ray")
df = loader.read("s3://bucket/data.parquet", schema=MySchema)
loader.write(df, "s3://bucket/output.parquet", partition_by=["date"])
```

---

## Success Metrics

| Metric | Target |
|--------|--------|
| Time to first pipeline run | < 15 minutes for new users |
| Estimator switching | Zero code changes |
| Scale to 100GB dataset | < 2 hours training time |
| Cross-validation speedup (Ray) | 5-10x vs local |
| Hyperparameter trials | 1000+ trials/hour |

---

## Next Steps

1. **Review and approve architecture** with ML Platform team
2. **Prototype I/O Layer** with Parquet support
3. **Implement XGBoost adapter** as reference implementation
4. **Build local compute backend** for testing
5. **Create Kubeflow component** wrapper
6. **Iterate based on data scientist feedback**
