# 5-Minute Quickstart

Get started with the Kubeflow Development Environment in under 5 minutes!

## Prerequisites

- Docker Desktop (running)
- macOS or Linux

## Quick Setup

### 1. Clone and Enter Directory

```bash
cd kubeflow-dev-env
```

### 2. Install Everything

```bash
./install.sh --mode dev --k8s 1.28.5 --kfp 2.1.0
```

This will:
- Install k3d, kubectl, and Helm if needed
- Create a local Kubernetes cluster
- Install Kubeflow Pipelines
- Set up the development environment

### 3. Access the UI

```bash
make port-forward
```

Open http://localhost:8080 in your browser.

### 4. Run Your First Pipeline

```bash
make deploy-pipeline PIPELINE=gbm-training
```

## What's Next?

- **Run the GBM training pipeline**: Based on the hw1 notebook, trains gradient boosting models
- **Build components**: `make build-all`
- **Run tests**: `make test-unit`
- **See all commands**: `make help`

## Troubleshooting

### Docker Not Running
```bash
open -a Docker  # macOS
sudo systemctl start docker  # Linux
```

### Port Already in Use
```bash
lsof -i :8080  # Find what's using the port
kill -9 <PID>  # Stop it
```

### Cluster Issues
```bash
make cluster-destroy
make cluster-create
```

## Need Help?

- Check the [FAQ](FAQ.md)
- Read the [User Guide](USER_GUIDE.md)
- Submit an [issue](https://github.com/.../issues/new/choose)
