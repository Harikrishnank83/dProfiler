# Kubernetes & Kubeflow Glossary

A beginner-friendly guide to terminology used in this project.

## Kubernetes Basics

### Cluster
A set of computers (or virtual machines) that run your applications. In this project, we use k3d to create a cluster on your laptop.

### Pod
The smallest unit in Kubernetes. A pod runs one or more containers. Each step in your ML pipeline runs in a pod.

### Container
A lightweight, isolated environment for running code. Think of it as a mini virtual machine that includes your code and all its dependencies. Built from Docker images.

### Namespace
A way to organize resources in a cluster. Like folders on your computer. Kubeflow uses the "kubeflow" namespace.

### Deployment
Tells Kubernetes how to run your application (how many copies, what resources, etc.).

### Service
Makes your application accessible to other applications or users. Like a phone number that routes to the right person.

### Node
A computer (or VM) in your cluster. With k3d, each node is actually a Docker container.

### kubectl
The command-line tool for interacting with Kubernetes. Like "cd" and "ls" for Kubernetes.

## Kubeflow Concepts

### Kubeflow
An open-source ML platform that runs on Kubernetes. Makes it easier to run ML workflows.

### Kubeflow Pipelines (KFP)
The part of Kubeflow for defining and running ML pipelines. What we use in this project.

### Pipeline
A sequence of steps (components) that process data. Like a flowchart for your ML experiment.

### Component
A single step in a pipeline. Runs in a container with specific inputs and outputs.

### Run
One execution of a pipeline. You can run the same pipeline multiple times with different parameters.

### Experiment
A group of related runs. Helps organize your work.

### Artifact
Data produced by a component. Can be datasets, models, metrics, etc.

## Project-Specific Terms

### k3d
Tool for running Kubernetes clusters in Docker. Makes it easy to create/destroy clusters.

### Registry
A place to store Docker images. We use a local registry (localhost:5000) for development.

### Operator
A Kubernetes extension that manages specific types of applications. We use Dask and Ray operators.

### CRD (Custom Resource Definition)
A way to extend Kubernetes with new types of resources. Operators use CRDs.

## Common Commands Explained

### `kubectl get pods`
Shows all pods (running containers). Useful to see if your pipeline steps are running.

### `kubectl logs <pod-name>`
Shows the output of a pod. Use this to debug failing components.

### `make port-forward`
Makes the Kubeflow UI accessible at localhost:8080. Routes traffic from your browser to the cluster.

### `make build-component`
Creates a Docker image for a component. Needed before you can use the component in a pipeline.

## Visual Reference

```
Cluster
├── Node 1 (server)
│   ├── Pod (ml-pipeline)
│   ├── Pod (mysql)
│   └── Pod (minio)
└── Node 2 (agent)
    ├── Pod (your-pipeline-step-1)
    └── Pod (your-pipeline-step-2)
```

## Still Confused?

That's okay! You don't need to understand all of this to use the platform. Just:

1. Run `make port-forward` to access the UI
2. Use the UI to run pipelines
3. View results in the UI

The Kubernetes stuff happens behind the scenes!
