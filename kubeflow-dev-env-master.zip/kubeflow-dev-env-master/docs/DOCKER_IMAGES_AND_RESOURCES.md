# Docker Images and Resource Usage Guide

**Complete guide to images, containers, disk space, and memory usage**

---

## Table of Contents

1. [Overview](#overview)
2. [Docker Images Used](#docker-images-used)
3. [Resource Requirements](#resource-requirements)
4. [Before Installation](#before-installation)
5. [After Installation](#after-installation)
6. [Custom Images](#custom-images)
7. [Image Repositories](#image-repositories)
8. [Impact Analysis](#impact-analysis)

---

## Overview

This guide provides transparency about what Docker images are downloaded, how much disk space and memory they require, and how to use custom images.

---

## Docker Images Used

### 1. Kubeflow Pipelines Images

**Source:** `gcr.io/ml-pipeline` or alternative registries

| Image | Size (Approx) | Purpose |
|-------|---------------|---------|
| `ml-pipeline-api-server` | ~200MB | Main API server |
| `ml-pipeline-frontend` | ~100MB | Web UI |
| `ml-pipeline-persistenceagent` | ~80MB | Saves run state to DB |
| `ml-pipeline-scheduledworkflow` | ~80MB | Handles recurring runs |
| `ml-pipeline-viewer-crd-controller` | ~50MB | Artifact visualization |
| `ml-pipeline-visualization-server` | ~150MB | Metrics visualization |
| **Total KFP Images** | **~660MB** | Core platform |

### 2. Supporting Services

| Image | Size (Approx) | Purpose |
|-------|---------------|---------|
| `mysql:8.0` | ~580MB | Metadata database |
| `minio/minio:RELEASE` | ~140MB | Artifact storage |
| `rancher/k3s:v1.28.5-k3s1` | ~220MB | Kubernetes nodes |
| **Total Supporting** | **~940MB** | Infrastructure |

### 3. ML Component Images (Optional)

Built locally if you run `make build-all`:

| Image | Base | Size | Purpose |
|-------|------|------|---------|
| `localhost:5000/ml-base:latest` | `python:3.10-slim` | ~450MB | Base for components |
| `localhost:5000/data-loader:latest` | `ml-base` | ~470MB | Data preprocessing |
| `localhost:5000/gbm-trainer:latest` | `ml-base` | ~520MB | Model training |
| `localhost:5000/evaluator:latest` | `ml-base` | ~480MB | Model evaluation |
| **Total Components** | | **~1.92GB** | ML pipelines |

### 4. Base Images

| Image | Size (Approx) | When Downloaded |
|-------|---------------|-----------------|
| `python:3.10-slim` | ~130MB | Building components |
| `alpine:latest` | ~7MB | Utility containers |
| `busybox:latest` | ~2MB | Testing |

---

## Resource Requirements

### Minimum Requirements

| Resource | Minimum | Recommended | Why |
|----------|---------|-------------|-----|
| **Disk Space** | 10GB | 20GB+ | Images + artifacts + data |
| **Docker Memory** | 4GB | 8GB | Running all services |
| **Docker CPUs** | 2 cores | 4+ cores | Parallel operations |
| **Available RAM** | 8GB | 16GB | Total system memory |

### Disk Space Breakdown

#### Before Installation
```
Base system:           2GB   (Docker, k3d, kubectl, etc.)
Free space required:   8GB   (minimum for installation)
```

#### After Minimal Installation
```
Kubeflow images:      ~660MB  (core platform)
Supporting services:  ~940MB  (MySQL, MinIO, k3s)
Registry cache:       ~200MB  (image layers)
Kubernetes config:    ~50MB   (configs, secrets)
MinIO storage:        ~100MB  (initial buckets)
Total:                ~2GB
```

#### After Full Installation (with components)
```
Minimal install:      ~2GB    (base platform)
ML components:        ~1.92GB (if built locally)
Component cache:      ~500MB  (build layers)
Sample data:          ~50MB   (if loaded)
Artifacts:            ~100MB  (pipeline outputs)
Total:                ~4.5GB
```

### Memory Usage

#### Idle State (No Pipelines Running)
```
k3s server:           ~500MB
ml-pipeline-api:      ~100MB
ml-pipeline-ui:       ~50MB
persistenceagent:     ~30MB
scheduledworkflow:    ~30MB
MySQL:                ~200MB
MinIO:                ~50MB
Total:                ~960MB
```

#### Active Pipeline Running
```
Idle services:        ~960MB  (from above)
Pipeline pods:        ~200MB  (per concurrent pipeline)
Data processing:      ~500MB  (temporary, per step)
Model training:       ~1GB    (varies by model)
Peak usage:           ~2.5GB+ (depends on pipeline)
```

---

## Before Installation

### Check Current Resources

Run the wizard to see your current status:
```bash
./install-wizard.sh --dry-run
```

Or check manually:

#### Check Docker Resources
```bash
# Check Docker disk usage
docker system df

# Example output:
TYPE            TOTAL    ACTIVE   SIZE      RECLAIMABLE
Images          5        2        2.5GB     1.2GB (48%)
Containers      2        1        300MB     150MB (50%)
Local Volumes   3        2        500MB     200MB (40%)
Build Cache     10       0        1.5GB     1.5GB (100%)
```

#### Check Available Disk Space
```bash
# macOS/Linux
df -h /var/lib/docker  # Or your Docker data directory
df -h .                # Current directory (for artifacts)

# Expected minimum: 10GB free
```

#### Check Docker Memory Allocation
```bash
# macOS: Docker Desktop → Settings → Resources → Memory
# Linux: docker info | grep Memory

docker info | grep "Total Memory"
# Expected minimum: 4GB
```

#### Estimate What Will Be Downloaded
```bash
# Kubeflow core images:     ~660MB
# Supporting services:      ~940MB
# Total to download:        ~1.6GB
#
# Build components locally: ~1.92GB additional
# (optional, only if you run make build-all)
```

---

## After Installation

### Check What Was Installed

#### List All Images
```bash
# All Kubeflow-related images
docker images | grep -E "(ml-pipeline|minio|mysql|k3s)"

# Local component images
docker images | grep localhost:5000

# All images with sizes
docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}"
```

#### Check Total Disk Usage
```bash
# Detailed breakdown
docker system df -v

# Images only
docker images --format "table {{.Repository}}\t{{.Size}}" | \
  awk '{sum+=$NF} END {print "Total: " sum/1024 " GB"}'
```

#### Check Running Containers
```bash
# List all containers
kubectl get pods -n kubeflow

# Memory usage per pod
kubectl top pods -n kubeflow

# Node resources
kubectl top nodes
```

#### Detailed Resource Report
```bash
# Create a resource report
cat > /tmp/resource-report.sh << 'EOF'
#!/bin/bash
echo "=== Docker Images ==="
docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}"
echo ""
echo "=== Docker Disk Usage ==="
docker system df
echo ""
echo "=== Running Containers ==="
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Size}}"
echo ""
echo "=== Kubernetes Pods ==="
kubectl get pods -n kubeflow -o wide
echo ""
echo "=== Resource Usage ==="
kubectl top pods -n kubeflow 2>/dev/null || echo "Metrics server not available"
EOF

chmod +x /tmp/resource-report.sh
/tmp/resource-report.sh
```

---

## Custom Images

### Why Use Custom Images?

1. **Corporate Policy** - Use approved base images
2. **Security** - Scan and harden images
3. **Optimization** - Reduce size, add caching
4. **Customization** - Pre-install tools/libraries
5. **Air-Gapped** - Use internal registries

### Custom Image Support: YES! ✅

The system fully supports custom images at multiple levels:

---

### 1. Custom Base Image for Components

**Default:** `python:3.10-slim`

**Change:** Edit `components/Dockerfile.base`

```dockerfile
# Instead of:
FROM python:3.10-slim

# Use your custom image:
FROM your-registry.com/python:3.10-hardened

# Or use a different base entirely:
FROM your-registry.com/ml-base:v1.0.0
```

**No Impact on KFP!** Your custom base only affects your components, not Kubeflow itself.

---

### 2. Custom Registry for Components

**Default:** `localhost:5000`

**Change:** Set registry in build commands

```bash
# Build with custom registry
./build/build-all.sh --registry your-registry.com/ml-components

# Or set environment variable
export REGISTRY=your-registry.com/ml-components
make build-all
```

**Configuration:** Edit `config/config.yaml`
```yaml
registry:
  remote:
    url: "your-registry.com"
    username: "${REGISTRY_USERNAME}"
    password: "${REGISTRY_PASSWORD}"
```

---

### 3. Custom Kubeflow Images

**Advanced:** Replace KFP images with custom versions

#### Option A: Image Patches (Recommended)

Edit `config/image-patches.yaml`:
```yaml
# Image overrides for Kubeflow Pipelines
images:
  # API Server
  ml-pipeline-api-server:
    original: "gcr.io/ml-pipeline/api-server"
    custom: "your-registry.com/ml-pipeline/api-server:2.1.0-hardened"
  
  # UI
  ml-pipeline-ui:
    original: "gcr.io/ml-pipeline/frontend"
    custom: "your-registry.com/ml-pipeline/frontend:2.1.0-hardened"
  
  # Supporting services
  mysql:
    original: "mysql:8.0"
    custom: "your-registry.com/mysql:8.0-hardened"
  
  minio:
    original: "minio/minio:RELEASE.2023-01-01"
    custom: "your-registry.com/minio:RELEASE.2023-01-01"
```

Apply during installation:
```bash
./scripts/install-kubeflow.sh --version 2.1.0 --use-custom-images
```

#### Option B: Manual Manifest Edit

Download and edit KFP manifests:
```bash
# Download official manifests
curl -O https://github.com/kubeflow/pipelines/releases/download/2.1.0/manifests.yaml

# Replace image references
sed -i 's|gcr.io/ml-pipeline|your-registry.com/kfp|g' manifests.yaml

# Apply custom manifest
kubectl apply -f manifests.yaml -n kubeflow
```

---

### 4. Custom k3s Image

**For k3d cluster:**

Edit infra templates:
```yaml
# infra/k3d-single-node.yaml.tmpl
image: your-registry.com/rancher/k3s:v1.28.5-k3s1-hardened
```

---

## Image Repositories

### Default Public Repositories

| Component | Repository | Can Change? |
|-----------|-----------|-------------|
| **KFP Core** | `gcr.io/ml-pipeline` | ✅ Yes (patches) |
| **MySQL** | `docker.io/mysql` | ✅ Yes |
| **MinIO** | `docker.io/minio` | ✅ Yes |
| **k3s** | `docker.io/rancher` | ✅ Yes |
| **Components** | `localhost:5000` | ✅ Yes (config) |
| **Base Images** | `docker.io/python` | ✅ Yes (Dockerfile) |

### Using Private Registries

#### Pull from Private Registry

```bash
# Login to your registry
docker login your-registry.com

# Configure kubectl to use credentials
kubectl create secret docker-registry regcred \
  --docker-server=your-registry.com \
  --docker-username=your-user \
  --docker-password=your-pass \
  -n kubeflow

# Patch service accounts to use secret
kubectl patch serviceaccount default \
  -p '{"imagePullSecrets": [{"name": "regcred"}]}' \
  -n kubeflow
```

#### Air-Gapped Environment

1. **Download images** (on internet-connected machine):
```bash
# Create image list
cat > images.txt << EOF
gcr.io/ml-pipeline/api-server:2.1.0
gcr.io/ml-pipeline/frontend:2.1.0
mysql:8.0
minio/minio:RELEASE.2023-01-01
rancher/k3s:v1.28.5-k3s1
python:3.10-slim
EOF

# Pull all images
while read image; do
  docker pull "$image"
done < images.txt

# Save to tar
docker save $(cat images.txt) -o kubeflow-images.tar
```

2. **Transfer** `kubeflow-images.tar` to air-gapped system

3. **Load on air-gapped system**:
```bash
docker load -i kubeflow-images.tar

# Tag for your registry
while read image; do
  new_image="your-internal-registry/${image}"
  docker tag "$image" "$new_image"
  docker push "$new_image"
done < images.txt
```

---

## Impact Analysis

### Using Different Base Images for Components

#### Scenario: Change from `python:3.10-slim` to `python:3.11-slim`

**Impact:**
- ✅ **Components:** Rebuild required, no functionality impact if code compatible
- ✅ **KFP Platform:** Zero impact (KFP doesn't care about component base)
- ✅ **Pipelines:** No impact if Python 3.11 compatible
- ⚠️ **Size:** May change by ±50MB depending on base

**Steps:**
```bash
# 1. Update base Dockerfile
sed -i 's/python:3.10-slim/python:3.11-slim/g' components/Dockerfile.base

# 2. Rebuild components
make build-all

# 3. Test pipelines
python pipelines/gbm-training-pipeline.py --run
```

---

#### Scenario: Use Custom Corporate Base Image

**Impact:**
- ✅ **Components:** Work if base has Python + pip
- ✅ **KFP Platform:** Zero impact
- ✅ **Pipelines:** No impact
- ⚠️ **Build Time:** May increase if base is larger
- ⚠️ **Dependencies:** Must ensure required packages available

**Compatibility Check:**
```dockerfile
# Your custom base must provide:
# - Python 3.9+
# - pip
# - Basic build tools (gcc, etc.) for some packages

# Test your base:
FROM your-registry.com/custom-python:latest
RUN python --version  # Should be 3.9+
RUN pip --version     # Should work
RUN pip install pandas scikit-learn  # Should succeed
```

---

#### Scenario: Different Images for Different Components

**Example:**
- Data loader: `python:3.10-slim`
- GBM trainer: `nvidia/cuda:11.8-cudnn8-runtime-ubuntu22.04`
- Evaluator: `python:3.10-slim`

**Impact:**
- ✅ **Fully Supported:** Each component has its own Dockerfile
- ✅ **KFP Platform:** Zero impact
- ✅ **Flexibility:** Use GPU images only where needed
- ⚠️ **Disk Space:** More base images = more disk usage
- ⚠️ **Complexity:** Different build processes per component

**Implementation:**
```bash
# components/gbm-trainer/Dockerfile
FROM nvidia/cuda:11.8-cudnn8-runtime-ubuntu22.04
# Custom setup for GPU training

# components/data-loader/Dockerfile
FROM python:3.10-slim
# Lightweight for data processing

# No impact on Kubeflow!
```

---

### Using Custom Kubeflow Images

#### Scenario: Hardened KFP Images

**Impact:**
- ⚠️ **Compatibility:** Must match KFP version exactly
- ⚠️ **Maintenance:** You own updates and security patches
- ✅ **Components:** No impact
- ✅ **Functionality:** Same if images are functionally equivalent

**Risk Level:** Medium (KFP must be compatible)

---

#### Scenario: Alternative MySQL/MinIO

**Impact:**
- ✅ **Low Risk:** Standard protocols (MySQL, S3)
- ✅ **Drop-in Replacement:** Works if API-compatible
- ⚠️ **Configuration:** May need connection string changes

**Example:**
```yaml
# Use PostgreSQL instead of MySQL
# Note: Requires KFP manifest changes
images:
  database:
    type: postgresql
    image: your-registry.com/postgresql:14
```

---

## Resource Optimization Tips

### 1. Reduce Image Size

```dockerfile
# Multi-stage builds
FROM python:3.10-slim as builder
RUN pip install --user pandas scikit-learn

FROM python:3.10-slim
COPY --from=builder /root/.local /root/.local
# Saves ~100MB by not keeping build tools
```

### 2. Share Base Images

```bash
# Use same base for all components
# Layers are shared, saves disk space
```

### 3. Prune Unused Images

```bash
# Remove dangling images
docker image prune -f

# Remove unused images (aggressive)
docker image prune -a -f

# Remove unused containers, networks, volumes
docker system prune -a --volumes -f
```

### 4. Enable Docker Build Cache

```yaml
# config/config.yaml
build:
  cache:
    enabled: true  # Speeds up rebuilds
```

---

## Summary

### Resource Requirements

| Phase | Disk Space | Memory | Notes |
|-------|-----------|--------|-------|
| **Before** | 10GB free | 4GB+ | Minimum for installation |
| **After (Minimal)** | +2GB | +960MB idle | Core platform only |
| **After (Full)** | +4.5GB | +960MB idle | With components built |
| **Pipeline Running** | Variable | +1-2GB | Depends on pipeline |

### Custom Images

| Level | Supported | Impact on KFP | Impact on Components |
|-------|-----------|---------------|----------------------|
| **Component Base** | ✅ Full | None | Must rebuild components |
| **Component Registry** | ✅ Full | None | Configuration only |
| **KFP Images** | ✅ Advanced | Must be compatible | None |
| **Infrastructure** | ✅ Full | Test thoroughly | None |

### Key Takeaways

1. ✅ **~1.6GB download** for minimal install
2. ✅ **~4.5GB total** for full install with components
3. ✅ **~1GB memory** idle, ~2.5GB+ during pipeline runs
4. ✅ **Custom images fully supported** at all levels
5. ✅ **No impact on KFP** from custom component bases
6. ⚠️ **Test compatibility** when using custom KFP images
7. ✅ **Air-gapped deployment** possible with image transfer

---

## Related Documentation

- **Installation Guide:** `START_HERE.md`
- **Resource Monitoring:** `docs/MONITORING_AND_DEBUGGING.md`
- **Build System:** `build/README.md` (if exists)
- **Configuration:** `config/config.yaml`

---

**Questions about images or resources?**  
See `docs/FAQ.md` or run `./scripts/diagnose.sh`
