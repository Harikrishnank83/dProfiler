# Monitoring and Debugging Kubeflow Pipelines

**Quick Reference Guide**

---

## Monitoring Options

### 1. Kubeflow UI (if installed)
**Access:** `make port-forward` → http://localhost:8080

**Capabilities:**
- Visual pipeline graphs
- Run status dashboard
- Step-by-step execution view
- Artifact visualization
- Experiment comparison
- Metrics graphs

**Best for:** Visual debugging, team collaboration, learning

---

### 2. KFP Python SDK
**Install:** `pip install kfp`

**Example:**
```python
import kfp

# Connect to KFP API
client = kfp.Client(host="http://localhost:8888")

# List runs
runs = client.list_runs(experiment_id="exp-id")
for run in runs.runs:
    print(f"{run.name}: {run.status}")

# Monitor specific run
run = client.get_run(run_id="run-123")
print(f"Status: {run.run.status}")

# Get run details
workflow = client.get_workflow(run_id="run-123")
print(workflow)
```

**Best for:** Automation, CI/CD, programmatic monitoring

---

### 3. kubectl (Kubernetes Native)
**No installation needed** (already have kubectl)

**Commands:**
```bash
# List all workflow pods
kubectl get pods -n kubeflow

# Watch workflows in real-time
kubectl get workflows -n kubeflow -w

# Get workflow status
kubectl describe workflow <workflow-name> -n kubeflow

# View pod logs
kubectl logs <pod-name> -n kubeflow

# Follow logs in real-time
kubectl logs -f <pod-name> -n kubeflow

# Get workflow events
kubectl get events -n kubeflow

# List all workflows
kubectl get workflows -n kubeflow

# Get workflow YAML
kubectl get workflow <workflow-name> -n kubeflow -o yaml
```

**Best for:** Deep debugging, troubleshooting, system administration

---

### 4. Argo CLI
**Install:** `brew install argo` (macOS) or download from releases

**Commands:**
```bash
# List workflows
argo list -n kubeflow

# Watch workflow execution
argo watch <workflow-name> -n kubeflow

# Get workflow logs
argo logs <workflow-name> -n kubeflow

# Get workflow status
argo get <workflow-name> -n kubeflow

# Get logs from specific step
argo logs <workflow-name> -c <container> -n kubeflow
```

**Best for:** Workflow-specific operations, detailed logs

---

### 5. MinIO (Artifact Storage)
**Access:** Port-forward to MinIO
```bash
kubectl port-forward svc/minio-service 9000:9000 -n kubeflow
# Open http://localhost:9000
# Login: minio / minio123
```

**Capabilities:**
- Browse pipeline artifacts
- Download intermediate results
- View model files
- Access metrics

**Best for:** Artifact inspection, data debugging

---

## Debugging Strategies

### Quick Diagnosis
```bash
# 1. Check if KFP is running
kubectl get pods -n kubeflow

# 2. Check workflow status
kubectl get workflows -n kubeflow

# 3. Find failed pods
kubectl get pods -n kubeflow | grep Error

# 4. Check recent events
kubectl get events -n kubeflow --sort-by='.lastTimestamp' | tail -20
```

### Detailed Investigation

#### Step 1: Identify Failed Workflow
```bash
# List workflows with status
kubectl get workflows -n kubeflow \
  -o custom-columns=NAME:.metadata.name,STATUS:.status.phase,AGE:.metadata.creationTimestamp
```

#### Step 2: Get Workflow Details
```bash
# Describe workflow
kubectl describe workflow <workflow-name> -n kubeflow

# Get workflow YAML
kubectl get workflow <workflow-name> -n kubeflow -o yaml
```

#### Step 3: Find Failed Steps
```bash
# List pods for this workflow
kubectl get pods -n kubeflow \
  -l workflows.argoproj.io/workflow=<workflow-name>

# Check pod status
kubectl get pod <pod-name> -n kubeflow -o yaml
```

#### Step 4: Get Logs
```bash
# Main container logs
kubectl logs <pod-name> -n kubeflow

# All container logs
kubectl logs <pod-name> -n kubeflow --all-containers=true

# Previous logs (if crashed)
kubectl logs <pod-name> -n kubeflow --previous

# Stream logs
kubectl logs -f <pod-name> -n kubeflow
```

#### Step 5: Interactive Debugging
```bash
# Exec into running pod
kubectl exec -it <pod-name> -n kubeflow -- /bin/bash

# Copy files from pod
kubectl cp kubeflow/<pod-name>:/path/to/file ./local-file
```

---

## Common Issues and Solutions

### Issue: Pipeline Stuck in Pending

**Diagnosis:**
```bash
kubectl describe pod <pod-name> -n kubeflow
```

**Common Causes:**
- Insufficient resources
- Image pull errors
- Volume mount issues

**Solutions:**
```bash
# Check node resources
kubectl top nodes

# Check image pull
kubectl get events -n kubeflow | grep Pull

# Check PVC status
kubectl get pvc -n kubeflow
```

---

### Issue: Pipeline Failed

**Diagnosis:**
```bash
# Get failure reason
kubectl get workflow <workflow-name> -n kubeflow -o jsonpath='{.status.message}'

# Get failed pod logs
kubectl logs <failed-pod> -n kubeflow
```

**Common Causes:**
- Component code errors
- Missing dependencies
- Permission issues
- Resource limits

---

### Issue: Can't Access Artifacts

**Diagnosis:**
```bash
# Check MinIO status
kubectl get pods -n kubeflow -l app=minio

# Port forward to MinIO
kubectl port-forward svc/minio-service 9000:9000 -n kubeflow
```

**Solution:** Access MinIO console at http://localhost:9000

---

## Programmatic Debugging Script

```python
#!/usr/bin/env python3
"""Automated debugging helper."""

import kfp
import subprocess

def diagnose_run(run_id):
    """Complete diagnostic of a pipeline run."""
    
    client = kfp.Client(host="http://localhost:8888")
    
    print(f"🔍 Diagnosing run: {run_id}\n")
    
    # 1. Get run status
    run = client.get_run(run_id)
    print(f"Status: {run.run.status}")
    
    if run.run.error:
        print(f"Error: {run.run.error}")
    
    # 2. Get workflow details
    workflow = client.get_workflow(run_id)
    workflow_name = workflow['metadata']['name']
    print(f"Workflow: {workflow_name}")
    
    # 3. Check each step
    print(f"\n📋 Steps:")
    nodes = workflow['status'].get('nodes', {})
    failed_pods = []
    
    for node_id, node in nodes.items():
        status = node['phase']
        print(f"  {node['displayName']}: {status}")
        
        if status == 'Failed':
            print(f"    ❌ Error: {node.get('message', 'Unknown')}")
            # Get pod name
            if 'id' in node:
                failed_pods.append(node['id'])
    
    # 4. Get logs for failed pods
    if failed_pods:
        print(f"\n📝 Failed Pod Logs:")
        for pod in failed_pods:
            print(f"\n--- {pod} ---")
            result = subprocess.run(
                ['kubectl', 'logs', pod, '-n', 'kubeflow'],
                capture_output=True,
                text=True
            )
            print(result.stdout[-500:])  # Last 500 chars

# Usage
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        diagnose_run(sys.argv[1])
    else:
        print("Usage: python debug.py <run-id>")
```

---

## Monitoring Dashboard (Text-Based)

```python
#!/usr/bin/env python3
"""Simple text-based monitoring dashboard."""

import kfp
import time
from datetime import datetime

def dashboard(refresh_seconds=10):
    """Display live dashboard."""
    
    client = kfp.Client(host="http://localhost:8888")
    
    while True:
        # Clear screen
        print("\033[2J\033[H")
        
        print("=" * 70)
        print(f"Kubeflow Pipelines Dashboard - {datetime.now().strftime('%H:%M:%S')}")
        print("=" * 70)
        
        # Get recent runs
        runs = client.list_runs(page_size=10).runs or []
        
        print(f"\n📊 Recent Runs ({len(runs)}):")
        print("-" * 70)
        
        status_counts = {"Running": 0, "Succeeded": 0, "Failed": 0}
        
        for run in runs:
            status = run.status or "Unknown"
            status_counts[status] = status_counts.get(status, 0) + 1
            
            # Status emoji
            emoji = {
                "Running": "⏳",
                "Succeeded": "✅",
                "Failed": "❌",
            }.get(status, "❓")
            
            print(f"{emoji} {run.name[:40]:<40} {status:<10}")
        
        print("-" * 70)
        print(f"\n📈 Summary:")
        for status, count in status_counts.items():
            print(f"  {status}: {count}")
        
        time.sleep(refresh_seconds)

if __name__ == "__main__":
    try:
        dashboard()
    except KeyboardInterrupt:
        print("\n\nDashboard stopped.")
```

---

## Best Practices

### 1. Enable Logging in Components
```python
@dsl.component
def my_component():
    import logging
    
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    logger.info("Starting processing...")
    # Your code
    logger.info("Processing complete!")
```

### 2. Save Intermediate Artifacts
```python
@dsl.component
def process_data(output_path: str):
    # Save intermediate results
    import json
    
    result = {"status": "complete"}
    with open(output_path, 'w') as f:
        json.dump(result, f)
    
    # These are automatically stored in MinIO
```

### 3. Use Meaningful Names
```python
run = client.create_run_from_pipeline_func(
    pipeline_func=training_pipeline,
    run_name=f"training-v2-{datetime.now().strftime('%Y%m%d-%H%M')}",  # Clear naming
    experiment_name="production-models"  # Organized experiments
)
```

### 4. Add Retries for Flaky Steps
```python
@dsl.component
def flaky_task():
    # Add retry logic
    pass

# In pipeline
task = flaky_task()
task.set_retry(num_retries=3, backoff_duration="1m")
```

---

## Quick Command Reference

```bash
# ===== Monitoring =====
# Watch all KFP pods
kubectl get pods -n kubeflow -w

# Watch workflows
kubectl get workflows -n kubeflow -w

# Get workflow status
argo list -n kubeflow

# ===== Debugging =====
# Get logs from specific pod
kubectl logs <pod-name> -n kubeflow

# Describe failed workflow
kubectl describe workflow <name> -n kubeflow

# Get events
kubectl get events -n kubeflow --sort-by='.lastTimestamp'

# ===== Artifacts =====
# Port forward to MinIO
kubectl port-forward svc/minio-service 9000:9000 -n kubeflow

# ===== API Access =====
# Port forward to KFP API
kubectl port-forward svc/ml-pipeline 8888:8888 -n kubeflow
```

---

## Summary

### You can monitor KFP runs via:
1. **UI** - Visual dashboard (if installed)
2. **SDK** - Programmatic access
3. **kubectl** - Kubernetes native
4. **Argo CLI** - Workflow specific
5. **MinIO** - Artifact access

### You can debug issues via:
1. **Pod logs** - kubectl logs
2. **Workflow events** - kubectl describe
3. **SDK diagnostics** - client.get_workflow()
4. **Interactive** - kubectl exec
5. **Artifacts** - MinIO console

### UI is completely optional!
All monitoring and debugging can be done programmatically or via CLI tools.

---

**For complete API-only workflow, see:** `docs/KFP_WITHOUT_UI.md`
