# Troubleshooting Guide

This guide documents common issues encountered during setup and usage of the Kubeflow Development Environment, along with their solutions.

## Table of Contents

1. [Quick Diagnostics](#quick-diagnostics)
2. [Installation Issues](#installation-issues)
3. [Cluster Creation Issues](#cluster-creation-issues)
4. [Kubeflow Pipelines Issues](#kubeflow-pipelines-issues)
5. [Image Pull Issues](#image-pull-issues)
6. [Component Issues](#component-issues)
7. [Unified GBM Issues](#unified-gbm-issues)
8. [Performance Issues](#performance-issues)
9. [Recovery Procedures](#recovery-procedures)

---

## Quick Diagnostics

### Health Check Script

Run this to quickly diagnose common issues:

```bash
#!/bin/bash
echo "=== System Check ==="
echo "Docker: $(docker info > /dev/null 2>&1 && echo 'Running' || echo 'NOT RUNNING')"
echo "k3d: $(k3d version 2>/dev/null | head -1 || echo 'NOT INSTALLED')"
echo "kubectl: $(kubectl version --client -o json 2>/dev/null | jq -r '.clientVersion.gitVersion' || echo 'NOT INSTALLED')"
echo "helm: $(helm version --short 2>/dev/null || echo 'NOT INSTALLED')"

echo ""
echo "=== Cluster Status ==="
k3d cluster list 2>/dev/null || echo "No clusters found"

echo ""
echo "=== Kubeflow Pods ==="
kubectl get pods -n kubeflow 2>/dev/null || echo "Cannot connect to cluster"

echo ""
echo "=== Problem Pods ==="
kubectl get pods -n kubeflow 2>/dev/null | grep -v "Running\|Completed" | grep -v "NAME"
```

### Common Status Indicators

| Pod Status | Meaning | Action |
|------------|---------|--------|
| `Running` | Healthy | None needed |
| `Pending` | Waiting for resources | Check node resources, PVCs |
| `ImagePullBackOff` | Cannot pull image | See [Image Pull Issues](#image-pull-issues) |
| `CrashLoopBackOff` | Container crashing | Check logs with `kubectl logs` |
| `Error` | Container failed | Check logs and events |
| `Terminating` | Being deleted | Wait or force delete |

---

## Installation Issues

### Issue: Docker is not running

**Symptoms:**
```
Cannot connect to the Docker daemon at unix:///Users/.../.docker/run/docker.sock
```

**Solution:**
```bash
# macOS
open -a Docker
sleep 15  # Wait for Docker to start

# Linux
sudo systemctl start docker

# Verify
docker info
```

### Issue: k3d not installed

**Symptoms:**
```
command not found: k3d
```

**Solution:**
```bash
# macOS with Homebrew
brew install k3d

# Linux/macOS with curl
curl -s https://raw.githubusercontent.com/k3d-io/k3d/main/install.sh | bash

# Verify
k3d version
```

### Issue: kubectl not configured

**Symptoms:**
```
The connection to the server localhost:8080 was refused
```

**Solution:**
```bash
# List clusters and get kubeconfig
k3d cluster list
k3d kubeconfig merge kfp-dev --kubeconfig-switch-context

# Verify
kubectl cluster-info
```

### Issue: Helm not installed

**Symptoms:**
```
command not found: helm
```

**Solution:**
```bash
# macOS
brew install helm

# Linux
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Verify
helm version
```

---

## Cluster Creation Issues

### Issue: Port already in use

**Symptoms:**
```
listen tcp4 0.0.0.0:5000: bind: address already in use
```

**Cause:** Another service (often macOS AirPlay Receiver) is using port 5000.

**Solution:**
```bash
# Option 1: Use a different port for registry
k3d cluster create kfp-dev --registry-create kfp-registry:5050

# Option 2: Find and stop the service using the port
lsof -i :5000
# Then stop the service, or on macOS:
# System Preferences > General > AirDrop & Handoff > AirPlay Receiver (OFF)

# Option 3: Create cluster without registry
k3d cluster create kfp-dev --port "8080:80@loadbalancer"
```

### Issue: API port conflict

**Symptoms:**
```
listen tcp4 0.0.0.0:6443: bind: address already in use
```

**Solution:**
```bash
# Use a different API port
k3d cluster create kfp-dev --api-port 6444
```

### Issue: Cluster creation hangs

**Symptoms:**
- Cluster creation takes more than 5 minutes
- Stuck at "Starting cluster..."

**Solution:**
```bash
# 1. Check Docker resources
docker system df
docker system prune -f  # Free up space

# 2. Increase Docker resources (Docker Desktop > Settings > Resources)
# Recommended: 4 CPUs, 8GB RAM, 20GB disk

# 3. Delete partial cluster and retry
k3d cluster delete kfp-dev
k3d cluster create kfp-dev --timeout 10m
```

### Issue: Node not ready

**Symptoms:**
```
NAME                   STATUS     ROLES    AGE   VERSION
k3d-kfp-dev-server-0   NotReady   master   1m    v1.28.5+k3s1
```

**Solution:**
```bash
# Check node conditions
kubectl describe node k3d-kfp-dev-server-0

# Common fixes:
# 1. Wait longer (can take 2-3 minutes)
# 2. Restart the cluster
k3d cluster stop kfp-dev
k3d cluster start kfp-dev

# 3. Recreate if persists
k3d cluster delete kfp-dev
k3d cluster create kfp-dev
```

---

## Kubeflow Pipelines Issues

### Issue: KFP pods stuck in ImagePullBackOff

**Symptoms:**
```
minio-xxx                 0/1     ImagePullBackOff   0          5m
ml-pipeline-ui-xxx        0/1     ImagePullBackOff   0          5m
```

**Cause:** GCR images (gcr.io/ml-pipeline/*) are deprecated or not accessible.

**Solution:**
Apply our image patches:

```bash
# Patch minio to use official image
kubectl patch deployment minio -n kubeflow --type='json' -p='[
  {"op": "replace", "path": "/spec/template/spec/containers/0/image", "value": "minio/minio:RELEASE.2023-06-19T19-52-50Z"},
  {"op": "replace", "path": "/spec/template/spec/containers/0/command", "value": ["/bin/sh", "-c", "minio server /data --console-address :9001"]}
]'

# Patch workflow-controller to use upstream Argo image
kubectl patch deployment workflow-controller -n kubeflow --type='json' -p='[
  {"op": "replace", "path": "/spec/template/spec/containers/0/image", "value": "quay.io/argoproj/workflow-controller:v3.4.17"}
]'

# Update executor image in configmap
kubectl patch cm workflow-controller-configmap -n kubeflow --type='json' -p='[
  {"op": "replace", "path": "/data/executor", "value": "imagePullPolicy: IfNotPresent\nimage: quay.io/argoproj/argoexec:v3.4.17\n"}
]'

# Scale down UI if image not available
kubectl scale deployment ml-pipeline-ui -n kubeflow --replicas=0
```

### Issue: workflow-controller in CrashLoopBackOff

**Symptoms:**
```
workflow-controller-xxx   0/1     CrashLoopBackOff   5          10m
```

**Diagnosis:**
```bash
kubectl logs -n kubeflow -l app=workflow-controller --tail=50
```

**Common Causes & Solutions:**

1. **Metrics port conflict (port 9090 already in use)**
   ```
   panic: listen tcp :9090: bind: address already in use
   ```
   
   **Solution:** Use upstream Argo image which handles this better:
   ```bash
   kubectl patch deployment workflow-controller -n kubeflow --type='json' -p='[
     {"op": "replace", "path": "/spec/template/spec/containers/0/image", "value": "quay.io/argoproj/workflow-controller:v3.4.17"}
   ]'
   ```

2. **Cannot connect to minio**
   ```
   Failed to check if Minio bucket exists
   ```
   
   **Solution:** Ensure minio is running first:
   ```bash
   kubectl get pods -n kubeflow -l app=minio
   # If not running, apply minio patch above
   ```

### Issue: ml-pipeline (API server) crashing

**Symptoms:**
```
ml-pipeline-xxx   0/1     CrashLoopBackOff   10         30m
```

**Diagnosis:**
```bash
kubectl logs -n kubeflow -l app=ml-pipeline --tail=100
```

**Common Causes & Solutions:**

1. **MySQL not ready**
   ```bash
   kubectl get pods -n kubeflow -l app=mysql
   # Wait for mysql to be Running before ml-pipeline starts
   ```

2. **Minio not available**
   ```bash
   kubectl get pods -n kubeflow -l app=minio
   # Ensure minio is running
   ```

3. **Database migration issues**
   ```bash
   # Delete the pod to restart fresh
   kubectl delete pod -n kubeflow -l app=ml-pipeline
   ```

### Issue: Cannot access KFP UI

**Symptoms:**
- Port-forward works but browser shows error
- Connection refused

**Solution:**
```bash
# Check if ml-pipeline-ui is running
kubectl get pods -n kubeflow -l app=ml-pipeline-ui

# If not running (image issues), use API directly:
kubectl port-forward svc/ml-pipeline 8888:8888 -n kubeflow

# Test API
curl http://localhost:8888/apis/v2beta1/healthz
```

### Issue: Namespace stuck in Terminating

**Symptoms:**
```
kubeflow   Terminating   5h
```

**Solution:**
```bash
# Remove finalizers
kubectl get namespace kubeflow -o json | jq '.spec.finalizers = []' | kubectl replace --raw "/api/v1/namespaces/kubeflow/finalize" -f -

# If that doesn't work, delete stuck resources manually
kubectl api-resources --verbs=list --namespaced -o name | xargs -n 1 kubectl get -n kubeflow --ignore-not-found

# Force delete
kubectl delete namespace kubeflow --grace-period=0 --force
```

---

## Image Pull Issues

### Issue: General ImagePullBackOff

**Diagnosis:**
```bash
# Get detailed error
kubectl describe pod <pod-name> -n kubeflow | grep -A 10 "Events:"
```

**Common errors and solutions:**

| Error | Cause | Solution |
|-------|-------|----------|
| `not found` | Image doesn't exist | Use alternative image |
| `unauthorized` | Private registry | Add imagePullSecrets |
| `timeout` | Network issues | Check DNS, proxy settings |
| `manifest unknown` | Wrong tag | Check available tags |

### Pre-pulling images to k3d

```bash
# Pull on host and import to k3d
docker pull <image>
k3d image import <image> -c kfp-dev

# Example for minio
docker pull minio/minio:RELEASE.2023-06-19T19-52-50Z
k3d image import minio/minio:RELEASE.2023-06-19T19-52-50Z -c kfp-dev
```

### Using local registry

```bash
# Tag and push to local registry
docker tag myimage:latest localhost:5050/myimage:latest
docker push localhost:5050/myimage:latest

# Use in deployment
# image: kfp-registry:5050/myimage:latest
```

---

## Component Issues

### Issue: Component build fails

**Symptoms:**
```
ERROR: failed to solve: failed to compute cache key
```

**Solution:**
```bash
# Clear Docker build cache
docker builder prune -f

# Rebuild with no cache
docker build --no-cache -t component:latest .
```

### Issue: Component cannot find dependencies

**Symptoms:**
```
ModuleNotFoundError: No module named 'xxx'
```

**Solution:**
```bash
# Check requirements.txt is correct
cat requirements.txt

# Rebuild image
./build/build-component.sh <component-name>
```

### Issue: Pipeline fails with artifact error

**Symptoms:**
```
failed to save artifact: connection refused
```

**Solution:**
```bash
# Check minio is running
kubectl get pods -n kubeflow -l app=minio

# Check minio service
kubectl get svc -n kubeflow minio-service

# Test minio connection from within cluster
kubectl run -it --rm debug --image=busybox --restart=Never -- \
  wget -qO- http://minio-service.kubeflow:9000/minio/health/live
```

---

## Unified GBM Issues

### Issue: Import error for unified_gbm

**Symptoms:**
```python
ModuleNotFoundError: No module named 'unified_gbm'
```

**Solution:**
```bash
# Install in development mode
cd kubeflow-dev-env/unified-gbm
pip install -e ".[all]"

# Or install specific extras
pip install -e ".[xgboost]"
```

### Issue: XGBoost not found

**Symptoms:**
```python
ImportError: xgboost is required. Install with: pip install xgboost
```

**Solution:**
```bash
pip install xgboost
# Or
pip install unified-gbm[xgboost]
```

### Issue: Ray backend fails to initialize

**Symptoms:**
```python
ConnectionError: Could not connect to Ray cluster
```

**Solution:**
```bash
# Start local Ray cluster
ray start --head

# Or use local backend for testing
from unified_gbm import UnifiedGBMComponent
gbm = UnifiedGBMComponent(compute_backend="local")  # Instead of "ray"
```

### Issue: Data loading fails

**Symptoms:**
```python
FileNotFoundError: [Errno 2] No such file or directory
```

**Solution:**
```python
# Use absolute paths
from pathlib import Path
data_path = str(Path("data/train.parquet").absolute())

# Or for S3
data_path = "s3://bucket/path/to/data.parquet"  # Requires s3fs
```

---

## Performance Issues

### Issue: Cluster running slowly

**Diagnosis:**
```bash
# Check resource usage
kubectl top nodes
kubectl top pods -n kubeflow

# Check for resource limits
kubectl describe pod <pod-name> -n kubeflow | grep -A 5 "Limits:"
```

**Solution:**
```bash
# Increase Docker resources (Docker Desktop Settings)
# Recommended: 4+ CPUs, 8+ GB RAM

# Or reduce agent count
k3d cluster delete kfp-dev
k3d cluster create kfp-dev --agents 1  # Instead of 2
```

### Issue: Pipeline runs slowly

**Solutions:**
1. Use caching:
   ```yaml
   # In component spec
   caching: true
   ```

2. Use Ray/Dask for distributed execution:
   ```python
   gbm = UnifiedGBMComponent(compute_backend="ray")
   ```

3. Reduce data size for testing:
   ```python
   df = df.sample(n=10000)
   ```

---

## Recovery Procedures

### Full Cluster Reset

```bash
#!/bin/bash
# Complete reset of the KFP environment

# 1. Delete cluster
k3d cluster delete kfp-dev

# 2. Clean Docker (optional)
docker system prune -f
docker volume prune -f

# 3. Recreate cluster
k3d cluster create kfp-dev \
  --api-port 6443 \
  --port "8080:80@loadbalancer" \
  --agents 2 \
  --registry-create kfp-registry:5050

# 4. Install KFP
export PIPELINE_VERSION=2.3.0
kubectl apply -k "github.com/kubeflow/pipelines/manifests/kustomize/cluster-scoped-resources?ref=$PIPELINE_VERSION"
kubectl wait --for condition=established --timeout=60s crd/applications.app.k8s.io
kubectl apply -k "github.com/kubeflow/pipelines/manifests/kustomize/env/platform-agnostic?ref=$PIPELINE_VERSION"

# 5. Apply patches
kubectl patch deployment minio -n kubeflow --type='json' -p='[
  {"op": "replace", "path": "/spec/template/spec/containers/0/image", "value": "minio/minio:RELEASE.2023-06-19T19-52-50Z"},
  {"op": "replace", "path": "/spec/template/spec/containers/0/command", "value": ["/bin/sh", "-c", "minio server /data --console-address :9001"]}
]'

kubectl patch deployment workflow-controller -n kubeflow --type='json' -p='[
  {"op": "replace", "path": "/spec/template/spec/containers/0/image", "value": "quay.io/argoproj/workflow-controller:v3.4.17"}
]'

# 6. Wait for pods
kubectl wait --for=condition=Available deployment --all -n kubeflow --timeout=300s
```

### Restart All KFP Pods

```bash
# Delete all pods to trigger recreation
kubectl delete pods --all -n kubeflow

# Wait for restart
kubectl wait --for=condition=Ready pod --all -n kubeflow --timeout=300s
```

### Export/Import Cluster State

```bash
# Export
./scripts/export-cluster.sh kfp-dev backup.tar.gz

# Import on another machine
./scripts/import-cluster.sh backup.tar.gz
```

---

## Getting Help

### Collect Diagnostic Information

```bash
#!/bin/bash
# Save this as collect-diagnostics.sh

OUTPUT="diagnostics-$(date +%Y%m%d-%H%M%S).txt"

{
  echo "=== System Info ==="
  uname -a
  docker version
  k3d version
  kubectl version
  
  echo ""
  echo "=== Cluster Info ==="
  k3d cluster list
  kubectl cluster-info
  
  echo ""
  echo "=== Node Status ==="
  kubectl get nodes -o wide
  kubectl describe nodes
  
  echo ""
  echo "=== All Pods ==="
  kubectl get pods -A -o wide
  
  echo ""
  echo "=== KFP Pods Details ==="
  kubectl describe pods -n kubeflow
  
  echo ""
  echo "=== Recent Events ==="
  kubectl get events -n kubeflow --sort-by='.lastTimestamp'
  
  echo ""
  echo "=== Pod Logs ==="
  for pod in $(kubectl get pods -n kubeflow -o name); do
    echo "--- $pod ---"
    kubectl logs $pod -n kubeflow --tail=50 2>/dev/null || echo "No logs available"
  done
  
} > "$OUTPUT"

echo "Diagnostics saved to $OUTPUT"
```

### Useful Commands Quick Reference

```bash
# View logs
kubectl logs <pod> -n kubeflow
kubectl logs <pod> -n kubeflow --previous  # Previous container
kubectl logs <pod> -n kubeflow -f  # Follow

# Describe resources
kubectl describe pod <pod> -n kubeflow
kubectl describe deployment <deploy> -n kubeflow

# Execute in pod
kubectl exec -it <pod> -n kubeflow -- /bin/sh

# Port forward
kubectl port-forward svc/ml-pipeline 8888:8888 -n kubeflow
kubectl port-forward svc/minio-service 9000:9000 -n kubeflow

# Watch pods
watch kubectl get pods -n kubeflow

# Get events
kubectl get events -n kubeflow --sort-by='.lastTimestamp'
```

---

## Known Issues & Workarounds

| Issue | Status | Workaround |
|-------|--------|------------|
| GCR images deprecated | Permanent | Use image patches in `config/image-patches.yaml` |
| ml-pipeline-ui not available | Permanent | Access API directly via port-forward |
| workflow-controller port conflict | Fixed | Use upstream Argo image |
| Port 5000 conflict on macOS | OS-level | Use port 5050 for registry |

---

## Version Compatibility Matrix

| Kubernetes | KFP Version | Status |
|------------|-------------|--------|
| 1.26.x | 2.0.5, 2.1.0 | Tested |
| 1.28.x | 2.1.0, 2.2.0, 2.3.0 | Tested |
| 1.29.x | 2.2.0, 2.3.0 | Tested |
| 1.30+ | 2.3.0 | Experimental |

---

*Last updated: 2026-02-01*
*Based on issues encountered during initial setup*
