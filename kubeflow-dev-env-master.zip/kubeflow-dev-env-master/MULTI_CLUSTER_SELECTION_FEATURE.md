# Multi-Cluster Selection Feature

**Date:** February 2, 2026  
**Feature:** Cluster selection and multi-environment support  
**Status:** ✅ **IMPLEMENTED**

---

## 🎯 Feature Overview

### What's New

The wizard now supports **managing multiple K3d clusters** for different environments (dev, QA, production) with different K8s and KFP versions.

**Key Capabilities:**
- ✅ **List existing clusters** with K8s and KFP versions
- ✅ **Select existing cluster** or create new one
- ✅ **Multi-environment support** (dev, QA, prod)
- ✅ **Version visibility** - See K8s/KFP versions before selection
- ✅ **Flexible naming** - Custom cluster names
- ✅ **Smart context switching** - Automatic kubectl context management

---

## 🚀 User Experience

### New Wizard Flow (Step 3/8)

```bash
./install-wizard.sh
```

**Step 1-2:** System detection and mode selection (unchanged)

**Step 3 (NEW): Select or Create Cluster**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CLUSTER NAME         STATUS          K8s VERSION     KFP VERSION      NODES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
kfp-dev             ● running        1.28.5          2.1.0            1
kfp-qa              ● running        1.28.5          2.1.0            1
kfp-prod            ● stopped        1.29.0          2.2.0            3
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

What would you like to do?

  1) Use existing cluster: kfp-dev
  2) Use existing cluster: kfp-qa
  3) Use existing cluster: kfp-prod
  4) Create a new cluster

Enter your choice (1-4) [4] (type 'help' or 'exit'):
```

**Step 4-8:** Version selection, installation plan, etc. (adjusted for selected cluster)

---

## 📖 Usage Scenarios

### Scenario 1: First Time User (No Existing Clusters)

```bash
./install-wizard.sh
```

**Step 3 Output:**
```
Scanning for existing K3d clusters...

No existing K3d clusters found.

A new cluster will be created with:
  • Name: kfp-dev
  • You'll choose K8s and KFP versions in the next step

[Continues to step 4...]
```

### Scenario 2: Select Existing Dev Cluster

```bash
./install-wizard.sh
```

**Step 3 - User selects option 1 (kfp-dev):**

```
✓ Selected existing cluster: kfp-dev

Fetching cluster details...

Cluster Information:
  • Cluster: kfp-dev
  • Kubernetes: 1.28.5
  • KFP: 2.1.0
```

**Step 4 (Auto-skipped):**
```
Using versions from existing cluster 'kfp-dev':
  • Kubernetes: 1.28.5
  • Kubeflow Pipelines: 2.1.0
```

### Scenario 3: Create New QA Cluster

```bash
./install-wizard.sh
```

**Step 3 - User selects option 4 (Create new):**

```
Enter name for new cluster [kfp-dev] (type 'help' or 'exit'): kfp-qa

✓ Will create new cluster: kfp-qa
```

**Step 4 - Choose versions:**
```
Kubernetes version [1.28.5]: 1.28.5
Kubeflow Pipelines version [2.1.0]: 2.1.0

✓ Selected K8s 1.28.5 + KFP 2.1.0
```

### Scenario 4: Create Production Cluster (Multi-Node, Latest Versions)

```bash
./install-wizard.sh
```

**Step 3:**
```
Enter name for new cluster [kfp-dev]: kfp-prod

✓ Will create new cluster: kfp-prod
```

**Step 4:**
```
Kubernetes version [1.28.5]: 1.29.0
Kubeflow Pipelines version [2.1.0]: 2.2.0

✓ Selected K8s 1.29.0 + KFP 2.2.0
```

---

## 🎯 Multi-Environment Setup Example

### Complete Workflow: Dev → QA → Prod

#### Step 1: Create Development Cluster

```bash
./install-wizard.sh

# Step 3: Create new cluster
Enter name: kfp-dev
# Step 4: K8s 1.28.5, KFP 2.1.0
# Mode: Dev

Result: ✅ kfp-dev cluster with K8s 1.28.5 + KFP 2.1.0
```

#### Step 2: Create QA Cluster

```bash
./install-wizard.sh

# Step 3: Sees existing kfp-dev
# Selects: Create new cluster
Enter name: kfp-qa
# Step 4: K8s 1.28.5, KFP 2.1.0 (same as dev)
# Mode: Full (includes operators)

Result: ✅ kfp-qa cluster with K8s 1.28.5 + KFP 2.1.0
```

#### Step 3: Create Production Cluster

```bash
./install-wizard.sh

# Step 3: Sees existing kfp-dev, kfp-qa
# Selects: Create new cluster
Enter name: kfp-prod
# Step 4: K8s 1.29.0, KFP 2.2.0 (latest)
# Mode: Full

Result: ✅ kfp-prod cluster with K8s 1.29.0 + KFP 2.2.0
```

#### Step 4: List All Clusters

```bash
./scripts/cluster-list-detailed.sh
```

**Output:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CLUSTER NAME         STATUS          K8s VERSION     KFP VERSION      NODES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
kfp-dev             ● running        1.28.5          2.1.0            1
kfp-qa              ● running        1.28.5          2.1.0            1
kfp-prod            ● running        1.29.0          2.2.0            1
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 🔧 New Scripts and Tools

### 1. Cluster List Detailed (`scripts/cluster-list-detailed.sh`)

**Purpose:** List all K3d clusters with comprehensive details

**Usage:**
```bash
# Table format (default)
./scripts/cluster-list-detailed.sh

# JSON format
./scripts/cluster-list-detailed.sh --format json
```

**Output (Table):**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CLUSTER NAME         STATUS          K8s VERSION     KFP VERSION      NODES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
kfp-dev             ● running        1.28.5          2.1.0            1
kfp-qa              ● running        1.28.5          2.0.5            1
kfp-prod            ● stopped        1.29.0          not-installed    3
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Output (JSON):**
```json
[
  {
    "name": "kfp-dev",
    "status": "running",
    "k8s_version": "1.28.5",
    "kfp_version": "2.1.0",
    "node_count": 1
  },
  {
    "name": "kfp-qa",
    "status": "running",
    "k8s_version": "1.28.5",
    "kfp_version": "2.0.5",
    "node_count": 1
  },
  {
    "name": "kfp-prod",
    "status": "stopped",
    "k8s_version": "1.29.0",
    "kfp_version": "not-installed",
    "node_count": 3
  }
]
```

**Features:**
- ✅ Detects K8s version from cluster
- ✅ Detects KFP version from deployment
- ✅ Shows cluster status (running/stopped)
- ✅ Shows node count
- ✅ Color-coded output
- ✅ JSON export for scripting

### 2. Enhanced Wizard (`install-wizard.sh`)

**New Step:** `select_or_create_cluster()` (Step 3/8)

**Features:**
- ✅ Automatic cluster discovery
- ✅ Interactive selection menu
- ✅ Version display before selection
- ✅ Custom cluster naming
- ✅ Automatic context switching
- ✅ Graceful handling of no clusters

---

## 💡 Use Cases

### Use Case 1: Testing Across Multiple K8s Versions

**Scenario:** Test pipeline compatibility across K8s versions

```bash
# Create cluster with K8s 1.26
./install-wizard.sh
# Name: kfp-k8s-126, K8s: 1.26, KFP: 2.1.0

# Create cluster with K8s 1.28
./install-wizard.sh
# Name: kfp-k8s-128, K8s: 1.28, KFP: 2.1.0

# Create cluster with K8s 1.29
./install-wizard.sh
# Name: kfp-k8s-129, K8s: 1.29, KFP: 2.1.0

# Test pipeline on each cluster
for cluster in kfp-k8s-126 kfp-k8s-128 kfp-k8s-129; do
    kubectl config use-context k3d-$cluster
    python submit_pipeline.py
done
```

### Use Case 2: Testing KFP Version Upgrades

**Scenario:** Test KFP upgrade from 2.0.5 to 2.1.0

```bash
# Create cluster with KFP 2.0.5
./install-wizard.sh
# Name: kfp-v205, K8s: 1.28.5, KFP: 2.0.5

# Create cluster with KFP 2.1.0
./install-wizard.sh
# Name: kfp-v210, K8s: 1.28.5, KFP: 2.1.0

# Compare behavior
kubectl config use-context k3d-kfp-v205
python test_pipeline.py --version 2.0.5

kubectl config use-context k3d-kfp-v210
python test_pipeline.py --version 2.1.0
```

### Use Case 3: Environment Isolation

**Scenario:** Separate dev, QA, and prod environments

```bash
# Development cluster
./install-wizard.sh
# Name: kfp-dev
# K8s: 1.28.5, KFP: 2.1.0
# Mode: Dev (lightweight)

# QA cluster
./install-wizard.sh
# Name: kfp-qa
# K8s: 1.28.5, KFP: 2.1.0
# Mode: Full (with operators)

# Production cluster
./install-wizard.sh
# Name: kfp-prod
# K8s: 1.29.0, KFP: 2.2.0
# Mode: Full (latest versions)

# Switch between environments
alias kfp-dev='kubectl config use-context k3d-kfp-dev'
alias kfp-qa='kubectl config use-context k3d-kfp-qa'
alias kfp-prod='kubectl config use-context k3d-kfp-prod'
```

### Use Case 4: Feature Branch Testing

**Scenario:** Test features in isolated clusters

```bash
# Main development cluster
./install-wizard.sh
# Name: kfp-main

# Feature branch cluster
./install-wizard.sh
# Name: kfp-feature-auth

# Another feature branch
./install-wizard.sh
# Name: kfp-feature-ui

# List all feature clusters
./scripts/cluster-list-detailed.sh | grep kfp-feature
```

---

## 📊 Benefits

### For Developers
- ✅ **Easy environment switching** - Test across versions
- ✅ **Parallel development** - Multiple feature clusters
- ✅ **Version testing** - Verify compatibility
- ✅ **No conflicts** - Isolated environments

### For QA Teams
- ✅ **Stable test environments** - Separate QA clusters
- ✅ **Version validation** - Test before production
- ✅ **Reproducible tests** - Known cluster configurations
- ✅ **Environment parity** - Match production setup

### For Operations
- ✅ **Production-like testing** - Isolated prod cluster
- ✅ **Upgrade testing** - Test new versions safely
- ✅ **Disaster recovery** - Quick cluster recreation
- ✅ **Environment documentation** - See all clusters at a glance

---

## 🔍 Technical Details

### Cluster Detection Logic

```bash
# 1. List all K3d clusters
k3d cluster list -o json

# 2. For each cluster:
#    - Get K8s version from kubectl or docker inspect
#    - Get KFP version from deployment image tag
#    - Get cluster status (running/stopped)
#    - Get node count

# 3. Display in table or JSON format
```

### Version Detection

**K8s Version:**
1. Try: `kubectl version --short` (if cluster running)
2. Fallback: `docker inspect` K3S_VERSION env var

**KFP Version:**
1. Check if `kubeflow` namespace exists
2. Try: Get `ml-pipeline` deployment image tag
3. Fallback: Check if KFP pods exist → "installed"
4. Else: "not-installed"

### Context Management

```bash
# When existing cluster selected:
kubectl config use-context "k3d-$CLUSTER_NAME"

# When new cluster created:
# k3d automatically sets context

# Verify current context:
kubectl config current-context
```

---

## 🛠️ Commands Reference

### List Clusters
```bash
# Detailed view with versions
./scripts/cluster-list-detailed.sh

# JSON format
./scripts/cluster-list-detailed.sh --format json

# Quick list (k3d native)
k3d cluster list
```

### Manage Clusters
```bash
# Create via wizard (recommended)
./install-wizard.sh

# Create directly
./scripts/cluster-create.sh --k8s 1.28.5 --name kfp-qa

# Switch context
kubectl config use-context k3d-kfp-qa

# Stop cluster
k3d cluster stop kfp-qa

# Start cluster
k3d cluster start kfp-qa

# Delete cluster
./scripts/cluster-destroy.sh --name kfp-qa
```

### Get Current Cluster Info
```bash
# Current context
kubectl config current-context

# Cluster info
kubectl cluster-info

# K8s version
kubectl version --short

# KFP version
kubectl get deployment -n kubeflow ml-pipeline \
  -o jsonpath='{.spec.template.spec.containers[0].image}'
```

---

## ✅ Testing

### Test 1: No Existing Clusters
```bash
# Ensure clean state
k3d cluster delete --all

# Run wizard
./install-wizard.sh

# Expected: Shows "No clusters found", creates new one
# Result: ✅ PASS
```

### Test 2: Select Existing Cluster
```bash
# Create cluster
./install-wizard.sh
# Name: kfp-test

# Run wizard again
./install-wizard.sh

# Expected: Shows kfp-test in list, allows selection
# Result: ✅ PASS
```

### Test 3: Create Multiple Clusters
```bash
# Create 3 clusters
for name in kfp-dev kfp-qa kfp-prod; do
    ./install-wizard.sh
    # Create new cluster: $name
done

# List all
./scripts/cluster-list-detailed.sh

# Expected: Shows all 3 clusters
# Result: ✅ PASS
```

### Test 4: JSON Output
```bash
./scripts/cluster-list-detailed.sh --format json | jq '.'

# Expected: Valid JSON with cluster array
# Result: ✅ PASS
```

---

## 📝 Migration Guide

### For Existing Users

**Before (Single Cluster):**
```bash
./install-wizard.sh
# Always used cluster named "kfp-dev"
# No cluster selection
```

**After (Multi-Cluster):**
```bash
./install-wizard.sh
# Step 3: Shows existing clusters
# Can select existing or create new
# Can name clusters
```

**Backward Compatibility:**
- ✅ Default cluster name still "kfp-dev"
- ✅ If no clusters exist, creates "kfp-dev" automatically
- ✅ Existing workflows unchanged

---

## 🎉 Summary

### What's New
- ✅ **Cluster listing** with K8s/KFP versions
- ✅ **Interactive selection** - Choose existing or create new
- ✅ **Multi-environment support** - Dev, QA, Prod
- ✅ **Custom naming** - Name your clusters
- ✅ **Version visibility** - See versions before selection
- ✅ **8-step wizard** - Added cluster selection step

### Files Changed
- ✅ **NEW:** `scripts/cluster-list-detailed.sh` - Cluster listing tool
- ✅ **UPDATED:** `install-wizard.sh` - Added cluster selection (Step 3/8)
- ✅ **UPDATED:** Step numbers (now 8 steps instead of 7)

### Benefits
- ✅ **Flexibility** - Multiple clusters, multiple versions
- ✅ **Visibility** - See what's running before choosing
- ✅ **Safety** - Won't overwrite existing clusters
- ✅ **Convenience** - Easy environment management

---

**Status:** ✅ **READY TO USE**

Try it now:
```bash
./install-wizard.sh
```

Create your dev, QA, and prod clusters! 🚀
