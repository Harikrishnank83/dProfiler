---
name: Bug Report
about: Report a bug or unexpected behavior
title: "[BUG] "
labels: bug
assignees: ''
---

## Description
A clear and concise description of the bug.

## Environment
- **K8s version**: [e.g., 1.28.5]
- **Kubeflow version**: [e.g., 2.1.0]
- **Cluster mode**: [single/multi]
- **Component**: [e.g., gbm-trainer, data-loader]
- **Installation mode**: [full/minimal/dev/ci]
- **OS**: [e.g., macOS 14.0, Ubuntu 22.04]

## Steps to Reproduce
1. 
2. 
3. 

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened.

## Logs
```
Paste relevant logs here
```

## Screenshots
If applicable, add screenshots.

## Additional Context
Any other information that might help.

## Checklist
- [ ] I have searched existing issues for duplicates
- [ ] I have included all relevant information
- [ ] I can reproduce this issue
