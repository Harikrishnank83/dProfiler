---
name: Pipeline Issue
about: Report issues with pipeline execution
title: "[PIPELINE] "
labels: pipeline, help wanted
assignees: ''
---

## Pipeline Name
e.g., gbm-training-pipeline

## Issue Type
- [ ] Pipeline won't compile
- [ ] Pipeline fails during execution
- [ ] Unexpected results
- [ ] Performance issue
- [ ] Other

## Pipeline Definition
```python
# Paste your pipeline code or attach .py file
```

## Run Details
- **Run ID**: [from KFP UI, if available]
- **Failed component**: [if applicable]
- **Error message**: 
```
Paste error message here
```

## Component Logs
```
Paste logs from the failing component
```

## What I've Tried
1. 
2. 

## For Data Scientists
If you're not familiar with K8s/Docker, check these boxes:
- [ ] I'm not familiar with K8s/Docker
- [ ] I need help understanding the error message
- [ ] I need step-by-step guidance

## Additional Information
Any other relevant details.
