#!/usr/bin/env bash
# Install prerequisites for Kubeflow Development Environment

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$PROJECT_ROOT/scripts/common.sh"

log_info "Checking and installing dependencies..."

# Check Docker
if command_exists docker; then
    DOCKER_VERSION=$(docker --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)
    log_success "Docker is installed: $DOCKER_VERSION"
else
    log_error "Docker is not installed"
    log_info "Install Docker from: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check if Docker is running
if ! docker info &>/dev/null; then
    log_error "Docker is not running. Please start Docker and try again."
    exit 1
fi

# Check k3d
if command_exists k3d; then
    K3D_VERSION=$(k3d version | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' | head -1)
    log_success "k3d is installed: $K3D_VERSION"
else
    log_info "Installing k3d..."
    curl -s https://raw.githubusercontent.com/k3d-io/k3d/main/install.sh | bash
    log_success "k3d installed"
fi

# Check kubectl
if command_exists kubectl; then
    KUBECTL_VERSION=$(kubectl version --client -o json 2>/dev/null | grep -oE '"gitVersion": "[^"]+"' | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+')
    log_success "kubectl is installed: $KUBECTL_VERSION"
else
    log_info "Installing kubectl..."
    if [[ "$(uname)" == "Darwin" ]]; then
        brew install kubectl
    else
        curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
        chmod +x kubectl
        sudo mv kubectl /usr/local/bin/
    fi
    log_success "kubectl installed"
fi

# Check Helm
if command_exists helm; then
    HELM_VERSION=$(helm version --short | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+')
    log_success "Helm is installed: $HELM_VERSION"
else
    log_info "Installing Helm..."
    curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
    log_success "Helm installed"
fi

# Check yq
if command_exists yq; then
    YQ_VERSION=$(yq --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')
    log_success "yq is installed: $YQ_VERSION"
else
    log_info "Installing yq..."
    if [[ "$(uname)" == "Darwin" ]]; then
        brew install yq
    else
        sudo wget -qO /usr/local/bin/yq https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64
        sudo chmod +x /usr/local/bin/yq
    fi
    log_success "yq installed"
fi

log_success "All dependencies are installed!"
