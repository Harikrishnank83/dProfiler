#!/usr/bin/env bash
# Verify Kubeflow Development Environment installation

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$PROJECT_ROOT/scripts/common.sh"

FAILED=0

print_header "Verifying Installation"

# Check Docker
log_info "Checking Docker..."
if docker info &>/dev/null; then
    log_success "Docker is running"
else
    log_error "Docker is not running"
    FAILED=1
fi

# Check k3d
log_info "Checking k3d..."
if k3d version &>/dev/null; then
    log_success "k3d is installed"
else
    log_error "k3d is not installed"
    FAILED=1
fi

# Check kubectl
log_info "Checking kubectl..."
if kubectl version --client &>/dev/null; then
    log_success "kubectl is installed"
else
    log_error "kubectl is not installed"
    FAILED=1
fi

# Check cluster
log_info "Checking cluster connection..."
if kubectl cluster-info &>/dev/null; then
    log_success "Cluster is accessible"
    
    # Check Kubeflow namespace
    log_info "Checking Kubeflow namespace..."
    if kubectl get namespace kubeflow &>/dev/null; then
        log_success "Kubeflow namespace exists"
        
        # Check KFP pods
        log_info "Checking Kubeflow Pipelines pods..."
        RUNNING_PODS=$(kubectl get pods -n kubeflow -o jsonpath='{.items[?(@.status.phase=="Running")].metadata.name}' | wc -w)
        if [[ $RUNNING_PODS -gt 0 ]]; then
            log_success "$RUNNING_PODS pods running in kubeflow namespace"
        else
            log_warning "No running pods in kubeflow namespace"
        fi
    else
        log_warning "Kubeflow namespace not found"
    fi
else
    log_warning "Cluster is not accessible (may not be created yet)"
fi

# Check registry
log_info "Checking local registry..."
REGISTRY_NAME=$(yq '.cluster.registry.name // "kfp-dev-registry"' "$PROJECT_ROOT/config/cluster-state.yaml" 2>/dev/null || echo "kfp-dev-registry")
if docker ps | grep -q "$REGISTRY_NAME"; then
    log_success "Local registry is running"
else
    log_warning "Local registry not found (may start with cluster)"
fi

# Summary
echo ""
if [[ $FAILED -eq 0 ]]; then
    log_success "All verification checks passed!"
    exit 0
else
    log_error "Some verification checks failed"
    exit 1
fi
