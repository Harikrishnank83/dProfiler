#!/usr/bin/env bash
# Install development tools

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$PROJECT_ROOT/scripts/common.sh"

log_info "Setting up development tools..."

# Create Python virtual environment
VENV_DIR="$PROJECT_ROOT/.venv"
if [[ ! -d "$VENV_DIR" ]]; then
    log_info "Creating Python virtual environment..."
    python3 -m venv "$VENV_DIR"
fi

# Activate venv and install dependencies
log_info "Installing Python dependencies..."
source "$VENV_DIR/bin/activate"
pip install --upgrade pip
pip install -r "$PROJECT_ROOT/dev/requirements.txt"
pip install -r "$PROJECT_ROOT/dev/requirements-test.txt"

# Install pre-commit hooks
if command_exists pre-commit; then
    log_info "Installing pre-commit hooks..."
    cd "$PROJECT_ROOT"
    pre-commit install
fi

log_success "Development tools installed!"
echo ""
echo "Activate the virtual environment with:"
echo "  source $VENV_DIR/bin/activate"
