#!/usr/bin/env bash
# Uninstall Kubeflow Development Environment
# Usage: ./uninstall.sh [--purge]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/scripts/common.sh"

PURGE="false"

while [[ $# -gt 0 ]]; do
    case $1 in
        --purge)
            PURGE="true"
            shift
            ;;
        --help|-h)
            echo "Uninstall Kubeflow Development Environment"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --purge    Also remove data volumes and caches"
            echo "  --help     Show this help"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

print_header "Uninstalling Kubeflow Development Environment"

log_warning "This will remove the Kubeflow development environment."
if [[ "$PURGE" == "true" ]]; then
    log_warning "Data volumes will also be deleted (--purge)"
fi
echo ""

if ! confirm "Are you sure you want to continue?"; then
    log_info "Aborted"
    exit 0
fi

# Destroy cluster
log_step "Destroying cluster..."
"$SCRIPT_DIR/scripts/cluster-destroy.sh" --force || true

# Clean up generated files
log_step "Cleaning up generated files..."
rm -rf "$SCRIPT_DIR/.generated"
rm -rf "$SCRIPT_DIR/config/cluster-state.yaml"

# Clean build cache
log_step "Cleaning build cache..."
rm -rf "$SCRIPT_DIR/build/.buildcache"

# Clean test artifacts
log_step "Cleaning test artifacts..."
rm -rf "$SCRIPT_DIR/tests/python/.pytest_cache"
rm -rf "$SCRIPT_DIR/tests/python/htmlcov"

# Purge data if requested
if [[ "$PURGE" == "true" ]]; then
    log_step "Purging data volumes..."
    rm -rf "$SCRIPT_DIR/data/artifacts"/*
    rm -rf "$SCRIPT_DIR/data/minio"/*
    rm -rf "$SCRIPT_DIR/.snapshots"
    rm -rf "$SCRIPT_DIR/.backups"
    rm -rf "$SCRIPT_DIR/exports"
fi

log_success "Uninstallation complete!"
