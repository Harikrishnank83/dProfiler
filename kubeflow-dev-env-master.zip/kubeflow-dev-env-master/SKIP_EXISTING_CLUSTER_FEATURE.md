# Skip Existing Cluster Feature

**Date:** February 2, 2026  
**Feature:** `--skip-existing` flag for cluster creation  
**Status:** ✅ **IMPLEMENTED**

---

## 🎯 Problem

### User Experience Issue
When running the wizard or cluster creation script multiple times:

```bash
./scripts/cluster-create.sh --k8s 1.28.5 --kfp 2.1.0
```

**Error:**
```
[ERROR] Cluster 'kfp-dev' already exists. Use cluster-destroy.sh first or choose a different name.
```

**Impact:**
- ❌ **Workflow interrupted** - User must manually destroy cluster
- ❌ **Data loss risk** - Destroying cluster removes all work
- ❌ **Poor UX** - Extra steps required for re-running setup
- ❌ **Not idempotent** - Can't safely re-run scripts

---

## ✅ Solution

### New Flag: `--skip-existing`

Added a new flag that makes cluster creation **idempotent** - it can be safely run multiple times.

**Behavior with `--skip-existing`:**
1. ✅ Checks if cluster exists
2. ✅ If exists: Switches to existing cluster context and exits successfully
3. ✅ If not exists: Creates new cluster as normal

---

## 🚀 Usage

### Option 1: Direct Script Usage

```bash
# Create cluster (or use existing)
./scripts/cluster-create.sh \
    --k8s 1.28.5 \
    --kfp 2.1.0 \
    --skip-existing
```

**Output when cluster exists:**
```
[WARNING] Cluster 'kfp-dev' already exists. Skipping creation (--skip-existing).
[INFO] Switching to existing cluster context...
[SUCCESS] Using existing cluster: kfp-dev
```

**Output when cluster doesn't exist:**
```
[INFO] Creating K3d cluster: kfp-dev
[INFO] Cluster created successfully
...
```

### Option 2: Wizard (Automatic)

The wizard now **automatically** uses `--skip-existing` flag:

```bash
./install-wizard.sh
```

**Benefits:**
- ✅ Re-running wizard is safe
- ✅ Won't fail if cluster exists
- ✅ Won't destroy existing work
- ✅ Idempotent installation

---

## 📖 Complete Usage Examples

### Example 1: First Time Setup

```bash
# First run - creates cluster
./scripts/cluster-create.sh --k8s 1.28.5 --kfp 2.1.0 --skip-existing

# Output:
# [INFO] Creating K3d cluster: kfp-dev
# [SUCCESS] Cluster created successfully
```

### Example 2: Re-run (Cluster Exists)

```bash
# Second run - uses existing
./scripts/cluster-create.sh --k8s 1.28.5 --kfp 2.1.0 --skip-existing

# Output:
# [WARNING] Cluster 'kfp-dev' already exists. Skipping creation (--skip-existing).
# [SUCCESS] Using existing cluster: kfp-dev
```

### Example 3: Without Flag (Old Behavior)

```bash
# Without flag - fails if exists (backward compatible)
./scripts/cluster-create.sh --k8s 1.28.5 --kfp 2.1.0

# Output if cluster exists:
# [ERROR] Cluster 'kfp-dev' already exists.
# [ERROR] Options:
# [ERROR]   1. Use --skip-existing flag to use the existing cluster
# [ERROR]   2. Run: ./scripts/cluster-destroy.sh --name kfp-dev
# [ERROR]   3. Choose a different name with: --name <new-name>
```

### Example 4: Custom Cluster Name

```bash
# Create with custom name
./scripts/cluster-create.sh \
    --k8s 1.28.5 \
    --kfp 2.1.0 \
    --name my-cluster \
    --skip-existing

# Re-run is safe
./scripts/cluster-create.sh \
    --k8s 1.28.5 \
    --kfp 2.1.0 \
    --name my-cluster \
    --skip-existing
```

### Example 5: Wizard Integration

```bash
# Wizard automatically uses --skip-existing
./install-wizard.sh

# Select mode: Full (or any mode)
# If cluster exists: Uses existing cluster
# If cluster doesn't exist: Creates new cluster
# Either way: Installation proceeds successfully
```

---

## 🔧 Implementation Details

### Changes in `scripts/cluster-create.sh`

#### 1. Added Flag Definition
```bash
# Default values
SKIP_EXISTING="false"
```

#### 2. Added Flag Parsing
```bash
--skip-existing)
    SKIP_EXISTING="true"
    shift
    ;;
```

#### 3. Updated Help Text
```bash
echo "  --skip-existing      Skip if cluster already exists (use existing)"
```

#### 4. Enhanced Cluster Check Logic
```bash
# Check if cluster already exists
if k3d cluster list 2>/dev/null | grep -q "^$CLUSTER_NAME "; then
    if [[ "$SKIP_EXISTING" == "true" ]]; then
        log_warning "Cluster '$CLUSTER_NAME' already exists. Skipping creation (--skip-existing)."
        log_info "Switching to existing cluster context..."
        kubectl config use-context "k3d-$CLUSTER_NAME" 2>/dev/null || true
        log_success "Using existing cluster: $CLUSTER_NAME"
        exit 0
    else
        log_error "Cluster '$CLUSTER_NAME' already exists."
        log_error "Options:"
        log_error "  1. Use --skip-existing flag to use the existing cluster"
        log_error "  2. Run: ./scripts/cluster-destroy.sh --name $CLUSTER_NAME"
        log_error "  3. Choose a different name with: --name <new-name>"
        exit 1
    fi
fi
```

### Changes in `install-wizard.sh`

#### Updated Cluster Creation Call
```bash
"create-cluster")
    echo ""
    "$SCRIPT_DIR/scripts/cluster-create.sh" \
        --k8s "$K8S_VERSION" \
        --kfp "$KFP_VERSION" \
        --skip-kfp \
        --skip-existing  # ← Added this flag
    ;;
```

---

## 🎯 Use Cases

### Use Case 1: Development Iteration
**Scenario:** Developer testing wizard improvements

```bash
# First run
./install-wizard.sh  # Creates cluster

# Make changes to code...

# Second run - uses existing cluster (no need to destroy)
./install-wizard.sh  # ✅ Works! Uses existing cluster
```

### Use Case 2: Partial Installation Recovery
**Scenario:** Installation failed midway, want to retry

```bash
./install-wizard.sh
# Installation fails at KFP installation step
# Cluster was created successfully

# Retry - cluster already exists
./install-wizard.sh  # ✅ Skips cluster creation, continues
```

### Use Case 3: CI/CD Pipeline
**Scenario:** Automated testing environment

```bash
#!/bin/bash
# CI script can be idempotent
./scripts/cluster-create.sh --skip-existing
./scripts/install-kubeflow.sh
# Run tests...
```

### Use Case 4: Multi-Stage Setup
**Scenario:** User wants to install in stages

```bash
# Day 1: Create cluster only
./scripts/cluster-create.sh --k8s 1.28.5 --skip-existing --skip-kfp

# Day 2: Add Kubeflow (cluster already exists)
./scripts/cluster-create.sh --k8s 1.28.5 --skip-existing  # ✅ Skips
./scripts/install-kubeflow.sh

# Day 3: Add operators (cluster already exists)
./scripts/cluster-create.sh --k8s 1.28.5 --skip-existing  # ✅ Skips
./scripts/install-operators.sh --dask --ray
```

---

## 📊 Comparison: Before vs After

| Scenario | Before (Without Flag) | After (With `--skip-existing`) |
|----------|----------------------|-------------------------------|
| **First run** | ✅ Creates cluster | ✅ Creates cluster |
| **Second run** | ❌ Error: cluster exists | ✅ Uses existing cluster |
| **Re-run wizard** | ❌ Must destroy cluster first | ✅ Safe to re-run |
| **Partial failure recovery** | ❌ Complex manual steps | ✅ Just re-run |
| **CI/CD** | ❌ Not idempotent | ✅ Idempotent |
| **Data preservation** | ❌ Risk of data loss | ✅ Preserves existing work |

---

## 🛡️ Safety & Best Practices

### What Gets Preserved
When using `--skip-existing`, the following are **preserved**:
- ✅ Existing cluster and all resources
- ✅ Deployed applications (Kubeflow, operators, etc.)
- ✅ User workloads and data
- ✅ Cluster configuration
- ✅ Kubernetes context

### What Gets Switched
- ✅ kubectl context switched to existing cluster
- ✅ Script exits successfully (exit code 0)
- ✅ No new resources created

### When NOT to Use `--skip-existing`

**Scenario 1: Want to recreate cluster**
```bash
# Don't use --skip-existing if you want a fresh cluster
./scripts/cluster-destroy.sh
./scripts/cluster-create.sh --k8s 1.28.5
```

**Scenario 2: Cluster is corrupted**
```bash
# Destroy and recreate
./scripts/cluster-destroy.sh --name kfp-dev
./scripts/cluster-create.sh --k8s 1.28.5
```

**Scenario 3: Different versions**
```bash
# Cluster exists with K8s 1.26, want K8s 1.28
# Must destroy and recreate
./scripts/cluster-destroy.sh
./scripts/cluster-create.sh --k8s 1.28.5
```

---

## 🔍 Troubleshooting

### Issue: "Context switch failed"
```bash
[WARNING] Cluster 'kfp-dev' already exists. Skipping creation (--skip-existing).
[INFO] Switching to existing cluster context...
error: context "k3d-kfp-dev" not found
```

**Solution:**
```bash
# Cluster might be stopped or corrupted
k3d cluster list

# If cluster is stopped
k3d cluster start kfp-dev

# If cluster is corrupted
./scripts/cluster-destroy.sh
./scripts/cluster-create.sh
```

### Issue: "Cluster exists but not responding"
**Solution:**
```bash
# Check cluster status
k3d cluster list
kubectl get nodes

# If not responding, restart
k3d cluster stop kfp-dev
k3d cluster start kfp-dev

# Or recreate
./scripts/cluster-destroy.sh
./scripts/cluster-create.sh --skip-existing
```

---

## 📝 Help Text

### Updated Help Output

```bash
./scripts/cluster-create.sh --help
```

**Output:**
```
Create a new K3d cluster with Kubeflow Pipelines

Usage: ./scripts/cluster-create.sh [options]

Options:
  --k8s VERSION        Kubernetes version (e.g., 1.28.5)
  --kfp VERSION        Kubeflow Pipelines version (e.g., 2.1.0)
  --mode MODE          Cluster mode: single or multi (default: single)
  --name NAME          Cluster name (default: kfp-dev)
  --registry-port PORT Local registry port (default: 5000)
  --skip-kfp           Skip Kubeflow Pipelines installation
  --skip-existing      Skip if cluster already exists (use existing)  ← NEW
  --dry-run            Print configuration without creating cluster
  --help               Show this help message
```

---

## ✅ Testing

### Test 1: First Run (No Existing Cluster)
```bash
# Ensure no cluster exists
k3d cluster delete kfp-dev 2>/dev/null || true

# Run with flag
./scripts/cluster-create.sh --k8s 1.28.5 --kfp 2.1.0 --skip-existing

# Expected: Creates cluster successfully
# Result: ✅ PASS
```

### Test 2: Second Run (Cluster Exists)
```bash
# Run again with flag
./scripts/cluster-create.sh --k8s 1.28.5 --kfp 2.1.0 --skip-existing

# Expected: Skips creation, uses existing
# Result: ✅ PASS
```

### Test 3: Without Flag (Backward Compatibility)
```bash
# Run without flag (cluster exists)
./scripts/cluster-create.sh --k8s 1.28.5 --kfp 2.1.0

# Expected: Error with helpful message
# Result: ✅ PASS
```

### Test 4: Wizard Integration
```bash
# Run wizard twice
./install-wizard.sh  # First time
./install-wizard.sh  # Second time

# Expected: Second run uses existing cluster
# Result: ✅ PASS
```

---

## 🎉 Summary

### What Was Added
- ✅ New `--skip-existing` flag in `cluster-create.sh`
- ✅ Automatic flag usage in `install-wizard.sh`
- ✅ Improved error messages with 3 clear options
- ✅ Context switching to existing cluster
- ✅ Idempotent cluster creation

### Benefits
- ✅ **Safer re-runs** - Won't destroy existing work
- ✅ **Better UX** - No need to manually destroy clusters
- ✅ **Idempotent** - Can run multiple times safely
- ✅ **CI/CD friendly** - Automated workflows are easier
- ✅ **Backward compatible** - Old behavior preserved without flag

### User Impact
- ✅ **Developers** - Faster iteration cycles
- ✅ **New users** - Less confusing errors
- ✅ **CI/CD** - Reliable automated deployments
- ✅ **Everyone** - Less risk of data loss

---

**Status:** ✅ **READY TO USE**

Try it now:
```bash
./scripts/cluster-create.sh --k8s 1.28.5 --skip-existing
```

Or just run the wizard (it's automatic):
```bash
./install-wizard.sh
```
