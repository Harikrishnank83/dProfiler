#!/usr/bin/env python3
"""
Hyperparameter Tuning Pipeline

Pipeline for hyperparameter search on GBM models.
Based on hw1 Question 2a: varying max_depth for decision trees.
"""

from kfp import dsl
from kfp import compiler
from typing import NamedTuple

REGISTRY = "localhost:5000"


@dsl.component(base_image=f"{REGISTRY}/gbm-trainer:latest")
def train_with_depth(
    input_data: str,
    max_depth: int,
    random_state: int = 10
) -> NamedTuple("Outputs", [
    ("max_depth", int),
    ("train_accuracy", float),
    ("cv_accuracy", float)
]):
    """Train decision tree with specific max_depth."""
    import json
    import numpy as np
    from sklearn import tree
    from sklearn.model_selection import cross_val_score, KFold
    from collections import namedtuple
    
    data = json.loads(input_data)
    X = np.array(data["X_train"])
    y = np.array(data["y_train"])
    
    clf = tree.DecisionTreeClassifier(max_depth=max_depth, random_state=random_state)
    clf.fit(X, y)
    
    train_acc = float(clf.score(X, y))
    
    cv = KFold(n_splits=10, shuffle=True, random_state=random_state)
    cv_scores = cross_val_score(clf, X, y, cv=cv)
    cv_acc = float(cv_scores.mean())
    
    Outputs = namedtuple("Outputs", ["max_depth", "train_accuracy", "cv_accuracy"])
    return Outputs(
        max_depth=max_depth,
        train_accuracy=train_acc,
        cv_accuracy=cv_acc
    )


@dsl.component(base_image="python:3.10-slim")
def find_best_depth(
    results: list
) -> NamedTuple("Outputs", [("best_depth", int), ("best_cv_accuracy", float)]):
    """Find the best max_depth based on CV accuracy."""
    from collections import namedtuple
    
    best_depth = 1
    best_cv = 0.0
    
    for r in results:
        if r["cv_accuracy"] > best_cv:
            best_cv = r["cv_accuracy"]
            best_depth = r["max_depth"]
    
    Outputs = namedtuple("Outputs", ["best_depth", "best_cv_accuracy"])
    return Outputs(best_depth=best_depth, best_cv_accuracy=best_cv)


@dsl.pipeline(
    name="Hyperparameter Tuning Pipeline",
    description="Search for optimal max_depth in decision trees (hw1 Q2a)"
)
def hyperparameter_tuning_pipeline(
    dataset: str = "breast_cancer",
    min_depth: int = 1,
    max_depth: int = 10,
    random_state: int = 10
):
    """
    Hyperparameter tuning for decision tree max_depth.
    
    Based on hw1 Question 2a: varying max_depth from 1 to 10.
    """
    from pipelines import gbm_training_pipeline
    
    # This is a simplified version - in practice you would use
    # Katib for more sophisticated hyperparameter tuning
    pass


def compile_pipeline(output_path: str = "hyperparameter-tuning-pipeline.yaml"):
    """Compile the pipeline to YAML."""
    compiler.Compiler().compile(
        pipeline_func=hyperparameter_tuning_pipeline,
        package_path=output_path
    )
    print(f"Pipeline compiled to: {output_path}")


if __name__ == "__main__":
    compile_pipeline()
