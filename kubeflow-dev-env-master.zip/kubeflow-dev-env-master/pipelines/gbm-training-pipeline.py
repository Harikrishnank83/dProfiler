#!/usr/bin/env python3
"""
GBM Training Pipeline

End-to-end ML pipeline for training and evaluating Gradient Boosting models.
Based on hw1_programming_base_notebook.ipynb from AI391L Machine Learning.

Usage:
    python gbm-training-pipeline.py --compile  # Compile pipeline to YAML
    python gbm-training-pipeline.py --run      # Submit to KFP
"""

import argparse
from typing import NamedTuple

from kfp import dsl
from kfp import compiler
from kfp.dsl import Dataset, Model, Metrics, Artifact

# Registry URL (configurable)
REGISTRY = "localhost:5000"


@dsl.component(
    base_image=f"{REGISTRY}/data-loader:latest",
    packages_to_install=[]
)
def load_data(
    dataset: str = "breast_cancer",
    test_size: float = 0.2,
    random_state: int = 10
) -> NamedTuple("Outputs", [
    ("output_data", Dataset),
    ("metadata", Artifact),
    ("n_samples", int),
    ("n_features", int)
]):
    """Load and split dataset."""
    import json
    import numpy as np
    from pathlib import Path
    from sklearn.datasets import load_breast_cancer
    from sklearn.model_selection import train_test_split
    from collections import namedtuple
    
    # Load data
    if dataset == "breast_cancer":
        data = load_breast_cancer()
        X, y = data.data, data.target
        feature_names = list(data.feature_names)
        target_names = list(data.target_names)
    else:
        raise ValueError(f"Unknown dataset: {dataset}")
    
    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    
    # Compute base rate (hw1 Question 1)
    malignant_rate = float(np.sum(y == 0) / len(y))
    
    # Save data
    output_data = {
        "X_train": X_train.tolist(),
        "X_test": X_test.tolist(),
        "y_train": y_train.tolist(),
        "y_test": y_test.tolist(),
        "feature_names": feature_names,
        "target_names": target_names
    }
    
    metadata = {
        "dataset": dataset,
        "n_samples": len(y),
        "n_features": len(feature_names),
        "train_size": len(y_train),
        "test_size": len(y_test),
        "base_rate_malignant": malignant_rate
    }
    
    Outputs = namedtuple("Outputs", ["output_data", "metadata", "n_samples", "n_features"])
    return Outputs(
        output_data=json.dumps(output_data),
        metadata=json.dumps(metadata),
        n_samples=len(y),
        n_features=len(feature_names)
    )


@dsl.component(
    base_image=f"{REGISTRY}/gbm-trainer:latest",
    packages_to_install=[]
)
def train_model(
    input_data: Dataset,
    model_type: str = "gradient_boosting",
    n_estimators: int = 100,
    max_depth: int = 5,
    learning_rate: float = 0.1,
    random_state: int = 10
) -> NamedTuple("Outputs", [
    ("model", Model),
    ("train_accuracy", float),
    ("test_accuracy", float),
    ("cv_accuracy", float)
]):
    """Train a gradient boosting model."""
    import json
    import pickle
    import numpy as np
    from sklearn import tree, ensemble
    from sklearn.model_selection import cross_val_score, KFold
    from collections import namedtuple
    
    # Load data
    data = json.loads(input_data)
    X_train = np.array(data["X_train"])
    X_test = np.array(data["X_test"])
    y_train = np.array(data["y_train"])
    y_test = np.array(data["y_test"])
    
    # Select model
    if model_type == "decision_tree":
        model = tree.DecisionTreeClassifier(
            max_depth=max_depth,
            random_state=random_state
        )
    elif model_type == "random_forest":
        model = ensemble.RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=random_state
        )
    elif model_type == "gradient_boosting":
        model = ensemble.GradientBoostingClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            random_state=random_state
        )
    else:
        raise ValueError(f"Unknown model type: {model_type}")
    
    # Train
    model.fit(X_train, y_train)
    
    # Evaluate
    train_acc = float(model.score(X_train, y_train))
    test_acc = float(model.score(X_test, y_test))
    
    # Cross-validation
    cv = KFold(n_splits=10, shuffle=True, random_state=random_state)
    cv_scores = cross_val_score(model, X_train, y_train, cv=cv)
    cv_acc = float(cv_scores.mean())
    
    # Serialize model
    model_bytes = pickle.dumps(model)
    
    Outputs = namedtuple("Outputs", ["model", "train_accuracy", "test_accuracy", "cv_accuracy"])
    return Outputs(
        model=model_bytes,
        train_accuracy=train_acc,
        test_accuracy=test_acc,
        cv_accuracy=cv_acc
    )


@dsl.component(
    base_image=f"{REGISTRY}/evaluator:latest",
    packages_to_install=[]
)
def evaluate_model(
    model: Model,
    input_data: Dataset
) -> NamedTuple("Outputs", [
    ("accuracy", float),
    ("f1_score", float),
    ("evaluation_report", Artifact)
]):
    """Evaluate trained model."""
    import json
    import pickle
    import numpy as np
    from sklearn.metrics import accuracy_score, f1_score, classification_report
    from collections import namedtuple
    
    # Load model and data
    clf = pickle.loads(model)
    data = json.loads(input_data)
    
    X_test = np.array(data["X_test"])
    y_test = np.array(data["y_test"])
    
    # Predict
    y_pred = clf.predict(X_test)
    
    # Metrics
    acc = float(accuracy_score(y_test, y_pred))
    f1 = float(f1_score(y_test, y_pred, average='weighted'))
    
    # Report
    report = classification_report(y_test, y_pred, output_dict=True)
    
    Outputs = namedtuple("Outputs", ["accuracy", "f1_score", "evaluation_report"])
    return Outputs(
        accuracy=acc,
        f1_score=f1,
        evaluation_report=json.dumps(report)
    )


@dsl.pipeline(
    name="GBM Training Pipeline",
    description="Train and evaluate Gradient Boosting models on breast cancer dataset"
)
def gbm_training_pipeline(
    dataset: str = "breast_cancer",
    model_type: str = "gradient_boosting",
    n_estimators: int = 100,
    max_depth: int = 5,
    learning_rate: float = 0.1,
    test_size: float = 0.2,
    random_state: int = 10
):
    """
    GBM Training Pipeline.
    
    This pipeline:
    1. Loads the breast cancer dataset
    2. Trains a gradient boosting model
    3. Evaluates the model
    
    Based on hw1_programming_base_notebook.ipynb from AI391L.
    """
    
    # Step 1: Load data
    load_task = load_data(
        dataset=dataset,
        test_size=test_size,
        random_state=random_state
    )
    load_task.set_display_name("Load Dataset")
    
    # Step 2: Train model
    train_task = train_model(
        input_data=load_task.outputs["output_data"],
        model_type=model_type,
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=random_state
    )
    train_task.set_display_name("Train Model")
    train_task.after(load_task)
    
    # Step 3: Evaluate model
    eval_task = evaluate_model(
        model=train_task.outputs["model"],
        input_data=load_task.outputs["output_data"]
    )
    eval_task.set_display_name("Evaluate Model")
    eval_task.after(train_task)


@dsl.pipeline(
    name="Model Comparison Pipeline",
    description="Compare multiple model types on the same dataset"
)
def model_comparison_pipeline(
    dataset: str = "breast_cancer",
    test_size: float = 0.2,
    random_state: int = 10
):
    """
    Compare different model types.
    
    This pipeline trains and evaluates:
    - Decision Tree
    - Random Forest
    - Gradient Boosting
    """
    
    # Load data once
    load_task = load_data(
        dataset=dataset,
        test_size=test_size,
        random_state=random_state
    )
    
    model_types = ["decision_tree", "random_forest", "gradient_boosting"]
    
    for model_type in model_types:
        # Train
        train_task = train_model(
            input_data=load_task.outputs["output_data"],
            model_type=model_type,
            random_state=random_state
        )
        train_task.set_display_name(f"Train {model_type}")
        
        # Evaluate
        eval_task = evaluate_model(
            model=train_task.outputs["model"],
            input_data=load_task.outputs["output_data"]
        )
        eval_task.set_display_name(f"Evaluate {model_type}")


def compile_pipeline(output_path: str = "gbm-training-pipeline.yaml"):
    """Compile the pipeline to YAML."""
    compiler.Compiler().compile(
        pipeline_func=gbm_training_pipeline,
        package_path=output_path
    )
    print(f"Pipeline compiled to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="GBM Training Pipeline")
    parser.add_argument("--compile", action="store_true",
                        help="Compile pipeline to YAML")
    parser.add_argument("--output", type=str, default="gbm-training-pipeline.yaml",
                        help="Output path for compiled pipeline")
    parser.add_argument("--run", action="store_true",
                        help="Submit pipeline to KFP (requires running cluster)")
    parser.add_argument("--host", type=str, default="http://localhost:8080",
                        help="KFP host URL")
    
    args = parser.parse_args()
    
    if args.compile:
        compile_pipeline(args.output)
    elif args.run:
        import kfp
        client = kfp.Client(host=args.host)
        run = client.create_run_from_pipeline_func(
            gbm_training_pipeline,
            arguments={
                "dataset": "breast_cancer",
                "model_type": "gradient_boosting",
                "n_estimators": 100,
                "max_depth": 5,
                "learning_rate": 0.1
            }
        )
        print(f"Pipeline run submitted: {run.run_id}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
