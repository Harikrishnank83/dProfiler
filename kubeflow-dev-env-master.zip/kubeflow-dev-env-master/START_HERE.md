# 🎯 START HERE - Kubeflow Development Environment

Welcome! This guide will get you from zero to running ML pipelines in **5-10 minutes**.

---

## 🚦 Your Current Status

```
✅ Docker       - Installed (needs to be started)
✅ k3d          - Installed
✅ kubectl      - Installed
✅ Helm         - Installed
✅ Python 3     - Installed

📊 System Ready: 95%
⏱️  Installation Time: 5-10 minutes (vs typical 20-30 min)
```

---

## ⚡ Quick Start (4 Steps)

### Step 0: Check Resources (Optional, 10 seconds)

```bash
./scripts/check-resources.sh
```

**Requirements:**
- 10GB+ free disk space (20GB+ recommended)
- 4GB+ Docker memory (8GB+ recommended)
- Downloads: ~1.6GB (minimal) or ~3.5GB (full)

📖 **Details:** See [docs/DOCKER_IMAGES_AND_RESOURCES.md](docs/DOCKER_IMAGES_AND_RESOURCES.md)

### Step 1: Start Docker (30 seconds)

```bash
open -a Docker
```

Wait ~30 seconds, then verify:
```bash
docker info
```

### Step 2: Run the Wizard (5-10 minutes)

**The wizard shows resource information automatically!**

```bash
./install-wizard.sh
```

**Interactive help available!** Type `help` at any prompt for detailed information.

When prompted:
- **Mode:** Select "Dev" (option 2) ⭐ or "API-Only" (option 4) for no UI
  - Not sure? Type `help` to see detailed mode descriptions
- **K8s:** Press Enter for default (1.28.5)
- **KFP:** Press Enter for default (2.1.0)
  - Need version info? Type `help` for compatibility matrix
- **Tips:** 
  - Type `help` or `?` for context-specific help
  - Type `exit` or `q` to quit at any time

### Step 3: Access & Test (1 minute)

```bash
# Start port forwarding
make port-forward

# Open in browser
open http://localhost:8080

# Deploy your first pipeline
make deploy-pipeline PIPELINE=gbm-training
```

---

## 🎉 That's It!

You should now have:
- ✅ Kubernetes cluster running
- ✅ Kubeflow Pipelines deployed
- ✅ UI accessible at localhost:8080
- ✅ First pipeline deployed

---

## 📚 What to Read Next

### New Users
1. **First:** `WIZARD_QUICKSTART.md` - How to use the wizard
2. **Then:** `docs/USER_GUIDE.md` - Complete user guide
3. **Finally:** `docs/FAQ.md` - Common questions

### Experienced Users
1. **Overview:** `DRY_RUN_SUMMARY.md` - Executive summary
2. **Details:** `SETUP_EVALUATION.md` - Complete evaluation
3. **Reference:** `README.md` - Project overview

### Troubleshooting
1. **Visual Status:** `SYSTEM_STATUS.md`
2. **Common Issues:** `docs/TROUBLESHOOTING.md`
3. **Run Diagnostics:** `./scripts/diagnose.sh`

---

## 🎨 Installation Options

### Option 1: Wizard (Recommended) ⭐
```bash
./install-wizard.sh
```
- Interactive
- Detects installed tools
- Step-by-step guidance
- Perfect for first-time users

### Option 2: Dry Run First
```bash
./install-wizard.sh --dry-run
```
- See what would happen
- No changes made
- Good for planning

### Option 3: Traditional
```bash
./install.sh --mode dev --k8s 1.28.5 --kfp 2.1.0
```
- One command
- Good for automation
- Familiar to existing users

### Option 4: Non-Interactive
```bash
./install-wizard.sh --non-interactive
```
- Uses defaults
- Perfect for CI/CD

---

## 🔧 Helpful Commands

### Before Installation
```bash
# Check what's installed
which docker k3d kubectl helm python3

# Check Docker status
docker info

# See existing clusters
k3d cluster list
```

### During Installation
```bash
# Watch the installation (in another terminal)
watch kubectl get pods -n kubeflow
```

### After Installation
```bash
# Check status
./scripts/diagnose.sh

# View all pods
kubectl get pods --all-namespaces

# Access UI
make port-forward

# See all make commands
make help
```

---

## ⚠️ Quick Troubleshooting

### Docker Not Running
```bash
open -a Docker
sleep 30
docker info
```

### Port 5000 in Use (macOS)
```
System Settings > General > AirDrop & Handoff
Disable: AirPlay Receiver
```

### Not Enough Memory
```
Docker Desktop > Settings > Resources
Set Memory to 8GB
Apply & Restart
```

### More Help
```bash
./scripts/diagnose.sh
```

---

## 📖 Complete Documentation Index

### Quick Start Guides
- `START_HERE.md` ← You are here
- `WIZARD_QUICKSTART.md` - Wizard usage guide
- `docs/QUICKSTART.md` - 5-minute quickstart

### Status & Reports
- `SYSTEM_STATUS.md` - Visual system status
- `DRY_RUN_SUMMARY.md` - Dry run executive summary
- `SETUP_EVALUATION.md` - Complete evaluation

### User Documentation
- `README.md` - Project overview
- `docs/USER_GUIDE.md` - Complete user guide
- `docs/FAQ.md` - Frequently asked questions
- `docs/TROUBLESHOOTING.md` - Problem solving
- `docs/GLOSSARY.md` - Kubernetes terminology
- `CONTRIBUTING.md` - How to contribute

### Architecture & Design
- `docs/UNIFIED_GBM_ARCHITECTURE.md` - GBM architecture

### Tools & Scripts
- `install-wizard.sh` - New intelligent wizard
- `install.sh` - Traditional installer
- `scripts/diagnose.sh` - System diagnostics
- `scripts/preflight-check.sh` - Pre-install checks
- `Makefile` - Common commands

---

## 🎯 Recommended Learning Path

### Day 1: Setup & Basics
1. Run the wizard (`./install-wizard.sh`)
2. Access the UI (`make port-forward`)
3. Deploy GBM pipeline (`make deploy-pipeline PIPELINE=gbm-training`)
4. Read `docs/USER_GUIDE.md`

### Day 2: Build Components
1. Explore components (`components/`)
2. Build custom component (`make build-all`)
3. Review component template (`components/component-template/`)
4. Read component docs

### Day 3: Create Pipelines
1. Study example pipelines (`pipelines/`)
2. Create your own pipeline
3. Deploy and test
4. Review pipeline patterns

### Week 2: Advanced Topics
1. Add operators (Dask, Ray)
2. Explore version management
3. Cluster operations
4. Testing framework

---

## 💡 Pro Tips

1. **Use Dev Mode:** Best balance of features and installation time
2. **Keep Docker Running:** Save startup time for future work
3. **Bookmark localhost:8080:** You'll use it a lot
4. **Learn Make Commands:** Run `make help` to see all options
5. **Join Workspace:** Save your progress for later

---

## 🚀 Ready? Let's Go!

1. Start Docker: `open -a Docker`
2. Run wizard: `./install-wizard.sh`
3. Build something awesome! 🎉

```bash
open -a Docker && sleep 30 && ./install-wizard.sh
```

---

## ❓ Questions?

- **Installation:** See `WIZARD_QUICKSTART.md`
- **Usage:** See `docs/USER_GUIDE.md`
- **Problems:** See `docs/TROUBLESHOOTING.md`
- **Concepts:** See `docs/GLOSSARY.md`
- **Diagnostics:** Run `./scripts/diagnose.sh`

---

**Made with ❤️ for ML Engineers and Data Scientists**

*Your system is ready. Time to build amazing ML pipelines!* 🚀
