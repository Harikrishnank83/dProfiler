"""
Local Pipeline Runner

Run pipelines locally without Kubernetes for rapid development and testing.
"""

import json
import tempfile
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class StepResult:
    """Result of a pipeline step."""
    name: str
    success: bool
    outputs: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    duration_ms: float = 0
    error: Optional[str] = None


@dataclass
class PipelineResult:
    """Result of a pipeline run."""
    success: bool
    steps: List[StepResult] = field(default_factory=list)
    total_duration_ms: float = 0
    error: Optional[str] = None
    
    def get_step(self, name: str) -> Optional[StepResult]:
        """Get a step result by name."""
        for step in self.steps:
            if step.name == name:
                return step
        return None
    
    def get_final_outputs(self) -> Dict[str, Any]:
        """Get outputs from the last step."""
        if self.steps:
            return self.steps[-1].outputs
        return {}


class LocalPipelineRunner:
    """
    Run pipelines locally for testing.
    
    This runner executes pipeline steps sequentially in Python,
    simulating how they would run on Kubeflow but without the overhead.
    
    Usage:
        runner = LocalPipelineRunner()
        result = runner.run(
            steps=[
                ("load_data", load_data_func, {"dataset": "breast_cancer"}),
                ("train_model", train_func, {"model_type": "gradient_boosting"}),
                ("evaluate", evaluate_func, {})
            ]
        )
    """
    
    def __init__(self, work_dir: Path = None):
        self.work_dir = work_dir or Path(tempfile.mkdtemp())
        self.artifacts: Dict[str, Any] = {}
        self.results: List[StepResult] = []
    
    def run(
        self,
        steps: List[tuple],
        initial_inputs: Dict[str, Any] = None
    ) -> PipelineResult:
        """
        Run a pipeline locally.
        
        Args:
            steps: List of (name, function, inputs) tuples
            initial_inputs: Initial inputs available to all steps
            
        Returns:
            PipelineResult with all step results
        """
        start_time = datetime.now()
        self.artifacts = initial_inputs or {}
        self.results = []
        
        for step_name, step_func, step_inputs in steps:
            step_result = self._run_step(step_name, step_func, step_inputs)
            self.results.append(step_result)
            
            if not step_result.success:
                return PipelineResult(
                    success=False,
                    steps=self.results,
                    total_duration_ms=self._ms_since(start_time),
                    error=f"Step '{step_name}' failed: {step_result.error}"
                )
            
            # Store outputs for subsequent steps
            self.artifacts.update(step_result.outputs)
        
        return PipelineResult(
            success=True,
            steps=self.results,
            total_duration_ms=self._ms_since(start_time)
        )
    
    def _run_step(
        self,
        name: str,
        func: Callable,
        inputs: Dict[str, Any]
    ) -> StepResult:
        """Run a single step."""
        start_time = datetime.now()
        
        try:
            # Merge inputs with available artifacts
            all_inputs = {}
            
            # Check if function expects any artifacts
            import inspect
            sig = inspect.signature(func)
            for param_name in sig.parameters:
                if param_name in inputs:
                    all_inputs[param_name] = inputs[param_name]
                elif param_name in self.artifacts:
                    all_inputs[param_name] = self.artifacts[param_name]
            
            # Execute function
            result = func(**all_inputs)
            
            # Parse result
            outputs = {}
            metrics = {}
            
            if hasattr(result, "_asdict"):
                outputs = result._asdict()
            elif isinstance(result, dict):
                outputs = result
            elif result is not None:
                outputs = {"result": result}
            
            # Extract numeric values as metrics
            for key, value in outputs.items():
                if isinstance(value, (int, float)):
                    metrics[key] = float(value)
            
            return StepResult(
                name=name,
                success=True,
                outputs=outputs,
                metrics=metrics,
                duration_ms=self._ms_since(start_time)
            )
            
        except Exception as e:
            return StepResult(
                name=name,
                success=False,
                duration_ms=self._ms_since(start_time),
                error=str(e)
            )
    
    def _ms_since(self, start: datetime) -> float:
        """Calculate milliseconds since start time."""
        return (datetime.now() - start).total_seconds() * 1000
    
    def get_artifact(self, name: str) -> Optional[Any]:
        """Get an artifact by name."""
        return self.artifacts.get(name)
    
    def save_artifacts(self, output_dir: Path = None):
        """Save all artifacts to disk."""
        output_dir = output_dir or self.work_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        
        for name, value in self.artifacts.items():
            output_path = output_dir / f"{name}.json"
            with open(output_path, "w") as f:
                if isinstance(value, (dict, list)):
                    json.dump(value, f, indent=2)
                else:
                    json.dump({"value": str(value)}, f)
        
        return output_dir


def run_pipeline_locally(
    pipeline_func: Callable,
    arguments: Dict[str, Any] = None
) -> PipelineResult:
    """
    Convenience function to run a KFP pipeline locally.
    
    Note: This only works with simple pipelines. Complex DAGs
    may not execute correctly.
    """
    runner = LocalPipelineRunner()
    
    # For simple testing, just call the pipeline function
    # This won't execute the actual steps but can validate structure
    try:
        result = pipeline_func(**(arguments or {}))
        return PipelineResult(success=True)
    except Exception as e:
        return PipelineResult(success=False, error=str(e))
