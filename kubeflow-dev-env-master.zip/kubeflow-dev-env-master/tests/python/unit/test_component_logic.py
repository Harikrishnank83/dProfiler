"""
Unit tests for component logic without Docker or cluster.

These tests validate the core logic of each component.
"""

import json
import numpy as np
import pytest
import sys
from pathlib import Path

# Add component directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "components" / "data-loader" / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "components" / "gbm-trainer" / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "components" / "evaluator" / "src"))


class TestDataLoaderLogic:
    """Tests for data loader component logic."""
    
    def test_load_breast_cancer_data(self):
        """Test that breast cancer data loads correctly."""
        from sklearn.datasets import load_breast_cancer
        
        data = load_breast_cancer()
        assert data.data.shape[0] == 569
        assert data.data.shape[1] == 30
        assert len(data.target) == 569
    
    def test_compute_base_rate(self):
        """Test base rate computation (hw1 Q1)."""
        from sklearn.datasets import load_breast_cancer
        
        data = load_breast_cancer()
        y = data.target
        
        malignant_count = np.sum(y == 0)
        total_count = len(y)
        base_rate = malignant_count / total_count
        
        # From hw1: base rate should be ~0.3726
        assert 0.37 < base_rate < 0.38
        assert malignant_count == 212
    
    def test_train_test_split(self):
        """Test train/test split."""
        from sklearn.datasets import load_breast_cancer
        from sklearn.model_selection import train_test_split
        
        data = load_breast_cancer()
        X_train, X_test, y_train, y_test = train_test_split(
            data.data, data.target, test_size=0.2, random_state=10
        )
        
        assert len(X_train) == 455
        assert len(X_test) == 114
        assert len(y_train) == 455
        assert len(y_test) == 114


class TestGBMTrainerLogic:
    """Tests for GBM trainer component logic."""
    
    def test_decision_tree_training(self, sample_breast_cancer_data):
        """Test decision tree training (hw1 Q2)."""
        from sklearn import tree
        
        X_train = np.array(sample_breast_cancer_data["X_train"])
        y_train = np.array(sample_breast_cancer_data["y_train"])
        
        clf = tree.DecisionTreeClassifier(max_depth=5, random_state=10)
        clf.fit(X_train, y_train)
        
        accuracy = clf.score(X_train, y_train)
        assert accuracy > 0.9  # Should be high on training data
    
    def test_decision_tree_depth_variation(self, sample_breast_cancer_data):
        """Test decision tree with varying depth (hw1 Q2a)."""
        from sklearn import tree
        from sklearn.model_selection import cross_val_score, KFold
        
        X = np.array(sample_breast_cancer_data["X_train"])
        y = np.array(sample_breast_cancer_data["y_train"])
        
        depths = range(1, 11)
        cv_scores = []
        
        for depth in depths:
            clf = tree.DecisionTreeClassifier(max_depth=depth, random_state=10)
            cv = KFold(n_splits=10, shuffle=True, random_state=10)
            scores = cross_val_score(clf, X, y, cv=cv)
            cv_scores.append(scores.mean())
        
        # CV accuracy should improve initially then plateau
        assert cv_scores[0] < cv_scores[4]  # Depth 1 < Depth 5
        assert len(cv_scores) == 10
    
    def test_random_forest_training(self, sample_breast_cancer_data):
        """Test random forest training (hw1 Q4)."""
        from sklearn.ensemble import RandomForestClassifier
        
        X_train = np.array(sample_breast_cancer_data["X_train"])
        y_train = np.array(sample_breast_cancer_data["y_train"])
        
        clf = RandomForestClassifier(n_estimators=50, random_state=10)
        clf.fit(X_train, y_train)
        
        accuracy = clf.score(X_train, y_train)
        assert accuracy > 0.95
    
    def test_gradient_boosting_training(self, sample_breast_cancer_data):
        """Test gradient boosting training (hw1 Q5)."""
        from sklearn.ensemble import GradientBoostingClassifier
        
        X_train = np.array(sample_breast_cancer_data["X_train"])
        y_train = np.array(sample_breast_cancer_data["y_train"])
        X_test = np.array(sample_breast_cancer_data["X_test"])
        y_test = np.array(sample_breast_cancer_data["y_test"])
        
        clf = GradientBoostingClassifier(
            n_estimators=50,
            max_depth=3,
            learning_rate=0.1,
            random_state=10
        )
        clf.fit(X_train, y_train)
        
        train_acc = clf.score(X_train, y_train)
        test_acc = clf.score(X_test, y_test)
        
        assert train_acc > 0.95
        assert test_acc > 0.90


class TestEvaluatorLogic:
    """Tests for evaluator component logic."""
    
    def test_model_evaluation(self, sample_model, sample_breast_cancer_data):
        """Test model evaluation metrics."""
        from sklearn.metrics import accuracy_score, f1_score
        
        X_test = np.array(sample_breast_cancer_data["X_test"])
        y_test = np.array(sample_breast_cancer_data["y_test"])
        
        y_pred = sample_model.predict(X_test)
        
        accuracy = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred, average='weighted')
        
        assert 0 <= accuracy <= 1
        assert 0 <= f1 <= 1
        assert accuracy > 0.9  # Should be reasonably good
    
    def test_cross_validation(self, sample_model, sample_breast_cancer_data):
        """Test cross-validation evaluation."""
        from sklearn.model_selection import cross_val_score, KFold
        
        X_train = np.array(sample_breast_cancer_data["X_train"])
        y_train = np.array(sample_breast_cancer_data["y_train"])
        
        cv = KFold(n_splits=10, shuffle=True, random_state=10)
        scores = cross_val_score(sample_model, X_train, y_train, cv=cv)
        
        assert len(scores) == 10
        assert scores.mean() > 0.85
        assert scores.std() < 0.1
