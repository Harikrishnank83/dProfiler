"""
Mock Kubeflow Pipelines Server

Provides a mock KFP API server for testing without a real cluster.
"""

import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class MockRun:
    """Mock pipeline run."""
    run_id: str
    name: str
    pipeline_id: str
    status: str = "Running"
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    finished_at: Optional[str] = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)


@dataclass
class MockPipeline:
    """Mock pipeline definition."""
    pipeline_id: str
    name: str
    description: str = ""
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class MockExperiment:
    """Mock experiment."""
    experiment_id: str
    name: str
    description: str = ""


class MockKFPServer:
    """
    Mock KFP server for testing.
    
    Usage:
        server = MockKFPServer()
        client = server.get_client()
        
        # Use client like real KFP client
        run = client.create_run_from_pipeline_func(...)
    """
    
    def __init__(self):
        self.pipelines: Dict[str, MockPipeline] = {}
        self.runs: Dict[str, MockRun] = {}
        self.experiments: Dict[str, MockExperiment] = {}
        
        # Create default experiment
        self._create_default_experiment()
    
    def _create_default_experiment(self):
        """Create the default experiment."""
        exp_id = str(uuid.uuid4())
        self.experiments[exp_id] = MockExperiment(
            experiment_id=exp_id,
            name="Default",
            description="Default experiment"
        )
    
    def upload_pipeline(
        self,
        pipeline_name: str,
        description: str = ""
    ) -> MockPipeline:
        """Upload a pipeline."""
        pipeline_id = str(uuid.uuid4())
        pipeline = MockPipeline(
            pipeline_id=pipeline_id,
            name=pipeline_name,
            description=description
        )
        self.pipelines[pipeline_id] = pipeline
        return pipeline
    
    def create_run(
        self,
        pipeline_id: str,
        run_name: str = None,
        parameters: Dict[str, Any] = None
    ) -> MockRun:
        """Create a pipeline run."""
        run_id = str(uuid.uuid4())
        run = MockRun(
            run_id=run_id,
            name=run_name or f"run-{run_id[:8]}",
            pipeline_id=pipeline_id,
            parameters=parameters or {}
        )
        self.runs[run_id] = run
        return run
    
    def get_run(self, run_id: str) -> Optional[MockRun]:
        """Get a run by ID."""
        return self.runs.get(run_id)
    
    def list_runs(
        self,
        experiment_id: str = None,
        limit: int = 100
    ) -> List[MockRun]:
        """List runs."""
        runs = list(self.runs.values())
        return runs[:limit]
    
    def complete_run(
        self,
        run_id: str,
        status: str = "Succeeded",
        metrics: Dict[str, float] = None
    ):
        """Mark a run as complete."""
        if run_id in self.runs:
            self.runs[run_id].status = status
            self.runs[run_id].finished_at = datetime.utcnow().isoformat()
            if metrics:
                self.runs[run_id].metrics = metrics
    
    def fail_run(self, run_id: str, error_message: str = ""):
        """Mark a run as failed."""
        self.complete_run(run_id, status="Failed")
    
    def get_client(self) -> "MockKFPClient":
        """Get a mock client instance."""
        return MockKFPClient(self)


class MockKFPClient:
    """
    Mock KFP client that mimics kfp.Client interface.
    
    Can be used as a drop-in replacement for testing.
    """
    
    def __init__(self, server: MockKFPServer = None):
        self.server = server or MockKFPServer()
    
    def create_run_from_pipeline_func(
        self,
        pipeline_func,
        arguments: Dict[str, Any] = None,
        run_name: str = None,
        experiment_name: str = "Default",
        **kwargs
    ) -> MockRun:
        """Create a run from a pipeline function."""
        # Upload pipeline
        pipeline = self.server.upload_pipeline(
            pipeline_name=getattr(pipeline_func, "__name__", "pipeline")
        )
        
        # Create run
        run = self.server.create_run(
            pipeline_id=pipeline.pipeline_id,
            run_name=run_name,
            parameters=arguments
        )
        
        return run
    
    def get_run(self, run_id: str) -> MockRun:
        """Get a run."""
        return self.server.get_run(run_id)
    
    def list_runs(self, **kwargs) -> "MockRunList":
        """List runs."""
        runs = self.server.list_runs(**kwargs)
        return MockRunList(runs=runs)
    
    def wait_for_run_completion(
        self,
        run_id: str,
        timeout: int = 3600
    ) -> MockRun:
        """Wait for run completion (immediately returns in mock)."""
        run = self.server.get_run(run_id)
        if run:
            run.status = "Succeeded"
            run.finished_at = datetime.utcnow().isoformat()
        return run
    
    def upload_pipeline(
        self,
        pipeline_package_path: str,
        pipeline_name: str = None
    ) -> MockPipeline:
        """Upload a pipeline."""
        return self.server.upload_pipeline(
            pipeline_name=pipeline_name or "uploaded-pipeline"
        )


@dataclass
class MockRunList:
    """Mock run list response."""
    runs: List[MockRun]
    
    def __iter__(self):
        return iter(self.runs)
    
    def __len__(self):
        return len(self.runs)
