"""
Mock Component Executor

Execute components locally without Docker for testing.
"""

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class ExecutionResult:
    """Result of component execution."""
    success: bool
    outputs: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    logs: str = ""
    error: Optional[str] = None


class LocalComponentExecutor:
    """
    Execute components locally without Docker.
    
    This executor runs the component's Python code directly,
    which is faster for testing and doesn't require Docker.
    """
    
    def __init__(self, components_dir: Path):
        self.components_dir = components_dir
        self.work_dir: Optional[Path] = None
    
    def execute(
        self,
        component_name: str,
        inputs: Dict[str, Any],
        output_names: List[str] = None
    ) -> ExecutionResult:
        """
        Execute a component locally.
        
        Args:
            component_name: Name of the component (e.g., "data-loader")
            inputs: Input parameters and values
            output_names: List of output artifact names
            
        Returns:
            ExecutionResult with outputs and metrics
        """
        component_dir = self.components_dir / component_name
        main_py = component_dir / "src" / "main.py"
        
        if not main_py.exists():
            return ExecutionResult(
                success=False,
                error=f"Component main.py not found: {main_py}"
            )
        
        # Create temp directory for outputs
        with tempfile.TemporaryDirectory() as tmpdir:
            self.work_dir = Path(tmpdir)
            
            # Prepare arguments
            args = [sys.executable, str(main_py)]
            
            # Add input arguments
            for key, value in inputs.items():
                arg_name = f"--{key.replace('_', '-')}"
                
                # Handle file inputs
                if isinstance(value, dict):
                    input_file = self.work_dir / f"{key}.json"
                    with open(input_file, "w") as f:
                        json.dump(value, f)
                    args.extend([arg_name, str(input_file)])
                elif isinstance(value, Path):
                    args.extend([arg_name, str(value)])
                else:
                    args.extend([arg_name, str(value)])
            
            # Add output paths
            output_paths = {}
            if output_names:
                for name in output_names:
                    output_path = self.work_dir / f"{name}.json"
                    arg_name = f"--{name.replace('_', '-')}"
                    args.extend([arg_name, str(output_path)])
                    output_paths[name] = output_path
            
            # Execute
            try:
                result = subprocess.run(
                    args,
                    capture_output=True,
                    text=True,
                    cwd=str(component_dir),
                    timeout=300
                )
                
                logs = result.stdout + result.stderr
                
                if result.returncode != 0:
                    return ExecutionResult(
                        success=False,
                        logs=logs,
                        error=f"Component failed with code {result.returncode}"
                    )
                
                # Read outputs
                outputs = {}
                metrics = {}
                
                for name, path in output_paths.items():
                    if path.exists():
                        with open(path) as f:
                            data = json.load(f)
                        
                        if name == "metrics" and "metrics" in data:
                            # Parse KFP metrics format
                            for m in data["metrics"]:
                                metrics[m["name"]] = m["numberValue"]
                        else:
                            outputs[name] = data
                
                return ExecutionResult(
                    success=True,
                    outputs=outputs,
                    metrics=metrics,
                    logs=logs
                )
                
            except subprocess.TimeoutExpired:
                return ExecutionResult(
                    success=False,
                    error="Component execution timed out"
                )
            except Exception as e:
                return ExecutionResult(
                    success=False,
                    error=str(e)
                )
    
    def execute_python_function(
        self,
        func,
        **kwargs
    ) -> ExecutionResult:
        """
        Execute a Python function directly.
        
        Useful for testing component logic without subprocess.
        """
        try:
            result = func(**kwargs)
            
            # Handle named tuple results
            if hasattr(result, "_asdict"):
                outputs = result._asdict()
            elif isinstance(result, dict):
                outputs = result
            else:
                outputs = {"result": result}
            
            # Extract metrics if present
            metrics = {}
            for key, value in outputs.items():
                if isinstance(value, (int, float)):
                    metrics[key] = value
            
            return ExecutionResult(
                success=True,
                outputs=outputs,
                metrics=metrics
            )
            
        except Exception as e:
            return ExecutionResult(
                success=False,
                error=str(e)
            )


class ComponentTestHarness:
    """
    Test harness for component integration testing.
    
    Provides utilities for setting up test data, executing components,
    and validating outputs.
    """
    
    def __init__(self, components_dir: Path):
        self.executor = LocalComponentExecutor(components_dir)
        self.artifacts: Dict[str, Any] = {}
    
    def setup_input(self, name: str, data: Any):
        """Set up an input artifact."""
        self.artifacts[name] = data
    
    def run_component(
        self,
        component_name: str,
        inputs: Dict[str, Any] = None,
        output_names: List[str] = None
    ) -> ExecutionResult:
        """Run a component with prepared inputs."""
        # Merge prepared artifacts with explicit inputs
        all_inputs = {**self.artifacts, **(inputs or {})}
        
        result = self.executor.execute(
            component_name,
            all_inputs,
            output_names
        )
        
        # Store outputs for next component
        if result.success:
            self.artifacts.update(result.outputs)
        
        return result
    
    def get_artifact(self, name: str) -> Optional[Any]:
        """Get an artifact by name."""
        return self.artifacts.get(name)
    
    def clear(self):
        """Clear all artifacts."""
        self.artifacts.clear()
