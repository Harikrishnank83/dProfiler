"""
Sample data generators for testing.

Provides consistent test data for component and pipeline testing.
"""

import numpy as np
from sklearn.datasets import load_breast_cancer, make_classification
from sklearn.model_selection import train_test_split
from typing import Tuple, Dict, Any


def get_breast_cancer_data(
    test_size: float = 0.2,
    random_state: int = 10
) -> Dict[str, Any]:
    """
    Get the breast cancer dataset in component-ready format.
    
    This is the same data used in hw1_programming_base_notebook.
    """
    data = load_breast_cancer()
    X_train, X_test, y_train, y_test = train_test_split(
        data.data, data.target, 
        test_size=test_size, 
        random_state=random_state
    )
    
    return {
        "X_train": X_train.tolist(),
        "X_test": X_test.tolist(),
        "y_train": y_train.tolist(),
        "y_test": y_test.tolist(),
        "feature_names": list(data.feature_names),
        "target_names": list(data.target_names)
    }


def get_small_test_data(
    n_samples: int = 100,
    n_features: int = 10,
    test_size: float = 0.2,
    random_state: int = 42
) -> Dict[str, Any]:
    """
    Generate a small synthetic dataset for fast testing.
    """
    X, y = make_classification(
        n_samples=n_samples,
        n_features=n_features,
        n_informative=5,
        n_redundant=2,
        random_state=random_state
    )
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    
    return {
        "X_train": X_train.tolist(),
        "X_test": X_test.tolist(),
        "y_train": y_train.tolist(),
        "y_test": y_test.tolist(),
        "feature_names": [f"feature_{i}" for i in range(n_features)],
        "target_names": ["class_0", "class_1"]
    }


def get_numpy_arrays(data: Dict[str, Any]) -> Tuple[np.ndarray, ...]:
    """
    Convert component data format to numpy arrays.
    
    Returns:
        Tuple of (X_train, X_test, y_train, y_test)
    """
    return (
        np.array(data["X_train"]),
        np.array(data["X_test"]),
        np.array(data["y_train"]),
        np.array(data["y_test"])
    )


class SampleDataFactory:
    """
    Factory for generating various test datasets.
    """
    
    @staticmethod
    def breast_cancer(**kwargs) -> Dict[str, Any]:
        """Get breast cancer dataset."""
        return get_breast_cancer_data(**kwargs)
    
    @staticmethod
    def small(**kwargs) -> Dict[str, Any]:
        """Get small synthetic dataset."""
        return get_small_test_data(**kwargs)
    
    @staticmethod
    def empty() -> Dict[str, Any]:
        """Get empty dataset structure."""
        return {
            "X_train": [],
            "X_test": [],
            "y_train": [],
            "y_test": [],
            "feature_names": [],
            "target_names": []
        }
    
    @staticmethod
    def single_sample() -> Dict[str, Any]:
        """Get dataset with single sample (edge case)."""
        return {
            "X_train": [[1.0, 2.0, 3.0]],
            "X_test": [[4.0, 5.0, 6.0]],
            "y_train": [0],
            "y_test": [1],
            "feature_names": ["a", "b", "c"],
            "target_names": ["neg", "pos"]
        }


# Pre-computed expected values for validation
BREAST_CANCER_EXPECTED = {
    "n_samples": 569,
    "n_features": 30,
    "train_samples": 455,
    "test_samples": 114,
    "malignant_count": 212,
    "base_rate_malignant": 0.3726,  # Approximate
    "random_state": 10  # hw1 default
}
