"""
Pytest configuration and fixtures for Kubeflow component testing.

This module provides fixtures for:
- Mocking KFP SDK calls
- Local component execution
- Sample data generation
- Artifact validation
"""

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Generator
from unittest.mock import MagicMock, patch

import pytest
import numpy as np


# ============================================================================
# Path Fixtures
# ============================================================================

@pytest.fixture
def project_root() -> Path:
    """Get the project root directory."""
    return Path(__file__).parent.parent.parent


@pytest.fixture
def components_dir(project_root: Path) -> Path:
    """Get the components directory."""
    return project_root / "components"


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """Create a temporary directory for test artifacts."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


# ============================================================================
# Sample Data Fixtures
# ============================================================================

@pytest.fixture
def sample_breast_cancer_data() -> dict:
    """Generate sample breast cancer dataset."""
    from sklearn.datasets import load_breast_cancer
    from sklearn.model_selection import train_test_split
    
    data = load_breast_cancer()
    X_train, X_test, y_train, y_test = train_test_split(
        data.data, data.target, test_size=0.2, random_state=10
    )
    
    return {
        "X_train": X_train.tolist(),
        "X_test": X_test.tolist(),
        "y_train": y_train.tolist(),
        "y_test": y_test.tolist(),
        "feature_names": list(data.feature_names),
        "target_names": list(data.target_names)
    }


@pytest.fixture
def sample_data_file(sample_breast_cancer_data: dict, temp_dir: Path) -> Path:
    """Create a sample data file."""
    data_file = temp_dir / "sample_data.json"
    with open(data_file, "w") as f:
        json.dump(sample_breast_cancer_data, f)
    return data_file


@pytest.fixture
def sample_model(sample_breast_cancer_data: dict) -> Any:
    """Create a sample trained model."""
    from sklearn.ensemble import GradientBoostingClassifier
    
    X_train = np.array(sample_breast_cancer_data["X_train"])
    y_train = np.array(sample_breast_cancer_data["y_train"])
    
    model = GradientBoostingClassifier(n_estimators=10, random_state=10)
    model.fit(X_train, y_train)
    
    return model


@pytest.fixture
def sample_model_file(sample_model: Any, temp_dir: Path) -> Path:
    """Create a sample model file."""
    import pickle
    
    model_file = temp_dir / "model.pkl"
    with open(model_file, "wb") as f:
        pickle.dump(sample_model, f)
    return model_file


# ============================================================================
# KFP Mock Fixtures
# ============================================================================

@pytest.fixture
def mock_kfp_client() -> Generator[MagicMock, None, None]:
    """Mock the KFP client for testing without a cluster."""
    with patch("kfp.Client") as mock_client:
        instance = MagicMock()
        mock_client.return_value = instance
        
        # Mock common methods
        instance.create_run_from_pipeline_func.return_value = MagicMock(
            run_id="mock-run-id-12345"
        )
        instance.get_run.return_value = MagicMock(
            run=MagicMock(status="Succeeded")
        )
        instance.list_runs.return_value = MagicMock(
            runs=[MagicMock(run_id="run-1"), MagicMock(run_id="run-2")]
        )
        
        yield instance


@pytest.fixture
def mock_kfp_components() -> Generator[dict, None, None]:
    """Mock KFP component decorators."""
    mocks = {}
    
    with patch("kfp.dsl.component") as mock_component:
        mock_component.return_value = lambda f: f
        mocks["component"] = mock_component
        
        with patch("kfp.dsl.pipeline") as mock_pipeline:
            mock_pipeline.return_value = lambda f: f
            mocks["pipeline"] = mock_pipeline
            
            yield mocks


# ============================================================================
# Component Execution Fixtures
# ============================================================================

@pytest.fixture
def local_runner(temp_dir: Path):
    """
    Fixture for running components locally without Docker.
    
    Returns a function that can execute component logic directly.
    """
    class LocalRunner:
        def __init__(self, work_dir: Path):
            self.work_dir = work_dir
            self.outputs = {}
        
        def run_component(
            self,
            component_func,
            inputs: dict,
            output_names: list = None
        ) -> dict:
            """Run a component function locally."""
            # Create output paths
            if output_names:
                for name in output_names:
                    output_path = self.work_dir / f"{name}.json"
                    inputs[name] = str(output_path)
            
            # Execute component
            result = component_func(**inputs)
            
            # Collect outputs
            self.outputs = {}
            if output_names:
                for name in output_names:
                    output_path = self.work_dir / f"{name}.json"
                    if output_path.exists():
                        with open(output_path) as f:
                            self.outputs[name] = json.load(f)
            
            return result
    
    return LocalRunner(temp_dir)


# ============================================================================
# Validation Fixtures
# ============================================================================

@pytest.fixture
def kfp_metrics_validator():
    """Validator for KFP metrics format."""
    def validate(metrics_path: Path) -> bool:
        """Validate that metrics file is in correct KFP format."""
        if not metrics_path.exists():
            return False
        
        with open(metrics_path) as f:
            data = json.load(f)
        
        if "metrics" not in data:
            return False
        
        for metric in data["metrics"]:
            if "name" not in metric or "numberValue" not in metric:
                return False
        
        return True
    
    return validate


@pytest.fixture
def artifact_validator():
    """Validator for pipeline artifacts."""
    def validate(artifact_path: Path, schema: dict = None) -> bool:
        """Validate that artifact exists and optionally matches schema."""
        if not artifact_path.exists():
            return False
        
        if schema:
            with open(artifact_path) as f:
                data = json.load(f)
            
            for key in schema.get("required", []):
                if key not in data:
                    return False
        
        return True
    
    return validate


# ============================================================================
# Environment Fixtures
# ============================================================================

@pytest.fixture
def mock_cluster_env(monkeypatch):
    """Mock cluster environment variables."""
    monkeypatch.setenv("KUBEFLOW_HOST", "http://localhost:8080")
    monkeypatch.setenv("REGISTRY_URL", "localhost:5000")
    monkeypatch.setenv("NAMESPACE", "kubeflow")


@pytest.fixture
def skip_if_no_cluster():
    """Skip test if no cluster is available."""
    import subprocess
    try:
        result = subprocess.run(
            ["kubectl", "cluster-info"],
            capture_output=True,
            timeout=5
        )
        if result.returncode != 0:
            pytest.skip("Kubernetes cluster not available")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pytest.skip("kubectl not available or cluster unreachable")
