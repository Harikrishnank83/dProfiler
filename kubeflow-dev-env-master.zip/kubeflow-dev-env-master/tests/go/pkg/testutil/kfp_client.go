// Package testutil provides mock KFP client for testing.
package testutil

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// MockRun represents a mock pipeline run.
type MockRun struct {
	RunID      string
	Name       string
	PipelineID string
	Status     string
	CreatedAt  time.Time
	FinishedAt *time.Time
	Parameters map[string]interface{}
	Metrics    map[string]float64
}

// MockPipeline represents a mock pipeline.
type MockPipeline struct {
	PipelineID  string
	Name        string
	Description string
	CreatedAt   time.Time
}

// MockKFPClient provides a mock KFP API client for testing.
type MockKFPClient struct {
	mu        sync.RWMutex
	pipelines map[string]*MockPipeline
	runs      map[string]*MockRun
	runIDSeq  int
}

// NewMockKFPClient creates a new mock KFP client.
func NewMockKFPClient() *MockKFPClient {
	return &MockKFPClient{
		pipelines: make(map[string]*MockPipeline),
		runs:      make(map[string]*MockRun),
	}
}

// UploadPipeline creates a new pipeline.
func (c *MockKFPClient) UploadPipeline(ctx context.Context, name, description string) (*MockPipeline, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	id := fmt.Sprintf("pipeline-%d", len(c.pipelines)+1)
	pipeline := &MockPipeline{
		PipelineID:  id,
		Name:        name,
		Description: description,
		CreatedAt:   time.Now(),
	}
	c.pipelines[id] = pipeline
	return pipeline, nil
}

// CreateRun creates a new pipeline run.
func (c *MockKFPClient) CreateRun(ctx context.Context, pipelineID, name string, params map[string]interface{}) (*MockRun, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if _, exists := c.pipelines[pipelineID]; !exists {
		return nil, fmt.Errorf("pipeline not found: %s", pipelineID)
	}

	c.runIDSeq++
	id := fmt.Sprintf("run-%d", c.runIDSeq)
	run := &MockRun{
		RunID:      id,
		Name:       name,
		PipelineID: pipelineID,
		Status:     "Running",
		CreatedAt:  time.Now(),
		Parameters: params,
		Metrics:    make(map[string]float64),
	}
	c.runs[id] = run
	return run, nil
}

// GetRun returns a run by ID.
func (c *MockKFPClient) GetRun(ctx context.Context, runID string) (*MockRun, error) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	run, exists := c.runs[runID]
	if !exists {
		return nil, fmt.Errorf("run not found: %s", runID)
	}
	return run, nil
}

// ListRuns returns all runs.
func (c *MockKFPClient) ListRuns(ctx context.Context) ([]*MockRun, error) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	runs := make([]*MockRun, 0, len(c.runs))
	for _, run := range c.runs {
		runs = append(runs, run)
	}
	return runs, nil
}

// CompleteRun marks a run as completed.
func (c *MockKFPClient) CompleteRun(ctx context.Context, runID string, status string, metrics map[string]float64) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	run, exists := c.runs[runID]
	if !exists {
		return fmt.Errorf("run not found: %s", runID)
	}

	now := time.Now()
	run.Status = status
	run.FinishedAt = &now
	if metrics != nil {
		run.Metrics = metrics
	}
	return nil
}

// WaitForCompletion waits for a run to complete (mock version completes immediately).
func (c *MockKFPClient) WaitForCompletion(ctx context.Context, runID string, timeout time.Duration) (*MockRun, error) {
	run, err := c.GetRun(ctx, runID)
	if err != nil {
		return nil, err
	}

	// In mock, complete immediately
	if run.Status == "Running" {
		if err := c.CompleteRun(ctx, runID, "Succeeded", nil); err != nil {
			return nil, err
		}
	}

	return c.GetRun(ctx, runID)
}

// Reset clears all pipelines and runs.
func (c *MockKFPClient) Reset() {
	c.mu.Lock()
	defer c.mu.Unlock()

	c.pipelines = make(map[string]*MockPipeline)
	c.runs = make(map[string]*MockRun)
	c.runIDSeq = 0
}
