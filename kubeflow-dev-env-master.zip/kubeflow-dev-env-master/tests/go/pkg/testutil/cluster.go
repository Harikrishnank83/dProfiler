// Package testutil provides utilities for testing Kubernetes operators and CRDs.
package testutil

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/envtest"
)

// TestCluster wraps envtest for testing.
type TestCluster struct {
	Env        *envtest.Environment
	Config     *rest.Config
	Client     client.Client
	Scheme     *runtime.Scheme
	cancelFunc context.CancelFunc
}

// ClusterOptions configures the test cluster.
type ClusterOptions struct {
	// CRDDirectoryPaths for custom resource definitions
	CRDDirectoryPaths []string
	// UseExistingCluster connects to a real cluster if true
	UseExistingCluster bool
	// K8sVersion to use (for envtest binary download)
	K8sVersion string
}

// NewTestCluster creates a new test cluster using envtest.
func NewTestCluster(opts ClusterOptions) (*TestCluster, error) {
	// Set up envtest environment
	env := &envtest.Environment{
		CRDDirectoryPaths:     opts.CRDDirectoryPaths,
		ErrorIfCRDPathMissing: false,
	}

	if opts.UseExistingCluster {
		useExisting := true
		env.UseExistingCluster = &useExisting
	}

	// Start the environment
	cfg, err := env.Start()
	if err != nil {
		return nil, fmt.Errorf("failed to start envtest: %w", err)
	}

	// Create scheme
	s := runtime.NewScheme()
	if err := scheme.AddToScheme(s); err != nil {
		env.Stop()
		return nil, fmt.Errorf("failed to add to scheme: %w", err)
	}

	// Create client
	k8sClient, err := client.New(cfg, client.Options{Scheme: s})
	if err != nil {
		env.Stop()
		return nil, fmt.Errorf("failed to create client: %w", err)
	}

	return &TestCluster{
		Env:    env,
		Config: cfg,
		Client: k8sClient,
		Scheme: s,
	}, nil
}

// Stop shuts down the test cluster.
func (tc *TestCluster) Stop() error {
	if tc.cancelFunc != nil {
		tc.cancelFunc()
	}
	return tc.Env.Stop()
}

// WaitForReady waits for the cluster to be ready.
func (tc *TestCluster) WaitForReady(ctx context.Context, timeout time.Duration) error {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		// Try to list namespaces as a health check
		var nsList client.ObjectList
		if err := tc.Client.List(ctx, nsList); err == nil {
			return nil
		}
		time.Sleep(100 * time.Millisecond)
	}
	return fmt.Errorf("cluster not ready after %v", timeout)
}

// GetProjectRoot returns the project root directory.
func GetProjectRoot() string {
	// Walk up from the test directory to find project root
	dir, err := os.Getwd()
	if err != nil {
		return ""
	}

	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return ""
		}
		dir = parent
	}
}

// DefaultCRDPaths returns the default CRD paths for the project.
func DefaultCRDPaths() []string {
	root := GetProjectRoot()
	if root == "" {
		return nil
	}
	return []string{
		filepath.Join(root, "infra", "operators"),
	}
}
