// Package testutil provides version matrix testing utilities.
package testutil

import (
	"fmt"
	"os"
	"path/filepath"

	"gopkg.in/yaml.v3"
)

// K8sVersion represents a Kubernetes version configuration.
type K8sVersion struct {
	Version   string `yaml:"version"`
	K3sImage  string `yaml:"k3s_image"`
	Supported bool   `yaml:"supported"`
}

// KFPVersion represents a Kubeflow Pipelines version configuration.
type KFPVersion struct {
	Version      string   `yaml:"version"`
	ManifestURL  string   `yaml:"manifest_url"`
	CompatibleK8s []string `yaml:"compatible_k8s"`
	Supported    bool     `yaml:"supported"`
}

// VersionMatrix holds all version configurations.
type VersionMatrix struct {
	Kubernetes []K8sVersion `yaml:"kubernetes"`
	Kubeflow   []KFPVersion `yaml:"kubeflow"`
}

// LoadVersionMatrix loads the version matrix from versions.yaml.
func LoadVersionMatrix(versionsFile string) (*VersionMatrix, error) {
	data, err := os.ReadFile(versionsFile)
	if err != nil {
		return nil, fmt.Errorf("failed to read versions file: %w", err)
	}

	var matrix VersionMatrix
	if err := yaml.Unmarshal(data, &matrix); err != nil {
		return nil, fmt.Errorf("failed to parse versions file: %w", err)
	}

	return &matrix, nil
}

// GetCompatiblePairs returns all compatible K8s/KFP version pairs.
func (m *VersionMatrix) GetCompatiblePairs() []VersionPair {
	var pairs []VersionPair

	for _, kfp := range m.Kubeflow {
		if !kfp.Supported {
			continue
		}

		for _, k8s := range m.Kubernetes {
			if !k8s.Supported {
				continue
			}

			// Check if K8s version is compatible with KFP
			k8sMinor := extractMinorVersion(k8s.Version)
			for _, compat := range kfp.CompatibleK8s {
				if k8sMinor == compat {
					pairs = append(pairs, VersionPair{
						K8sVersion: k8s.Version,
						KFPVersion: kfp.Version,
					})
					break
				}
			}
		}
	}

	return pairs
}

// VersionPair represents a compatible K8s/KFP version pair.
type VersionPair struct {
	K8sVersion string
	KFPVersion string
}

// String returns a string representation of the version pair.
func (p VersionPair) String() string {
	return fmt.Sprintf("k8s-%s-kfp-%s", p.K8sVersion, p.KFPVersion)
}

// extractMinorVersion extracts the minor version (e.g., "1.28" from "1.28.5").
func extractMinorVersion(version string) string {
	// Simple implementation - find first two dot-separated parts
	dots := 0
	for i, c := range version {
		if c == '.' {
			dots++
			if dots == 2 {
				return version[:i]
			}
		}
	}
	return version
}

// VersionMatrixTestCase represents a test case for a version pair.
type VersionMatrixTestCase struct {
	Name       string
	K8sVersion string
	KFPVersion string
	TestFunc   func() error
}

// RunVersionMatrixTests runs tests for all compatible version pairs.
func RunVersionMatrixTests(versionsFile string, testFunc func(pair VersionPair) error) error {
	matrix, err := LoadVersionMatrix(versionsFile)
	if err != nil {
		return err
	}

	pairs := matrix.GetCompatiblePairs()
	if len(pairs) == 0 {
		return fmt.Errorf("no compatible version pairs found")
	}

	var errors []error
	for _, pair := range pairs {
		if err := testFunc(pair); err != nil {
			errors = append(errors, fmt.Errorf("%s: %w", pair.String(), err))
		}
	}

	if len(errors) > 0 {
		return fmt.Errorf("%d tests failed", len(errors))
	}

	return nil
}

// DefaultVersionsFile returns the default versions.yaml path.
func DefaultVersionsFile() string {
	root := GetProjectRoot()
	if root == "" {
		return "versions/versions.yaml"
	}
	return filepath.Join(root, "..", "..", "versions", "versions.yaml")
}
