#!/usr/bin/env bash
# Intelligent Wizard-type Setup for Kubeflow Development Environment
# Detects existing installations and guides users through only necessary steps

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source common utilities
if [[ -f "$SCRIPT_DIR/scripts/common.sh" ]]; then
    source "$SCRIPT_DIR/scripts/common.sh"
fi

# Source container runtime abstraction
RUNTIME_FUNCTIONS_AVAILABLE=false
if [[ -f "$SCRIPT_DIR/scripts/container-runtime.sh" ]]; then
    source "$SCRIPT_DIR/scripts/container-runtime.sh"
    # Validate runtime functions are available
    if declare -f detect_active_runtime > /dev/null 2>&1; then
        RUNTIME_FUNCTIONS_AVAILABLE=true
    fi
fi

# Colors and formatting
BOLD='\033[1m'
DIM='\033[2m'
ITALIC='\033[3m'
NC='\033[0m'

# Wizard state
DRY_RUN=false
SKIP_DEPS=false
MODE=""
K8S_VERSION=""
KFP_VERSION=""
INSTALL_UI=true
CONTAINER_RUNTIME=""
USE_EXISTING_CLUSTER=false
CLUSTER_NAME=""
DETECTED_DEPS=()
MISSING_DEPS=()
INSTALLATION_PLAN=()

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --non-interactive)
            MODE="dev"
            K8S_VERSION="1.28.5"
            KFP_VERSION="2.1.0"
            shift
            ;;
        --help|-h)
            echo "Intelligent Kubeflow Installation Wizard"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --dry-run           Show what would be installed without making changes"
            echo "  --non-interactive   Use defaults without prompting"
            echo "  --help              Show this help message"
            echo ""
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Help functions
show_general_help() {
    echo -e "${CYAN}━━━ Help ━━━${NC}"
    echo ""
    echo "Available commands:"
    echo -e "  ${GREEN}help${NC} or ${GREEN}?${NC}  - Show this help"
    echo -e "  ${GREEN}exit${NC} or ${GREEN}q${NC}  - Quit the wizard"
    echo ""
    echo "Navigation:"
    echo "  • Press Enter to use default values [shown in brackets]"
    echo "  • Type your choice and press Enter"
    echo "  • Type 'help' for context-specific help"
    echo ""
}

show_mode_help() {
    echo -e "${CYAN}━━━ Installation Modes Help ━━━${NC}"
    echo ""
    echo -e "${BOLD}1) Full Mode${NC}"
    echo "   Installs: Cluster + KFP + Dask + Ray + Components + Dev Tools"
    echo "   Time: ~15-20 minutes"
    echo "   Best for: First-time users, complete environment"
    echo ""
    echo -e "${BOLD}2) Dev Mode${NC} ${GREEN}← Recommended${NC}"
    echo "   Installs: Cluster + KFP + Dev Tools (includes KFP SDK)"
    echo "   Time: ~5-10 minutes"
    echo "   Best for: Developers, most common use case"
    echo ""
    echo -e "${BOLD}3) Minimal Mode${NC}"
    echo "   Installs: Cluster + KFP only"
    echo "   Time: ~5 minutes"
    echo "   Best for: Quick testing, minimal footprint"
    echo ""
    echo -e "${BOLD}4) API-Only Mode${NC}"
    echo "   Installs: Cluster + KFP backend + Dev Tools (no UI emphasis)"
    echo "   Time: ~5-10 minutes"
    echo "   Best for: Automated workflows, CI/CD, programmatic use"
    echo "   Note: Use KFP SDK instead of web UI"
    echo ""
    echo -e "${BOLD}5) Custom Mode${NC}"
    echo "   Installs: Your choice of modules"
    echo "   Time: Varies"
    echo "   Best for: Advanced users with specific needs"
    echo ""
}

show_custom_modules_help() {
    echo -e "${CYAN}━━━ Available Modules Help ━━━${NC}"
    echo ""
    echo -e "${BOLD}Available modules:${NC}"
    echo ""
    echo -e "  ${GREEN}deps${NC}       - Install dependencies (k3d, kubectl, Helm, yq)"
    echo "             Required for: fresh systems"
    echo ""
    echo -e "  ${GREEN}cluster${NC}    - Create Kubernetes cluster (k3d)"
    echo "             Required for: running Kubeflow"
    echo ""
    echo -e "  ${GREEN}kubeflow${NC}   - Install Kubeflow Pipelines (API + UI)"
    echo "             Required for: ML pipelines"
    echo ""
    echo -e "  ${GREEN}dask${NC}       - Install Dask operator"
    echo "             Optional: for distributed computing"
    echo ""
    echo -e "  ${GREEN}ray${NC}        - Install Ray operator"
    echo "             Optional: for distributed ML"
    echo ""
    echo -e "  ${GREEN}components${NC} - Build ML pipeline components"
    echo "             Optional: pre-built examples"
    echo ""
    echo -e "  ${GREEN}devtools${NC}   - Install development tools (Python packages, KFP SDK)"
    echo "             Recommended for: development work"
    echo ""
    echo -e "${BOLD}Example combinations:${NC}"
    echo "  • Minimal: deps,cluster,kubeflow"
    echo "  • Dev: deps,cluster,kubeflow,devtools"
    echo "  • Full: deps,cluster,kubeflow,dask,ray,components,devtools"
    echo ""
    echo -e "${YELLOW}Tip:${NC} Your system already has some dependencies installed."
    echo "      You can skip 'deps' if you already have Docker, k3d, kubectl, etc."
    echo ""
}

show_version_help() {
    echo -e "${CYAN}━━━ Version Compatibility Help ━━━${NC}"
    echo ""
    echo "Kubernetes and Kubeflow Pipelines version compatibility:"
    echo ""
    echo "  K8s Version │ KFP 2.0.5 │ KFP 2.1.0 │ KFP 2.2.0"
    echo "  ────────────┼───────────┼───────────┼──────────"
    echo "  1.26        │     ✅    │     ✅    │    ❌"
    echo "  1.27        │     ✅    │     ✅    │    ✅"
    echo "  1.28        │     ✅    │     ✅    │    ✅     ← Recommended"
    echo "  1.29        │     ❌    │     ✅    │    ✅"
    echo ""
    echo -e "${BOLD}Recommendations:${NC}"
    echo "  • K8s 1.28.5 + KFP 2.1.0 (best compatibility)"
    echo "  • K8s 1.29 for latest features (KFP 2.1.0+ only)"
    echo ""
    echo -e "${BOLD}Version format:${NC}"
    echo "  • K8s: Major.Minor.Patch (e.g., 1.28.5)"
    echo "  • KFP: Major.Minor.Patch (e.g., 2.1.0)"
    echo ""
}

show_ui_help() {
    echo -e "${CYAN}━━━ Kubeflow UI Help ━━━${NC}"
    echo ""
    echo -e "${BOLD}What is the Kubeflow UI?${NC}"
    echo "  • Web interface at http://localhost:8080"
    echo "  • Visual pipeline editor and dashboard"
    echo "  • Run monitoring and artifact viewing"
    echo ""
    echo -e "${BOLD}Do you need the UI?${NC}"
    echo ""
    echo -e "  ${GREEN}YES${NC} - Include UI if you want to:"
    echo "    • Use visual pipeline editor"
    echo "    • View runs in a dashboard"
    echo "    • Explore pipelines interactively"
    echo "    • Learn Kubeflow concepts visually"
    echo ""
    echo -e "  ${YELLOW}NO${NC} - Skip UI emphasis if you want to:"
    echo "    • Use KFP SDK (Python) exclusively"
    echo "    • Automate deployments (CI/CD)"
    echo "    • Work programmatically"
    echo "    • Use kubectl/Argo CLI for monitoring"
    echo ""
    echo -e "${BOLD}Note:${NC} Even without UI, you get full KFP functionality via SDK!"
    echo "See: docs/KFP_WITHOUT_UI.md for complete guide"
    echo ""
}

# Wizard UI functions
print_banner() {
    clear
    echo -e "${BLUE}${BOLD}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║     🚀 Kubeflow Development Environment Setup Wizard 🚀              ║
║                                                                       ║
║     Intelligent installation that adapts to your system               ║
║                                                                       ║
║     💡 Type 'help' at any prompt for assistance                      ║
║     🚪 Type 'exit' to quit at any time                               ║
║                                                                       ║
╚═══════════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    echo ""
}

print_step() {
    local step="$1"
    local title="$2"
    echo ""
    echo -e "${CYAN}${BOLD}━━━ Step $step: $title${NC}"
    echo ""
}

print_check() {
    local item="$1"
    local status="$2"
    local detail="${3:-}"
    
    case "$status" in
        "installed")
            echo -e "  ${GREEN}✓${NC} $item ${DIM}(already installed${detail:+: $detail})${NC}"
            ;;
        "running")
            echo -e "  ${GREEN}✓${NC} $item ${DIM}(running${detail:+: $detail})${NC}"
            ;;
        "missing")
            echo -e "  ${RED}✗${NC} $item ${DIM}(will be installed)${NC}"
            ;;
        "stopped")
            echo -e "  ${YELLOW}⚠${NC} $item ${DIM}(installed but not running)${NC}"
            ;;
        "skip")
            echo -e "  ${BLUE}→${NC} $item ${DIM}(will skip)${NC}"
            ;;
    esac
}

print_plan_item() {
    local action="$1"
    local description="$2"
    echo -e "  ${CYAN}▸${NC} $action: ${DIM}$description${NC}"
}

prompt_user() {
    local prompt="$1"
    local default="${2:-}"
    local response
    
    if [[ -n "$default" ]]; then
        echo -en "${YELLOW}${prompt} [${default}]:${NC} "
    else
        echo -en "${YELLOW}${prompt}:${NC} "
    fi
    
    read -r response
    echo "${response:-$default}"
}

prompt_yes_no() {
    local prompt="$1"
    local default="${2:-n}"
    local help_callback="${3:-}"
    
    while true; do
        echo ""
        if [[ "$default" == "y" ]]; then
            echo -en "${YELLOW}${prompt} [Y/n]${NC} (type 'help' or 'exit'): "
        else
            echo -en "${YELLOW}${prompt} [y/N]${NC} (type 'help' or 'exit'): "
        fi
        
        local response
        read -r response
        response="${response:-$default}"
        
        # Handle exit commands
        if [[ "$response" == "exit" || "$response" == "quit" || "$response" == "q" ]]; then
            echo ""
            echo -e "${YELLOW}Installation cancelled. Exiting...${NC}"
            exit 0
        fi
        
        # Handle help command
        if [[ "$response" == "help" || "$response" == "?" || "$response" == "h" ]]; then
            if [[ -n "$help_callback" && $(type -t "$help_callback") == "function" ]]; then
                echo ""
                $help_callback
                continue
            else
                show_general_help
                continue
            fi
        fi
        
        # Return true/false
        [[ "$response" =~ ^[Yy] ]]
        return $?
    done
}

prompt_with_exit() {
    local prompt="$1"
    local default="${2:-}"
    local help_callback="${3:-}"
    
    while true; do
        # Output prompt to stderr so it doesn't get captured by command substitution
        echo "" >&2
        echo -en "${YELLOW}${prompt}" >&2
        if [[ -n "$default" ]]; then
            echo -en " [${default}]" >&2
        fi
        echo -en " (type 'help' or 'exit'):${NC} " >&2
        
        local response
        read -r response
        
        # Handle exit commands
        if [[ "$response" == "exit" || "$response" == "quit" || "$response" == "q" ]]; then
            echo "" >&2
            echo -e "${YELLOW}Installation cancelled. Exiting...${NC}" >&2
            exit 0
        fi
        
        # Handle help command
        if [[ "$response" == "help" || "$response" == "?" || "$response" == "h" ]]; then
            if [[ -n "$help_callback" && $(type -t "$help_callback") == "function" ]]; then
                echo "" >&2
                $help_callback >&2
                continue
            else
                show_general_help >&2
                continue
            fi
        fi
        
        # Return the response or default (to stdout for capture)
        echo "${response:-$default}"
        return 0
    done
}

# Resource information display
show_resource_info() {
    echo -e "${CYAN}━━━ Resource Requirements & Downloads ━━━${NC}"
    echo ""
    echo -e "${BOLD}What will be downloaded:${NC}"
    echo "  • Kubeflow Pipelines images:    ~660MB"
    echo "  • Supporting services (MySQL, MinIO):  ~940MB"
    echo "  ${GREEN}• Total download:  ~1.6GB${NC}"
    echo ""
    echo "  Additional if building components (optional):"
    echo "  • ML component images:  ~1.92GB"
    echo ""
    echo -e "${BOLD}Disk space required:${NC}"
    echo "  • Minimum:  10GB free space"
    echo "  • Recommended:  20GB+ free space"
    echo "  • After install (minimal):  +2GB used"
    echo "  • After install (full):  +4.5GB used"
    echo ""
    echo -e "${BOLD}Memory requirements:${NC}"
    echo "  • Docker allocation:  4GB minimum, 8GB recommended"
    echo "  • System idle:  ~960MB"
    echo "  • During pipelines:  +1-2GB additional"
    echo ""
    
    # Show current system resources
    echo -e "${BOLD}Your current system:${NC}"
    
    # Available disk space
    if command -v df &> /dev/null; then
        local available=$(df -h . | tail -1 | awk '{print $4}')
        echo "  • Available disk space:  ${GREEN}$available${NC}"
    fi
    
    # Docker memory
    if docker info &> /dev/null 2>&1; then
        local mem_gb=$(docker info --format '{{.MemTotal}}' 2>/dev/null | awk '{print int($1/1024/1024/1024)}')
        if [[ -n "$mem_gb" && "$mem_gb" -gt 0 ]]; then
            if [[ "$mem_gb" -lt 4 ]]; then
                echo -e "  • Docker memory:  ${RED}${mem_gb}GB (⚠ increase to 4GB+)${NC}"
            elif [[ "$mem_gb" -lt 8 ]]; then
                echo -e "  • Docker memory:  ${YELLOW}${mem_gb}GB (8GB+ recommended)${NC}"
            else
                echo -e "  • Docker memory:  ${GREEN}${mem_gb}GB${NC}"
            fi
        fi
    fi
    
    # Current Docker usage
    if docker info &> /dev/null 2>&1; then
        echo ""
        echo -e "${BOLD}Current Docker usage:${NC}"
        docker system df 2>/dev/null || echo "  Unable to get Docker disk usage"
    fi
    
    echo ""
    echo -e "${DIM}💡 Tip: For detailed info, see docs/DOCKER_IMAGES_AND_RESOURCES.md${NC}"
    echo ""
    
    sleep 2
}

# Detection functions
detect_system() {
    print_step "1/8" "Detecting System Configuration"
    
    # Show resource information
    show_resource_info
    
    echo "Scanning your system for installed dependencies..."
    echo ""
    
    # Check Container Runtime
    echo -e "${BOLD}Container Runtime:${NC}"
    
    # Detect active runtime
    local active_runtime=""
    if [[ "$RUNTIME_FUNCTIONS_AVAILABLE" == "true" ]] && active_runtime=$(detect_active_runtime 2>/dev/null); then
        # Get runtime description from the string format (bash 3.2 compatible)
        local runtime_name="$active_runtime"
        if [[ -n "$SUPPORTED_RUNTIMES" ]]; then
            local runtime_desc=$(echo "$SUPPORTED_RUNTIMES" | grep "^${active_runtime}:" | cut -d':' -f2- | head -1)
            if [[ -n "$runtime_desc" ]]; then
                runtime_name="$runtime_desc"
            fi
        fi
        print_check "Runtime" "running" "$runtime_name"
        DETECTED_DEPS+=("docker")  # For compatibility
        CONTAINER_RUNTIME="$active_runtime"
        
        # Check resources
        if [[ "$active_runtime" == "docker" ]] || [[ "$active_runtime" == "colima" ]] || [[ "$active_runtime" == "rancher-desktop" ]]; then
            local mem_gb=$(docker info --format '{{.MemTotal}}' 2>/dev/null | awk '{print int($1/1024/1024/1024)}' || echo "0")
            if [[ "$mem_gb" -gt 0 ]]; then
                if [[ "$mem_gb" -lt 4 ]]; then
                    echo -e "    ${RED}⚠ Warning: Runtime has only ${mem_gb}GB RAM (minimum 4GB recommended)${NC}"
                elif [[ "$mem_gb" -lt 8 ]]; then
                    echo -e "    ${YELLOW}ℹ Note: Runtime has ${mem_gb}GB RAM (8GB+ recommended)${NC}"
                else
                    echo -e "    ${GREEN}ℹ Memory: ${mem_gb}GB${NC}"
                fi
            fi
        fi
    else
        # Check for available but not running runtimes
        local available_runtimes=$(detect_available_runtimes 2>/dev/null || echo "")
        if [[ -n "$available_runtimes" ]]; then
            print_check "Runtime" "stopped" "Available: $available_runtimes"
            echo -e "    ${YELLOW}→ Container runtime needs to be started${NC}"
            CONTAINER_RUNTIME=$(echo "$available_runtimes" | awk '{print $1}')
        else
            print_check "Runtime" "missing" "None found"
            echo -e "    ${YELLOW}→ Install Docker, Colima, Podman, or Rancher Desktop${NC}"
            echo -e "    ${CYAN}ℹ See: docs/CONTAINER_RUNTIMES.md for options${NC}"
            MISSING_DEPS+=("docker")
        fi
    fi
    
    # Check k3d
    if command -v k3d &> /dev/null; then
        local k3d_version=$(k3d version 2>/dev/null | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "unknown")
        print_check "k3d" "installed" "$k3d_version"
        DETECTED_DEPS+=("k3d")
        
        # Check for existing clusters
        local cluster_count=$(k3d cluster list 2>/dev/null | tail -n +2 | wc -l | tr -d ' ')
        if [[ "$cluster_count" -gt 0 ]]; then
            echo -e "    ${BLUE}ℹ Found $cluster_count existing k3d cluster(s)${NC}"
            k3d cluster list 2>/dev/null | tail -n +2 | while read line; do
                local cluster_name=$(echo "$line" | awk '{print $1}')
                local cluster_status=$(echo "$line" | awk '{print $2}')
                echo -e "      • $cluster_name (${cluster_status})"
            done
        fi
    else
        print_check "k3d" "missing"
        MISSING_DEPS+=("k3d")
    fi
    
    # Check kubectl
    if command -v kubectl &> /dev/null; then
        local kubectl_version=$(kubectl version --client -o json 2>/dev/null | grep -oE '"gitVersion":\s*"v[0-9]+\.[0-9]+\.[0-9]+"' | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
        print_check "kubectl" "installed" "$kubectl_version"
        DETECTED_DEPS+=("kubectl")
    else
        print_check "kubectl" "missing"
        MISSING_DEPS+=("kubectl")
    fi
    
    # Check Helm
    if command -v helm &> /dev/null; then
        local helm_version=$(helm version --short 2>/dev/null | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
        print_check "Helm" "installed" "$helm_version"
        DETECTED_DEPS+=("helm")
    else
        print_check "Helm" "missing"
        MISSING_DEPS+=("helm")
    fi
    
    # Check yq
    if command -v yq &> /dev/null; then
        local yq_version=$(yq --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "unknown")
        print_check "yq" "installed" "v$yq_version"
        DETECTED_DEPS+=("yq")
    else
        print_check "yq" "missing"
        MISSING_DEPS+=("yq")
    fi
    
    # Check Python
    if command -v python3 &> /dev/null; then
        local py_version=$(python3 --version 2>/dev/null | awk '{print $2}')
        print_check "Python 3" "installed" "v$py_version"
        DETECTED_DEPS+=("python3")
        
        # Check Python version
        local py_major=$(echo "$py_version" | cut -d. -f1)
        local py_minor=$(echo "$py_version" | cut -d. -f2)
        if [[ "$py_major" -lt 3 ]] || [[ "$py_major" -eq 3 && "$py_minor" -lt 9 ]]; then
            echo -e "    ${RED}⚠ Warning: Python $py_version is too old (minimum 3.9 required)${NC}"
        fi
        
        # Check pip
        if command -v pip3 &> /dev/null; then
            print_check "pip3" "installed"
        fi
    else
        print_check "Python 3" "missing"
        MISSING_DEPS+=("python3")
    fi
    
    # Check disk space
    local available_space=$(df -h "$SCRIPT_DIR" | tail -1 | awk '{print $4}')
    echo ""
    echo -e "  ${CYAN}ℹ Available disk space: $available_space${NC}"
    
    sleep 1
}

select_installation_mode() {
    print_step "2/8" "Select Installation Mode"
    
    if [[ -n "$MODE" ]]; then
        echo "Installation mode: $MODE (pre-selected)"
        return
    fi
    
    echo "Choose what you want to install:"
    echo ""
    echo "  1) Full         - Everything (recommended for first-time users)"
    echo "  2) Dev          - Cluster, Kubeflow, and dev tools (recommended for developers)"
    echo "  3) Minimal      - Just cluster and Kubeflow"
    echo "  4) API-Only     - Cluster + Kubeflow backend (no UI - for programmatic use)"
    echo "  5) Custom       - Choose specific modules"
    echo ""
    echo -e "${DIM}Type 'help' for detailed mode descriptions${NC}"
    
    local choice
    while true; do
        choice=$(prompt_with_exit "Enter your choice (1-5)" "2" "show_mode_help")
        case "$choice" in
            1)
                MODE="full"
                INSTALL_UI=true
                break
                ;;
            2)
                MODE="dev"
                INSTALL_UI=true
                break
                ;;
            3)
                MODE="minimal"
                INSTALL_UI=true
                break
                ;;
            4)
                MODE="api-only"
                INSTALL_UI=false
                echo ""
                echo -e "${BLUE}ℹ API-Only mode: You'll interact via KFP SDK (Python) instead of UI${NC}"
                echo -e "${DIM}  See: docs/KFP_WITHOUT_UI.md for complete guide${NC}"
                break
                ;;
            5)
                MODE="custom"
                echo ""
                echo -e "${BOLD}Custom module selection${NC}"
                echo ""
                echo "Available modules: ${GREEN}deps, cluster, kubeflow, dask, ray, components, devtools${NC}"
                echo -e "${DIM}Type 'help' to see module descriptions${NC}"
                CUSTOM_MODULES=$(prompt_with_exit "Enter comma-separated list of modules" "deps,cluster,kubeflow" "show_custom_modules_help")
                echo ""
                if prompt_yes_no "Include Kubeflow UI?" "y" "show_ui_help"; then
                    INSTALL_UI=true
                else
                    INSTALL_UI=false
                fi
                break
                ;;
            *)
                echo -e "${RED}Invalid choice. Please enter 1-5 (or type 'help' for details).${NC}"
                ;;
        esac
    done
    
    echo ""
    echo -e "${GREEN}✓ Selected mode: $MODE${NC}"
    if [[ "$INSTALL_UI" == "false" ]]; then
        echo -e "${BLUE}ℹ UI will not be installed (API-only mode)${NC}"
    fi
    sleep 1
}

validate_version_compatibility() {
    local k8s_ver="$1"
    local kfp_ver="$2"
    
    # Extract minor versions
    local k8s_minor=$(echo "$k8s_ver" | cut -d'.' -f2)
    local kfp_minor=$(echo "$kfp_ver" | cut -d'.' -f2)
    
    # Compatibility matrix
    # K8s 1.26: KFP 2.0, 2.1 only (not 2.2)
    # K8s 1.27: KFP 2.0, 2.1, 2.2
    # K8s 1.28: KFP 2.0, 2.1, 2.2
    # K8s 1.29: KFP 2.1, 2.2 only (not 2.0)
    
    case "$k8s_minor" in
        26)
            if [[ "$kfp_minor" -ge 2 ]]; then
                return 1  # K8s 1.26 doesn't support KFP 2.2+
            fi
            ;;
        29)
            if [[ "$kfp_minor" -eq 0 ]]; then
                return 1  # K8s 1.29 doesn't support KFP 2.0
            fi
            ;;
    esac
    
    return 0
}

select_or_create_cluster() {
    print_step "3/8" "Select or Create Cluster"
    
    echo "Scanning for existing K3d clusters..."
    echo ""
    
    # Check if cluster-list-detailed.sh exists
    if [[ ! -f "$SCRIPT_DIR/scripts/cluster-list-detailed.sh" ]]; then
        log_warning "Cluster listing script not found, will create new cluster"
        USE_EXISTING_CLUSTER=false
        CLUSTER_NAME="kfp-dev"
        return
    fi
    
    # Get existing clusters (suppress debug output)
    local cluster_list
    cluster_list=$("$SCRIPT_DIR/scripts/cluster-list-detailed.sh" 2>/dev/null || echo "")
    
    # Check if any clusters exist
    if [[ -z "$cluster_list" ]] || ! echo "$cluster_list" | grep -q "CLUSTER NAME"; then
        echo -e "${CYAN}No existing K3d clusters found.${NC}"
        echo ""
        echo "A new cluster will be created with:"
        echo "  • Name: kfp-dev"
        echo "  • You'll choose K8s and KFP versions in the next step"
        echo ""
        USE_EXISTING_CLUSTER=false
        CLUSTER_NAME="kfp-dev"
        sleep 2
        return
    fi
    
    # Display existing clusters
    echo -e "${GREEN}Found existing K3d clusters:${NC}"
    echo "$cluster_list"
    echo ""
    
    # Extract cluster names for selection
    local cluster_names
    cluster_names=$(echo "$cluster_list" | grep -v "CLUSTER NAME" | grep -v "━" | awk '{print $1}' | grep -v "^$")
    
    if [[ -z "$cluster_names" ]]; then
        echo -e "${CYAN}No clusters available for selection.${NC}"
        USE_EXISTING_CLUSTER=false
        CLUSTER_NAME="kfp-dev"
        return
    fi
    
    # Build selection menu
    echo -e "${BOLD}What would you like to do?${NC}"
    echo ""
    
    local option_num=1
    declare -A CLUSTER_MAP
    
    # List existing clusters
    while IFS= read -r cluster_name; do
        [[ -z "$cluster_name" ]] && continue
        echo "  $option_num) Use existing cluster: ${GREEN}$cluster_name${NC}"
        CLUSTER_MAP[$option_num]="$cluster_name"
        option_num=$((option_num + 1))
    done <<< "$cluster_names"
    
    # Add option to create new cluster
    local create_option=$option_num
    echo "  $create_option) ${CYAN}Create a new cluster${NC}"
    echo ""
    
    # Get user choice
    local choice
    while true; do
        choice=$(prompt_with_exit "Enter your choice (1-$create_option)" "$create_option")
        
        if [[ "$choice" =~ ^[0-9]+$ ]] && [[ "$choice" -ge 1 ]] && [[ "$choice" -le "$create_option" ]]; then
            break
        else
            echo -e "${RED}Invalid choice. Please enter a number between 1 and $create_option${NC}"
        fi
    done
    
    # Process choice
    if [[ "$choice" == "$create_option" ]]; then
        # Create new cluster
        USE_EXISTING_CLUSTER=false
        echo ""
        CLUSTER_NAME=$(prompt_with_exit "Enter name for new cluster" "kfp-dev")
        echo ""
        echo -e "${GREEN}✓ Will create new cluster: $CLUSTER_NAME${NC}"
    else
        # Use existing cluster
        USE_EXISTING_CLUSTER=true
        CLUSTER_NAME="${CLUSTER_MAP[$choice]}"
        echo ""
        echo -e "${GREEN}✓ Selected existing cluster: $CLUSTER_NAME${NC}"
        
        # Get cluster details
        echo ""
        echo "Fetching cluster details..."
        local context="k3d-$CLUSTER_NAME"
        
        # Switch to cluster context
        if kubectl config use-context "$context" &>/dev/null; then
            # Get K8s version
            K8S_VERSION=$(kubectl version --short 2>/dev/null | grep "Server Version" | awk '{print $3}' | sed 's/v//' || echo "unknown")
            
            # Get KFP version
            if kubectl get namespace kubeflow &>/dev/null 2>&1; then
                KFP_VERSION=$(kubectl get deployment -n kubeflow ml-pipeline -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null | grep -o '[0-9]\+\.[0-9]\+\.[0-9]\+' | head -1 || echo "unknown")
            else
                KFP_VERSION="not-installed"
            fi
            
            echo ""
            echo -e "${BOLD}Cluster Information:${NC}"
            echo "  • Cluster: $CLUSTER_NAME"
            echo "  • Kubernetes: $K8S_VERSION"
            echo "  • KFP: $KFP_VERSION"
            echo ""
        else
            log_warning "Could not connect to cluster $CLUSTER_NAME"
            K8S_VERSION="unknown"
            KFP_VERSION="unknown"
        fi
    fi
    
    sleep 1
}

select_versions() {
    print_step "4/8" "Select Kubernetes and Kubeflow Versions"
    
    # Skip if using existing cluster with known versions
    if [[ "$USE_EXISTING_CLUSTER" == "true" ]] && [[ -n "$K8S_VERSION" ]] && [[ "$K8S_VERSION" != "unknown" ]]; then
        echo "Using versions from existing cluster '$CLUSTER_NAME':"
        echo "  • Kubernetes: $K8S_VERSION"
        echo "  • Kubeflow Pipelines: ${KFP_VERSION}"
        echo ""
        sleep 1
        return
    fi
    
    if [[ -n "$K8S_VERSION" ]] && [[ -n "$KFP_VERSION" ]]; then
        echo "Kubernetes version: $K8S_VERSION (pre-selected)"
        echo "Kubeflow Pipelines version: $KFP_VERSION (pre-selected)"
        return
    fi
    
    echo "Supported version combinations:"
    echo ""
    echo "  Kubernetes  │  KFP 2.0.5  │  KFP 2.1.0  │  KFP 2.2.0"
    echo "  ────────────┼─────────────┼─────────────┼─────────────"
    echo "  1.26        │      ✓      │      ✓      │      ✗"
    echo "  1.27        │      ✓      │      ✓      │      ✓"
    echo "  1.28        │      ✓      │      ✓      │      ✓       ← Recommended"
    echo "  1.29        │      ✗      │      ✓      │      ✓"
    echo ""
    echo -e "${DIM}Type 'help' for version compatibility details${NC}"
    echo ""
    
    K8S_VERSION=$(prompt_with_exit "Kubernetes version" "1.28.5" "show_version_help")
    KFP_VERSION=$(prompt_with_exit "Kubeflow Pipelines version" "2.1.0" "show_version_help")
    
    # Validate compatibility
    if ! validate_version_compatibility "$K8S_VERSION" "$KFP_VERSION"; then
        echo ""
        echo -e "${RED}⚠ Warning: This version combination may not be compatible!${NC}"
        echo -e "${YELLOW}  K8s $K8S_VERSION + KFP $KFP_VERSION${NC}"
        echo -e "${YELLOW}  Please refer to the compatibility matrix above${NC}"
        echo ""
        if ! prompt_yes_no "Continue anyway? (not recommended)" "n"; then
            echo ""
            echo "Please select compatible versions"
            sleep 1
            select_versions
            return
        fi
        echo ""
        echo -e "${YELLOW}⚠ Proceeding with potentially incompatible versions${NC}"
    fi
    
    echo ""
    echo -e "${GREEN}✓ Selected K8s $K8S_VERSION + KFP $KFP_VERSION${NC}"
    sleep 1
}

create_installation_plan() {
    print_step "5/8" "Creating Installation Plan"
    
    echo "Based on your system and selections, here's what will be done:"
    echo ""
    
    # Determine what needs to be installed
    if [[ ${#MISSING_DEPS[@]} -gt 0 ]]; then
        echo -e "${BOLD}Missing Dependencies (will be installed):${NC}"
        for dep in "${MISSING_DEPS[@]}"; do
            case "$dep" in
                "docker")
                    print_plan_item "Install Docker" "Container runtime (manual installation required)"
                    INSTALLATION_PLAN+=("install-docker-manual")
                    ;;
                "k3d")
                    print_plan_item "Install k3d" "Lightweight Kubernetes for local development"
                    INSTALLATION_PLAN+=("install-k3d")
                    ;;
                "kubectl")
                    print_plan_item "Install kubectl" "Kubernetes command-line tool"
                    INSTALLATION_PLAN+=("install-kubectl")
                    ;;
                "helm")
                    print_plan_item "Install Helm" "Kubernetes package manager"
                    INSTALLATION_PLAN+=("install-helm")
                    ;;
                "yq")
                    print_plan_item "Install yq" "YAML processor"
                    INSTALLATION_PLAN+=("install-yq")
                    ;;
                "python3")
                    print_plan_item "Install Python 3" "Python runtime (manual installation required)"
                    INSTALLATION_PLAN+=("install-python-manual")
                    ;;
            esac
        done
        echo ""
    else
        echo -e "${GREEN}✓ All dependencies are already installed!${NC}"
        echo ""
    fi
    
    # Check if Docker needs to be started
    if [[ " ${DETECTED_DEPS[@]} " =~ " docker " ]] && ! docker info &> /dev/null; then
        echo -e "${BOLD}Prerequisites:${NC}"
        print_plan_item "Start Docker" "Docker daemon must be running"
        INSTALLATION_PLAN+=("start-docker")
        echo ""
    fi
    
    # Kubernetes and Kubeflow installation
    echo -e "${BOLD}Main Installation:${NC}"
    
    if [[ "$USE_EXISTING_CLUSTER" == "true" ]]; then
        print_plan_item "Use existing cluster" "Cluster: $CLUSTER_NAME (k8s $K8S_VERSION)"
        INSTALLATION_PLAN+=("use-existing-cluster")
    else
        print_plan_item "Create k3d cluster" "Kubernetes cluster (k8s $K8S_VERSION, name: ${CLUSTER_NAME:-kfp-dev})"
        INSTALLATION_PLAN+=("create-cluster")
    fi
    
    if [[ "$INSTALL_UI" == "true" ]]; then
        print_plan_item "Install Kubeflow Pipelines" "ML workflow platform with UI (KFP $KFP_VERSION)"
        INSTALLATION_PLAN+=("install-kubeflow")
    else
        print_plan_item "Install Kubeflow Pipelines (API)" "Backend only, no UI (KFP $KFP_VERSION)"
        INSTALLATION_PLAN+=("install-kubeflow-api")
        echo -e "    ${CYAN}→ You'll use KFP SDK to submit/monitor pipelines${NC}"
    fi
    
    # Optional modules based on mode
    if [[ "$MODE" == "full" ]] || [[ "$MODE" == "dev" ]] || [[ "$MODE" == "api-only" ]]; then
        print_plan_item "Setup dev tools" "Python packages and development utilities (includes KFP SDK)"
        INSTALLATION_PLAN+=("install-devtools")
    fi
    
    if [[ "$MODE" == "full" ]]; then
        print_plan_item "Install Dask operator" "Distributed computing framework"
        INSTALLATION_PLAN+=("install-dask")
        
        print_plan_item "Install Ray operator" "Distributed ML framework"
        INSTALLATION_PLAN+=("install-ray")
        
        print_plan_item "Build ML components" "Custom pipeline components"
        INSTALLATION_PLAN+=("build-components")
    fi
    
    echo ""
    
    # Estimated time
    local estimated_time="5-10 minutes"
    if [[ "$MODE" == "full" ]]; then
        estimated_time="15-20 minutes"
    fi
    echo -e "${CYAN}Estimated installation time: $estimated_time${NC}"
    
    sleep 2
}

show_confirmation_help() {
    echo -e "${CYAN}━━━ Installation Confirmation Help ━━━${NC}"
    echo ""
    echo "This is your last chance to review before installation begins."
    echo ""
    echo -e "${BOLD}What will happen:${NC}"
    echo "  • Selected modules will be installed"
    echo "  • Kubernetes cluster will be created (if selected)"
    echo "  • Kubeflow Pipelines will be deployed (if selected)"
    echo "  • Development tools will be set up (if selected)"
    echo ""
    echo -e "${BOLD}Options:${NC}"
    echo "  • Type 'y' or 'yes' to proceed with installation"
    echo "  • Type 'n' or 'no' to cancel and exit"
    echo "  • Type 'help' to see this message again"
    echo "  • Type 'exit' to quit"
    echo ""
    echo -e "${BOLD}Installation time:${NC}"
    case "$MODE" in
        full)
            echo "  • Approximately 15-20 minutes"
            ;;
        dev|api-only)
            echo "  • Approximately 5-10 minutes"
            ;;
        minimal)
            echo "  • Approximately 5 minutes"
            ;;
        *)
            echo "  • Varies based on selected modules"
            ;;
    esac
    echo ""
    echo -e "${YELLOW}Note:${NC} Installation time may be faster if dependencies are already installed."
    echo ""
}

confirm_installation() {
    print_step "6/8" "Confirmation"
    
    echo "Installation Summary:"
    echo ""
    echo "  Mode: $MODE"
    echo "  Kubernetes: $K8S_VERSION"
    echo "  Kubeflow Pipelines: $KFP_VERSION"
    if [[ "$INSTALL_UI" == "true" ]]; then
        echo "  UI: Included (access via http://localhost:8080)"
    else
        echo "  UI: Not included (API-only mode)"
    fi
    echo "  Steps to execute: ${#INSTALLATION_PLAN[@]}"
    echo ""
    
    if $DRY_RUN; then
        echo -e "${YELLOW}DRY RUN MODE: No changes will be made${NC}"
        echo ""
        return 0
    fi
    
    echo -e "${DIM}Type 'help' for more details about what will happen${NC}"
    
    if ! prompt_yes_no "Proceed with installation?" "y" "show_confirmation_help"; then
        echo ""
        echo -e "${YELLOW}Installation cancelled. Exiting...${NC}"
        exit 0
    fi
    
    echo ""
}

execute_installation() {
    if $DRY_RUN; then
        print_step "7/8" "Dry Run Complete"
        echo ""
        echo -e "${GREEN}✓ Dry run completed successfully!${NC}"
        echo ""
        echo "To proceed with actual installation, run without --dry-run:"
        echo "  ./install-wizard.sh"
        echo ""
        return 0
    fi
    
    print_step "7/8" "Installing Kubeflow Development Environment"
    echo ""
    
    local step=1
    local total=${#INSTALLATION_PLAN[@]}
    
    for action in "${INSTALLATION_PLAN[@]}"; do
        echo -e "${CYAN}[$step/$total]${NC} Executing: $action"
        
        case "$action" in
            "install-docker-manual")
                echo -e "${RED}Error: Docker is not installed${NC}"
                echo ""
                echo "Please install Docker Desktop from: https://docs.docker.com/get-docker/"
                echo ""
                echo "After installing Docker:"
                echo "  1. Start Docker Desktop"
                echo "  2. Run this wizard again: ./install-wizard.sh"
                echo ""
                exit 1
                ;;
            
            "install-python-manual")
                echo -e "${RED}Error: Python 3 is not installed${NC}"
                echo ""
                echo "Please install Python 3.9+ from: https://www.python.org/downloads/"
                echo "  or via Homebrew: brew install python@3.11"
                echo ""
                exit 1
                ;;
            
            "start-docker")
                echo ""
                echo -e "${YELLOW}Docker is installed but not running.${NC}"
                echo ""
                echo "Please start Docker Desktop:"
                if [[ "$OSTYPE" == "darwin"* ]]; then
                    echo "  open -a Docker"
                else
                    echo "  sudo systemctl start docker"
                fi
                echo ""
                echo -e "${DIM}Press Ctrl+C to cancel if you want to start Docker manually${NC}"
                echo ""
                echo "Waiting for Docker to start..."
                
                local timeout=90
                local elapsed=0
                while ! docker info &> /dev/null && [[ $elapsed -lt $timeout ]]; do
                    echo -n "."
                    sleep 2
                    elapsed=$((elapsed + 2))
                done
                echo ""
                
                if docker info &> /dev/null; then
                    echo -e "${GREEN}✓ Docker is now running${NC}"
                else
                    echo -e "${RED}✗ Docker failed to start within $timeout seconds${NC}"
                    echo ""
                    echo "Please start Docker manually and run this wizard again."
                    echo "You can exit with Ctrl+C or type: exit"
                    exit 1
                fi
                ;;
            
            "install-k3d"|"install-kubectl"|"install-helm"|"install-yq")
                "$SCRIPT_DIR/install/install-deps.sh" || true
                ;;
            
            "use-existing-cluster")
                echo ""
                echo -e "${CYAN}Using existing cluster: $CLUSTER_NAME${NC}"
                # Switch to cluster context
                kubectl config use-context "k3d-$CLUSTER_NAME" &>/dev/null || {
                    echo -e "${RED}Failed to switch to cluster context${NC}"
                    exit 1
                }
                echo -e "${GREEN}✓ Switched to cluster: $CLUSTER_NAME${NC}"
                ;;
            
            "create-cluster")
                echo ""
                local cluster_args="--k8s $K8S_VERSION --kfp $KFP_VERSION --skip-kfp --skip-existing"
                if [[ -n "$CLUSTER_NAME" ]] && [[ "$CLUSTER_NAME" != "kfp-dev" ]]; then
                    cluster_args="$cluster_args --name $CLUSTER_NAME"
                fi
                "$SCRIPT_DIR/scripts/cluster-create.sh" $cluster_args
                ;;
            
            "install-kubeflow")
                echo ""
                "$SCRIPT_DIR/scripts/install-kubeflow.sh" --version "$KFP_VERSION"
                ;;
            
            "install-kubeflow-api")
                echo ""
                echo -e "${CYAN}Installing Kubeflow Pipelines backend (API-only, no UI)...${NC}"
                # Note: The standard install includes UI. For API-only, we'd need to customize the manifest.
                # For now, install standard and user can ignore UI.
                "$SCRIPT_DIR/scripts/install-kubeflow.sh" --version "$KFP_VERSION"
                echo -e "${BLUE}ℹ Note: Full KFP installed. You can use SDK to interact programmatically.${NC}"
                echo -e "${BLUE}  See: docs/KFP_WITHOUT_UI.md for details${NC}"
                ;;
            
            "install-devtools")
                echo ""
                echo -e "${CYAN}Installing development tools...${NC}"
                if "$SCRIPT_DIR/install/install-dev-tools.sh"; then
                    echo -e "${GREEN}✓ Development tools installed${NC}"
                else
                    echo -e "${YELLOW}⚠ Some dev tools may not have installed correctly${NC}"
                    echo -e "${YELLOW}  You can install them later with: ./install/install-dev-tools.sh${NC}"
                fi
                ;;
            
            "install-dask")
                echo ""
                echo -e "${CYAN}Installing Dask operator...${NC}"
                if "$SCRIPT_DIR/scripts/install-operators.sh" --dask; then
                    echo -e "${GREEN}✓ Dask operator installed${NC}"
                else
                    echo -e "${RED}✗ Dask operator installation failed${NC}"
                    echo -e "${YELLOW}  You can install it later with: ./scripts/install-operators.sh --dask${NC}"
                fi
                ;;
            
            "install-ray")
                echo ""
                echo -e "${CYAN}Installing Ray operator...${NC}"
                if "$SCRIPT_DIR/scripts/install-operators.sh" --ray; then
                    echo -e "${GREEN}✓ Ray operator installed${NC}"
                else
                    echo -e "${RED}✗ Ray operator installation failed${NC}"
                    echo -e "${YELLOW}  You can install it later with: ./scripts/install-operators.sh --ray${NC}"
                fi
                ;;
            
            "build-components")
                echo ""
                # Validate components directory exists
                if [[ ! -d "$SCRIPT_DIR/components" ]]; then
                    echo -e "${RED}✗ Components directory not found${NC}"
                    echo -e "${YELLOW}  Skipping component build${NC}"
                else
                    local component_count=$(find "$SCRIPT_DIR/components" -mindepth 1 -maxdepth 1 -type d ! -name "component-template" 2>/dev/null | wc -l | tr -d ' ')
                    if [[ "$component_count" -eq 0 ]]; then
                        echo -e "${YELLOW}⚠ No components found to build${NC}"
                    else
                        echo -e "${CYAN}Building $component_count component(s)...${NC}"
                        if "$SCRIPT_DIR/build/build-all.sh" --tag latest; then
                            echo -e "${GREEN}✓ Components built successfully${NC}"
                        else
                            echo -e "${RED}✗ Component build failed${NC}"
                            echo -e "${YELLOW}  You can build them later with: make build-all${NC}"
                        fi
                    fi
                fi
                ;;
            
            *)
                echo -e "${YELLOW}Unknown action: $action (skipping)${NC}"
                ;;
        esac
        
        step=$((step + 1))
        echo ""
    done
    
    # Verify installation
    echo -e "${CYAN}Verifying installation...${NC}"
    "$SCRIPT_DIR/install/verify-installation.sh" || log_warning "Some verification checks failed"
    echo ""
}

print_completion() {
    print_step "8/8" "Installation Complete!"
    echo ""
    echo -e "${GREEN}${BOLD}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║                   ✓ Installation Complete! ✓                         ║
║                                                                       ║
╚═══════════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    echo ""
    echo -e "${BOLD}Next Steps:${NC}"
    echo ""
    
    if [[ "$INSTALL_UI" == "true" ]]; then
        echo "  1. Access Kubeflow Pipelines UI:"
        echo -e "     ${CYAN}make port-forward${NC}"
        echo "     Then open: http://localhost:8080"
        echo ""
        echo "  2. Run your first pipeline (via UI or SDK):"
        echo -e "     ${CYAN}make deploy-pipeline PIPELINE=gbm-training${NC}"
        echo ""
    else
        echo "  1. Install KFP SDK (if not already done):"
        echo -e "     ${CYAN}pip install kfp${NC}"
        echo ""
        echo "  2. Run your first pipeline programmatically:"
        echo -e "     ${CYAN}python pipelines/gbm-training-pipeline.py --run${NC}"
        echo ""
        echo "  3. Monitor runs via kubectl:"
        echo -e "     ${CYAN}kubectl get pods -n kubeflow${NC}"
        echo -e "     ${CYAN}kubectl logs -n kubeflow <pod-name>${NC}"
        echo ""
        echo "  📖 Learn more about API-only workflow:"
        echo -e "     ${CYAN}cat docs/KFP_WITHOUT_UI.md${NC}"
        echo ""
    fi
    
    echo "  3. Check cluster status:"
    echo -e "     ${CYAN}kubectl get pods -n kubeflow${NC}"
    echo ""
    echo -e "${BOLD}Helpful Commands:${NC}"
    echo "  • View all commands:      make help"
    echo "  • Build components:       make build-all"
    echo "  • Run tests:              make test-unit"
    echo "  • Troubleshooting:        ./scripts/diagnose.sh"
    echo ""
    echo -e "${BOLD}Documentation:${NC}"
    echo "  • User Guide:    docs/USER_GUIDE.md"
    echo "  • FAQ:           docs/FAQ.md"
    echo "  • Troubleshoot:  docs/TROUBLESHOOTING.md"
    echo ""
    echo -e "${GREEN}Happy ML pipelining! 🚀${NC}"
    echo ""
}

# Main execution
main() {
    print_banner
    
    detect_system
    select_installation_mode
    select_or_create_cluster
    select_versions
    create_installation_plan
    confirm_installation
    execute_installation
    
    if ! $DRY_RUN; then
        print_completion
    fi
}

main
