# Contributing Guide

Thank you for contributing to the Kubeflow Development Environment!

## Ways to Contribute

1. 🐛 Report bugs
2. 💡 Suggest features
3. 📝 Improve documentation
4. 🧪 Add tests
5. 🔧 Add components
6. 🎨 Improve UX

## Getting Started

1. Fork the repository
2. Clone your fork
3. Install development environment:
   ```bash
   ./install.sh --mode dev --k8s 1.28 --kfp 2.1.0
   ```
4. Create a branch from `develop`
5. Make your changes
6. Run tests
7. Submit a PR

## Development Setup

```bash
# Install pre-commit hooks
pip install pre-commit
pre-commit install

# Run unit tests
make test-unit

# Run integration tests (requires cluster)
make test-integration
```

## Code Standards

- **Python**: PEP 8, Black formatting, type hints
- **Shell**: ShellCheck compliant
- **Commits**: Conventional commits

### Commit Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`, `ci`

## Adding Components

1. Use component template:
   ```bash
   cp -r components/component-template components/my-component
   ```
2. Implement component logic
3. Add tests
4. Build and test:
   ```bash
   make build-component COMPONENT=my-component
   make test-component COMPONENT=my-component
   ```
5. Document in `components/my-component/README.md`

## Testing Requirements

- Unit tests for all new code
- Integration tests for components
- E2E tests for new pipelines
- Minimum 80% coverage

## Documentation Requirements

- Update relevant docs
- Add docstrings/comments
- Update CHANGELOG.md
- Add examples if needed

## Pull Request Process

1. Update CHANGELOG.md
2. Ensure all tests pass
3. Update documentation
4. Request review
5. Address feedback
6. Squash commits if needed

## For Data Scientists

Don't worry if you're not familiar with K8s/Docker!
- Focus on component logic (Python)
- Use templates and examples
- Ask questions in issues/discussions
- We'll help with K8s/infra parts

## Questions?

- Check [FAQ](docs/FAQ.md)
- Submit an issue
