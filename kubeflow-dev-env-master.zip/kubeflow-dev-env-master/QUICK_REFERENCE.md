# 🚀 Quick Reference - Kubeflow Dev Environment

## Your System Status

```
✅ Docker       /usr/local/bin/docker
✅ k3d          /opt/homebrew/bin/k3d
✅ kubectl      /usr/local/bin/kubectl
✅ Helm         /opt/homebrew/bin/helm
✅ Python 3     /Users/hkk/miniconda3/bin/python3

⚠️  Docker needs to be started
⏱️  Installation: 5-10 min (vs typical 20-30 min)
```

---

## Installation Commands

### Check Resources First (Recommended) 📊

```bash
# Check system resources before installing
./scripts/check-resources.sh

# Detailed check
./scripts/check-resources.sh --detailed
```

**You'll see:**
- Disk space: Need 10GB+ free (20GB+ recommended)
- Docker memory: Need 4GB+ (8GB+ recommended)
- Downloads: ~1.6GB minimal, ~3.5GB full
- Current Docker usage

### Option 1: Wizard (Recommended) ⭐
```bash
open -a Docker                # Start Docker
./install-wizard.sh           # Run wizard

# Pro Tips:
# - Type 'help' at any prompt for context-specific help
# - Type 'exit' to quit gracefully (instead of Ctrl+C)
```

### Option 2: Dry Run First
```bash
./install-wizard.sh --dry-run # Test without changes
```

### Option 3: Non-Interactive
```bash
./install-wizard.sh --non-interactive  # Use defaults
```

### Option 4: Traditional
```bash
./install.sh --mode dev --k8s 1.28.5 --kfp 2.1.0
```

---

## Post-Installation Commands

```bash
# Access UI
make port-forward
open http://localhost:8080

# Deploy pipeline
make deploy-pipeline PIPELINE=gbm-training

# Check status
./scripts/diagnose.sh
kubectl get pods -n kubeflow

# All commands
make help
```

---

## Installation Modes

| Mode | Time | Contents |
|------|------|----------|
| **Minimal** | ~5 min | Cluster + KFP |
| **Dev** ⭐ | ~5-10 min | + Dev Tools |
| **API-Only** | ~5-10 min | Backend only (no UI focus) |
| **Full** | ~15-20 min | + Operators + Components |

**Note:** You can exit wizard anytime by typing `exit`

---

## Documentation Index

### Quick Start
- `START_HERE.md` - 3-step quick start
- `WIZARD_QUICKSTART.md` - Wizard guide
- `docs/QUICKSTART.md` - 5-minute start

### Status & Reports
- `SYSTEM_STATUS.md` - Visual status
- `DRY_RUN_SUMMARY.md` - Dry run report
- `IMPROVEMENTS_SUMMARY.md` - What's new

### Main Docs
- `README.md` - Overview
- `docs/USER_GUIDE.md` - Full guide
- `docs/FAQ.md` - Questions
- `docs/TROUBLESHOOTING.md` - Help

---

## Troubleshooting

### Docker Not Running
```bash
open -a Docker
sleep 30
docker info
```

### Port 5000 in Use (macOS)
```
System Settings > General > AirDrop & Handoff
Disable: AirPlay Receiver
```

### Not Enough Memory
```
Docker Desktop > Settings > Resources
Memory: 8GB
Apply & Restart
```

### Diagnostics
```bash
./scripts/diagnose.sh
```

---

## Key Differences: Traditional vs Wizard

| Feature | Traditional | Wizard |
|---------|------------|--------|
| Detects installed | ❌ | ✅ |
| Interactive | ❌ | ✅ |
| Shows plan | ❌ | ✅ |
| Time estimate | ❌ | ✅ |
| Skips installed | ❌ | ✅ |
| Your time | 20-30 min | 5-10 min |

---

## Verification Steps

```bash
# 1. Check Docker
docker info

# 2. Check cluster
kubectl cluster-info

# 3. Check Kubeflow
kubectl get pods -n kubeflow

# 4. Check all pods
kubectl get pods --all-namespaces

# 5. Full diagnostics
./scripts/diagnose.sh
```

---

## Version Compatibility

| K8s | KFP 2.0.5 | KFP 2.1.0 | KFP 2.2.0 |
|-----|-----------|-----------|-----------|
| 1.26 | ✅ | ✅ | ❌ |
| 1.27 | ✅ | ✅ | ✅ |
| 1.28 ⭐ | ✅ | ✅ | ✅ |
| 1.29 | ❌ | ✅ | ✅ |

**Recommended:** K8s 1.28.5 + KFP 2.1.0

---

## Common Make Commands

```bash
make install         # Install everything
make cluster-create  # Create cluster
make cluster-destroy # Destroy cluster
make port-forward    # Access UI
make build-all       # Build components
make test-unit       # Run unit tests
make help           # Show all commands
```

---

## File Locations

```
📁 Project Structure
├── install-wizard.sh          # New intelligent wizard
├── install.sh                 # Traditional installer
├── START_HERE.md             # Quick start guide
├── WIZARD_QUICKSTART.md      # Wizard documentation
├── SYSTEM_STATUS.md          # System status
├── DRY_RUN_SUMMARY.md        # Evaluation summary
├── README.md                 # Project overview
├── Makefile                  # Common commands
├── scripts/
│   ├── diagnose.sh          # Diagnostics
│   ├── preflight-check.sh   # Pre-install checks
│   └── ...
├── docs/
│   ├── USER_GUIDE.md        # Complete guide
│   ├── FAQ.md               # Questions
│   └── TROUBLESHOOTING.md   # Help
└── components/
    └── ...                   # ML components
```

---

## Time Estimates

### Your System (deps installed)
- Minimal: 5 min
- Dev: 5-10 min ⚡
- Full: 15-20 min

### Fresh System (no deps)
- Minimal: 15-20 min
- Dev: 20-30 min
- Full: 30-40 min

**You save:** 67% installation time!

---

## Next Steps After Install

1. ✅ `make port-forward` - Access UI
2. ✅ `open http://localhost:8080` - Open browser
3. ✅ `make deploy-pipeline PIPELINE=gbm-training` - First pipeline
4. ✅ Read `docs/USER_GUIDE.md` - Learn more

---

## Support Resources

- **Wizard Help:** `./install-wizard.sh --help`
- **System Status:** `SYSTEM_STATUS.md`
- **Full Guide:** `docs/USER_GUIDE.md`
- **FAQ:** `docs/FAQ.md`
- **Troubleshooting:** `docs/TROUBLESHOOTING.md`
- **Diagnostics:** `./scripts/diagnose.sh`

---

## Quick Installation (Copy-Paste)

```bash
# Complete installation in one command
open -a Docker && sleep 30 && ./install-wizard.sh
```

---

**Questions?** Check `START_HERE.md` or `docs/FAQ.md`  
**Problems?** Run `./scripts/diagnose.sh`  
**Ready?** Run `./install-wizard.sh` 🚀
