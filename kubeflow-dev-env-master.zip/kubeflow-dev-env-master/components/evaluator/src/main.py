#!/usr/bin/env python3
"""
Model Evaluator Component

Evaluate trained models with various metrics and cross-validation.
"""

import argparse
import json
import logging
import pickle
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)
from sklearn.model_selection import cross_val_score, KFold

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def load_model(model_path: str) -> Any:
    """Load model from pickle file."""
    with open(model_path, "rb") as f:
        return pickle.load(f)


def load_data(data_path: str) -> dict:
    """Load data from JSON file."""
    with open(data_path, "r") as f:
        return json.load(f)


def evaluate_model(
    model: Any,
    X_test: np.ndarray,
    y_test: np.ndarray,
    X_train: np.ndarray = None,
    y_train: np.ndarray = None,
    cv_folds: int = 10,
    random_state: int = 10
) -> dict:
    """Evaluate model with various metrics."""
    
    # Predictions
    y_pred = model.predict(X_test)
    
    # Basic metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted')
    recall = recall_score(y_test, y_pred, average='weighted')
    f1 = f1_score(y_test, y_pred, average='weighted')
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    
    # Classification report
    report = classification_report(y_test, y_pred, output_dict=True)
    
    evaluation = {
        "accuracy": float(accuracy),
        "precision": float(precision),
        "recall": float(recall),
        "f1_score": float(f1),
        "confusion_matrix": cm.tolist(),
        "classification_report": report
    }
    
    # Cross-validation if training data provided
    if X_train is not None and y_train is not None:
        logger.info(f"Running {cv_folds}-fold cross-validation...")
        cv = KFold(n_splits=cv_folds, shuffle=True, random_state=random_state)
        cv_scores = cross_val_score(model, X_train, y_train, cv=cv)
        
        evaluation["cv_accuracy_mean"] = float(cv_scores.mean())
        evaluation["cv_accuracy_std"] = float(cv_scores.std())
        evaluation["cv_scores"] = cv_scores.tolist()
    
    return evaluation


def compare_models(evaluations: list) -> dict:
    """Compare multiple model evaluations."""
    comparison = {
        "models": [],
        "best_model": None,
        "best_accuracy": 0.0
    }
    
    for eval_result in evaluations:
        model_name = eval_result.get("model_name", "unknown")
        accuracy = eval_result.get("accuracy", 0.0)
        
        comparison["models"].append({
            "name": model_name,
            "accuracy": accuracy,
            "f1_score": eval_result.get("f1_score", 0.0)
        })
        
        if accuracy > comparison["best_accuracy"]:
            comparison["best_accuracy"] = accuracy
            comparison["best_model"] = model_name
    
    return comparison


def save_json(data: dict, output_path: str) -> None:
    """Save data as JSON."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def save_metrics(metrics: dict, metrics_path: str) -> None:
    """Save metrics in KFP format."""
    path = Path(metrics_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    kfp_metrics = {
        "metrics": [
            {"name": k, "numberValue": v}
            for k, v in metrics.items()
            if isinstance(v, (int, float))
        ]
    }
    with open(path, "w") as f:
        json.dump(kfp_metrics, f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="Model Evaluator Component")
    parser.add_argument("--model", type=str, required=True,
                        help="Path to trained model (pickle)")
    parser.add_argument("--input-data", type=str, required=True,
                        help="Path to input data (from data-loader)")
    parser.add_argument("--cv-folds", type=int, default=10,
                        help="Number of cross-validation folds")
    parser.add_argument("--random-state", type=int, default=10,
                        help="Random seed")
    parser.add_argument("--output-evaluation", type=str, required=True,
                        help="Path for evaluation results")
    parser.add_argument("--metrics", type=str, required=True,
                        help="Path for KFP metrics")
    
    args = parser.parse_args()
    
    logger.info("Loading model...")
    model = load_model(args.model)
    
    logger.info("Loading data...")
    data = load_data(args.input_data)
    
    X_train = np.array(data["X_train"])
    X_test = np.array(data["X_test"])
    y_train = np.array(data["y_train"])
    y_test = np.array(data["y_test"])
    
    logger.info("Evaluating model...")
    evaluation = evaluate_model(
        model,
        X_test, y_test,
        X_train, y_train,
        cv_folds=args.cv_folds,
        random_state=args.random_state
    )
    
    logger.info(f"Test Accuracy: {evaluation['accuracy']:.4f}")
    logger.info(f"F1 Score: {evaluation['f1_score']:.4f}")
    if "cv_accuracy_mean" in evaluation:
        logger.info(f"CV Accuracy: {evaluation['cv_accuracy_mean']:.4f} "
                   f"(+/- {evaluation['cv_accuracy_std']:.4f})")
    
    # Save outputs
    save_json(evaluation, args.output_evaluation)
    
    metrics = {
        "accuracy": evaluation["accuracy"],
        "precision": evaluation["precision"],
        "recall": evaluation["recall"],
        "f1_score": evaluation["f1_score"]
    }
    if "cv_accuracy_mean" in evaluation:
        metrics["cv_accuracy"] = evaluation["cv_accuracy_mean"]
    
    save_metrics(metrics, args.metrics)
    
    logger.info("Evaluation complete!")


if __name__ == "__main__":
    main()
