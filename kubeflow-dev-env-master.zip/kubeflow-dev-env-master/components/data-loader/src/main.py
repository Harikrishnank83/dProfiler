#!/usr/bin/env python3
"""
Data Loader Component

Loads and preprocesses datasets for ML training.
Supports breast cancer dataset from sklearn and custom datasets.
"""

import argparse
import json
import logging
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def load_breast_cancer_data() -> tuple[np.ndarray, np.ndarray, list, list]:
    """Load the breast cancer dataset from sklearn."""
    logger.info("Loading breast cancer dataset...")
    data = load_breast_cancer()
    X = data.data
    y = data.target
    feature_names = list(data.feature_names)
    target_names = list(data.target_names)
    
    logger.info(f"Loaded dataset: {X.shape[0]} samples, {X.shape[1]} features")
    return X, y, feature_names, target_names


def compute_base_rate(y: np.ndarray) -> dict:
    """
    Compute the base rate of malignant cancer (label=0).
    From hw1_programming_base_notebook: Question 1
    """
    malignant_count = np.sum(y == 0)
    total_count = len(y)
    base_rate = malignant_count / total_count
    
    return {
        "total_samples": int(total_count),
        "malignant_samples": int(malignant_count),
        "benign_samples": int(total_count - malignant_count),
        "base_rate_malignant": float(base_rate),
        "base_rate_malignant_pct": float(base_rate * 100)
    }


def split_data(
    X: np.ndarray,
    y: np.ndarray,
    test_size: float = 0.2,
    random_state: int = 10
) -> dict:
    """Split data into train and test sets."""
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    
    return {
        "X_train": X_train.tolist(),
        "X_test": X_test.tolist(),
        "y_train": y_train.tolist(),
        "y_test": y_test.tolist(),
        "train_size": len(X_train),
        "test_size": len(X_test)
    }


def save_output(data: dict, output_path: str) -> None:
    """Save output data as JSON."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f)


def save_metrics(metrics: dict, metrics_path: str) -> None:
    """Save metrics in KFP format."""
    path = Path(metrics_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    kfp_metrics = {
        "metrics": [
            {"name": k, "numberValue": v if isinstance(v, (int, float)) else 0}
            for k, v in metrics.items()
        ]
    }
    with open(path, "w") as f:
        json.dump(kfp_metrics, f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="Data Loader Component")
    parser.add_argument("--dataset", type=str, default="breast_cancer",
                        help="Dataset to load (breast_cancer)")
    parser.add_argument("--test-size", type=float, default=0.2,
                        help="Test set size (0.0-1.0)")
    parser.add_argument("--random-state", type=int, default=10,
                        help="Random seed")
    parser.add_argument("--output-data", type=str, required=True,
                        help="Path for output data")
    parser.add_argument("--output-metadata", type=str, required=True,
                        help="Path for metadata output")
    parser.add_argument("--metrics", type=str, required=True,
                        help="Path for metrics output")
    
    args = parser.parse_args()
    
    logger.info(f"Loading dataset: {args.dataset}")
    
    # Load data
    if args.dataset == "breast_cancer":
        X, y, feature_names, target_names = load_breast_cancer_data()
    else:
        raise ValueError(f"Unknown dataset: {args.dataset}")
    
    # Compute base rate (from hw1 Question 1)
    base_rate_info = compute_base_rate(y)
    logger.info(f"Base rate of malignant cancer: {base_rate_info['base_rate_malignant_pct']:.2f}%")
    
    # Split data
    split_info = split_data(X, y, args.test_size, args.random_state)
    logger.info(f"Train size: {split_info['train_size']}, Test size: {split_info['test_size']}")
    
    # Prepare output
    output_data = {
        "X_train": split_info["X_train"],
        "X_test": split_info["X_test"],
        "y_train": split_info["y_train"],
        "y_test": split_info["y_test"],
        "feature_names": feature_names,
        "target_names": target_names
    }
    
    metadata = {
        "dataset": args.dataset,
        "n_features": len(feature_names),
        "n_samples": base_rate_info["total_samples"],
        "train_size": split_info["train_size"],
        "test_size": split_info["test_size"],
        "base_rate_info": base_rate_info,
        "random_state": args.random_state
    }
    
    metrics = {
        "total_samples": base_rate_info["total_samples"],
        "train_samples": split_info["train_size"],
        "test_samples": split_info["test_size"],
        "n_features": len(feature_names),
        "base_rate_malignant": base_rate_info["base_rate_malignant"]
    }
    
    # Save outputs
    save_output(output_data, args.output_data)
    save_output(metadata, args.output_metadata)
    save_metrics(metrics, args.metrics)
    
    logger.info("Data loading complete!")


if __name__ == "__main__":
    main()
