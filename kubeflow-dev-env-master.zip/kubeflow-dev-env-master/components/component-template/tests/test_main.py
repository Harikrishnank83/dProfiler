"""
Unit tests for Component Template.
"""

import json
import pytest
import tempfile
from pathlib import Path
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from main import process_data, load_input, save_output, save_metrics


class TestProcessData:
    """Tests for the process_data function."""
    
    def test_process_data_basic(self):
        """Test basic data processing."""
        input_data = {"key": "value"}
        output_data, metrics = process_data(input_data, "param1", 5)
        
        assert output_data == input_data
        assert "parameter_one" in metrics
        assert metrics["parameter_one"] == "param1"
        assert metrics["parameter_two"] == 5
    
    def test_process_data_with_list(self):
        """Test processing with list input."""
        input_data = [1, 2, 3, 4, 5]
        output_data, metrics = process_data(input_data, "test", 10)
        
        assert output_data == input_data
        assert metrics["input_size"] == 5


class TestLoadInput:
    """Tests for the load_input function."""
    
    def test_load_input_valid_file(self):
        """Test loading from valid JSON file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"test": "data"}, f)
            temp_path = f.name
        
        try:
            data = load_input(temp_path)
            assert data == {"test": "data"}
        finally:
            Path(temp_path).unlink()
    
    def test_load_input_missing_file(self):
        """Test loading from non-existent file."""
        data = load_input("/nonexistent/path.json")
        assert data is None


class TestSaveOutput:
    """Tests for the save_output function."""
    
    def test_save_output_creates_file(self):
        """Test that output file is created."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "subdir" / "output.json"
            data = {"result": "success"}
            
            save_output(data, str(output_path))
            
            assert output_path.exists()
            with open(output_path) as f:
                saved_data = json.load(f)
            assert saved_data == data


class TestSaveMetrics:
    """Tests for the save_metrics function."""
    
    def test_save_metrics_format(self):
        """Test metrics output format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            metrics_path = Path(tmpdir) / "metrics.json"
            metrics = {"accuracy": 0.95, "loss": 0.05}
            
            save_metrics(metrics, str(metrics_path))
            
            assert metrics_path.exists()
            with open(metrics_path) as f:
                saved = json.load(f)
            
            assert "metrics" in saved
            assert len(saved["metrics"]) == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
