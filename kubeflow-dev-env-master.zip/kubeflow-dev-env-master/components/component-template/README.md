# Component Template

This is a template for creating new Kubeflow Pipeline components.

## Structure

```
component-name/
├── src/
│   ├── __init__.py
│   └── main.py          # Component logic
├── tests/
│   └── test_main.py     # Unit tests
├── Dockerfile           # Component container
├── component.yaml       # KFP component specification
├── requirements.txt     # Component-specific dependencies
└── README.md           # Component documentation
```

## Creating a New Component

1. Copy this template:
   ```bash
   cp -r components/component-template components/my-component
   ```

2. Update `component.yaml` with your component's:
   - Name and description
   - Inputs and outputs
   - Container image reference

3. Implement your logic in `src/main.py`

4. Add tests in `tests/test_main.py`

5. Build the component:
   ```bash
   make build-component COMPONENT=my-component TAG=v1.0.0
   ```

6. Test locally:
   ```bash
   make test-component COMPONENT=my-component
   ```

## Component Guidelines

### Inputs and Outputs
- Use strongly typed inputs/outputs
- Document all parameters
- Provide sensible defaults

### Error Handling
- Log errors clearly
- Raise meaningful exceptions
- Clean up resources on failure

### Testing
- Write unit tests for core logic
- Mock external dependencies
- Test edge cases

### Documentation
- Update README with usage examples
- Document all parameters
- Include example pipeline usage
