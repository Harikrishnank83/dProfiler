# Component Template
"""
Template component package.
"""

__version__ = "1.0.0"
