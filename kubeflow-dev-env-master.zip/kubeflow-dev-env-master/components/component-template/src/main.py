#!/usr/bin/env python3
"""
Component Template - Main Entry Point

This is a template for building Kubeflow pipeline components.
Modify this file with your component's logic.
"""

import argparse
import json
import logging
from pathlib import Path
from typing import Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def process_data(
    input_data: Any,
    parameter_one: str,
    parameter_two: int
) -> tuple[Any, dict]:
    """
    Main processing logic for the component.
    
    Args:
        input_data: Input data to process
        parameter_one: First configuration parameter
        parameter_two: Second configuration parameter
        
    Returns:
        Tuple of (processed_data, metrics_dict)
    """
    logger.info(f"Processing with parameters: {parameter_one}, {parameter_two}")
    
    # TODO: Implement your processing logic here
    processed_data = input_data
    
    metrics = {
        "input_size": len(input_data) if hasattr(input_data, "__len__") else 0,
        "parameter_one": parameter_one,
        "parameter_two": parameter_two,
    }
    
    return processed_data, metrics


def load_input(input_path: str) -> Any:
    """Load input data from path."""
    path = Path(input_path)
    if path.exists():
        with open(path, "r") as f:
            return json.load(f)
    return None


def save_output(data: Any, output_path: str) -> None:
    """Save output data to path."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def save_metrics(metrics: dict, metrics_path: str) -> None:
    """Save metrics to path."""
    path = Path(metrics_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump({"metrics": [
            {"name": k, "numberValue": v if isinstance(v, (int, float)) else 0}
            for k, v in metrics.items()
        ]}, f, indent=2)


def main():
    """Main entry point for the component."""
    parser = argparse.ArgumentParser(description="Component Template")
    parser.add_argument("--input-data", type=str, required=True, help="Path to input data")
    parser.add_argument("--parameter-one", type=str, default="default", help="First parameter")
    parser.add_argument("--parameter-two", type=int, default=10, help="Second parameter")
    parser.add_argument("--output-data", type=str, required=True, help="Path for output data")
    parser.add_argument("--metrics", type=str, required=True, help="Path for metrics output")
    
    args = parser.parse_args()
    
    logger.info("Starting component execution")
    
    # Load input
    input_data = load_input(args.input_data)
    logger.info(f"Loaded input data from {args.input_data}")
    
    # Process
    output_data, metrics = process_data(
        input_data,
        args.parameter_one,
        args.parameter_two
    )
    
    # Save outputs
    save_output(output_data, args.output_data)
    logger.info(f"Saved output data to {args.output_data}")
    
    save_metrics(metrics, args.metrics)
    logger.info(f"Saved metrics to {args.metrics}")
    
    logger.info("Component execution completed successfully")


if __name__ == "__main__":
    main()
