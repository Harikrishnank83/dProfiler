#!/usr/bin/env python3
"""
GBM Trainer Component

Train Gradient Boosting models (Decision Trees, Random Forest, XGBoost, LightGBM).
Based on hw1_programming_base_notebook.ipynb from AI391L Machine Learning course.
"""

import argparse
import json
import logging
import pickle
from pathlib import Path
from typing import Optional

import numpy as np
from sklearn import tree, ensemble
from sklearn.model_selection import cross_val_score, KFold

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Constants from hw1 notebook
RANDOM_STATE = 10


def load_data(input_path: str) -> dict:
    """Load data from JSON file."""
    with open(input_path, "r") as f:
        return json.load(f)


def train_decision_tree(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    max_depth: int = 5,
    random_state: int = RANDOM_STATE
) -> tuple:
    """
    Train a decision tree classifier.
    From hw1 Question 2: Decision Tree performance.
    """
    logger.info(f"Training Decision Tree with max_depth={max_depth}")
    
    clf = tree.DecisionTreeClassifier(
        max_depth=max_depth,
        random_state=random_state
    )
    clf.fit(X_train, y_train)
    
    # Full dataset accuracy
    train_accuracy = clf.score(X_train, y_train)
    test_accuracy = clf.score(X_test, y_test)
    
    # Cross-validation accuracy
    cv = KFold(n_splits=10, shuffle=True, random_state=random_state)
    cv_scores = cross_val_score(clf, X_train, y_train, cv=cv)
    cv_accuracy = cv_scores.mean()
    cv_std = cv_scores.std()
    
    metrics = {
        "model_type": "decision_tree",
        "max_depth": max_depth,
        "train_accuracy": float(train_accuracy),
        "test_accuracy": float(test_accuracy),
        "cv_accuracy_mean": float(cv_accuracy),
        "cv_accuracy_std": float(cv_std)
    }
    
    return clf, metrics


def train_random_forest(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    n_estimators: int = 100,
    max_depth: Optional[int] = None,
    random_state: int = RANDOM_STATE
) -> tuple:
    """
    Train a Random Forest classifier.
    From hw1 Question 4: Random Forest.
    """
    logger.info(f"Training Random Forest with n_estimators={n_estimators}, max_depth={max_depth}")
    
    clf = ensemble.RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=random_state
    )
    clf.fit(X_train, y_train)
    
    train_accuracy = clf.score(X_train, y_train)
    test_accuracy = clf.score(X_test, y_test)
    
    # Cross-validation
    cv = KFold(n_splits=10, shuffle=True, random_state=random_state)
    cv_scores = cross_val_score(clf, X_train, y_train, cv=cv)
    cv_accuracy = cv_scores.mean()
    cv_std = cv_scores.std()
    
    metrics = {
        "model_type": "random_forest",
        "n_estimators": n_estimators,
        "max_depth": max_depth,
        "train_accuracy": float(train_accuracy),
        "test_accuracy": float(test_accuracy),
        "cv_accuracy_mean": float(cv_accuracy),
        "cv_accuracy_std": float(cv_std)
    }
    
    return clf, metrics


def train_gradient_boosting(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    n_estimators: int = 100,
    max_depth: int = 3,
    learning_rate: float = 0.1,
    random_state: int = RANDOM_STATE
) -> tuple:
    """
    Train a Gradient Boosting classifier.
    From hw1 Question 5: GBM.
    """
    logger.info(f"Training Gradient Boosting with n_estimators={n_estimators}, "
                f"max_depth={max_depth}, learning_rate={learning_rate}")
    
    clf = ensemble.GradientBoostingClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        learning_rate=learning_rate,
        random_state=random_state
    )
    clf.fit(X_train, y_train)
    
    train_accuracy = clf.score(X_train, y_train)
    test_accuracy = clf.score(X_test, y_test)
    
    # Cross-validation
    cv = KFold(n_splits=10, shuffle=True, random_state=random_state)
    cv_scores = cross_val_score(clf, X_train, y_train, cv=cv)
    cv_accuracy = cv_scores.mean()
    cv_std = cv_scores.std()
    
    metrics = {
        "model_type": "gradient_boosting",
        "n_estimators": n_estimators,
        "max_depth": max_depth,
        "learning_rate": learning_rate,
        "train_accuracy": float(train_accuracy),
        "test_accuracy": float(test_accuracy),
        "cv_accuracy_mean": float(cv_accuracy),
        "cv_accuracy_std": float(cv_std)
    }
    
    return clf, metrics


def train_depth_comparison(
    X_train: np.ndarray,
    y_train: np.ndarray,
    max_depths: list = None,
    random_state: int = RANDOM_STATE
) -> dict:
    """
    Train decision trees with varying max_depth and compare.
    From hw1 Question 2a: Visualization of performance vs max_depth.
    """
    if max_depths is None:
        max_depths = list(range(1, 11))
    
    full_dataset_accuracy = []
    cv_accuracy = []
    
    X_full = X_train
    y_full = y_train
    
    for depth in max_depths:
        clf = tree.DecisionTreeClassifier(max_depth=depth, random_state=random_state)
        
        # Full dataset accuracy
        clf.fit(X_full, y_full)
        full_acc = clf.score(X_full, y_full)
        full_dataset_accuracy.append(float(full_acc))
        
        # 10-fold CV
        cv = KFold(n_splits=10, shuffle=True, random_state=random_state)
        cv_scores = cross_val_score(clf, X_full, y_full, cv=cv)
        cv_accuracy.append(float(cv_scores.mean()))
    
    return {
        "max_depths": max_depths,
        "full_dataset_accuracy": full_dataset_accuracy,
        "cv_accuracy": cv_accuracy
    }


def save_model(model, output_path: str) -> None:
    """Save model as pickle file."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(model, f)


def save_json(data: dict, output_path: str) -> None:
    """Save data as JSON."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def save_metrics(metrics: dict, metrics_path: str) -> None:
    """Save metrics in KFP format."""
    path = Path(metrics_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    kfp_metrics = {
        "metrics": [
            {"name": k, "numberValue": v if isinstance(v, (int, float)) else 0}
            for k, v in metrics.items()
            if isinstance(v, (int, float))
        ]
    }
    with open(path, "w") as f:
        json.dump(kfp_metrics, f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="GBM Trainer Component")
    parser.add_argument("--input-data", type=str, required=True,
                        help="Path to input data (from data-loader)")
    parser.add_argument("--model-type", type=str, default="gradient_boosting",
                        choices=["decision_tree", "random_forest", "gradient_boosting"],
                        help="Type of model to train")
    parser.add_argument("--n-estimators", type=int, default=100,
                        help="Number of estimators (for ensemble methods)")
    parser.add_argument("--max-depth", type=int, default=5,
                        help="Maximum tree depth")
    parser.add_argument("--learning-rate", type=float, default=0.1,
                        help="Learning rate (for gradient boosting)")
    parser.add_argument("--random-state", type=int, default=RANDOM_STATE,
                        help="Random seed")
    parser.add_argument("--output-model", type=str, required=True,
                        help="Path for output model")
    parser.add_argument("--output-metrics-json", type=str, required=True,
                        help="Path for metrics JSON")
    parser.add_argument("--metrics", type=str, required=True,
                        help="Path for KFP metrics")
    
    args = parser.parse_args()
    
    logger.info(f"Loading data from {args.input_data}")
    data = load_data(args.input_data)
    
    X_train = np.array(data["X_train"])
    X_test = np.array(data["X_test"])
    y_train = np.array(data["y_train"])
    y_test = np.array(data["y_test"])
    
    logger.info(f"Training {args.model_type} model...")
    
    if args.model_type == "decision_tree":
        model, metrics = train_decision_tree(
            X_train, y_train, X_test, y_test,
            max_depth=args.max_depth,
            random_state=args.random_state
        )
    elif args.model_type == "random_forest":
        model, metrics = train_random_forest(
            X_train, y_train, X_test, y_test,
            n_estimators=args.n_estimators,
            max_depth=args.max_depth,
            random_state=args.random_state
        )
    elif args.model_type == "gradient_boosting":
        model, metrics = train_gradient_boosting(
            X_train, y_train, X_test, y_test,
            n_estimators=args.n_estimators,
            max_depth=args.max_depth,
            learning_rate=args.learning_rate,
            random_state=args.random_state
        )
    else:
        raise ValueError(f"Unknown model type: {args.model_type}")
    
    logger.info(f"Train accuracy: {metrics['train_accuracy']:.4f}")
    logger.info(f"Test accuracy: {metrics['test_accuracy']:.4f}")
    logger.info(f"CV accuracy: {metrics['cv_accuracy_mean']:.4f} (+/- {metrics['cv_accuracy_std']:.4f})")
    
    # Save outputs
    save_model(model, args.output_model)
    save_json(metrics, args.output_metrics_json)
    save_metrics(metrics, args.metrics)
    
    logger.info("Training complete!")


if __name__ == "__main__":
    main()
