# Unified GBM Component

A unified interface for Gradient Boosting Machine models in Kubeflow Pipelines.

## Features

- **Multiple Estimators**: XGBoost, LightGBM, CatBoost, Scikit-learn GBM
- **Compute Backends**: Local (joblib), Ray, Dask
- **Standardized I/O**: Parquet, CSV, Delta Lake support
- **Built-in ML Workflows**:
  - Training with early stopping
  - Cross-validation
  - Recursive Feature Elimination (RFE)
  - Hyperparameter tuning
  - Model evaluation

## Quick Start

```python
from unified_gbm import UnifiedGBMComponent

# Initialize component
gbm = UnifiedGBMComponent(
    estimator="xgboost",
    compute_backend="local",
    task="classification"
)

# Train with early stopping
model = gbm.fit(
    data="data/train.parquet",
    target_column="target",
    eval_split=0.2,
    early_stopping_rounds=50
)

# Cross-validate
cv_results = gbm.cross_validate(
    data="data/train.parquet",
    target_column="target",
    cv=5,
    scoring=["accuracy", "roc_auc"]
)

# Feature selection
rfe_results = gbm.rfe(
    data="data/train.parquet",
    target_column="target",
    n_features_to_select=10
)

# Hyperparameter tuning
tune_results = gbm.tune(
    data="data/train.parquet",
    target_column="target",
    param_space={
        "n_estimators": [100, 200, 500],
        "learning_rate": [0.01, 0.1, 0.3],
        "max_depth": [3, 6, 10]
    },
    n_trials=50
)

# Evaluate
metrics = gbm.evaluate(
    data="data/test.parquet",
    target_column="target"
)
```

## Switching Estimators

```python
# All estimators have the same interface
gbm_xgb = UnifiedGBMComponent(estimator="xgboost", task="classification")
gbm_lgb = UnifiedGBMComponent(estimator="lightgbm", task="classification")
gbm_cat = UnifiedGBMComponent(estimator="catboost", task="classification")

# Train with identical code
for gbm in [gbm_xgb, gbm_lgb, gbm_cat]:
    model = gbm.fit(data="train.parquet", target_column="target")
    print(gbm.evaluate(data="test.parquet", target_column="target"))
```

## Scaling with Ray

```python
from unified_gbm import UnifiedGBMComponent, ComputeConfig

# Configure Ray backend for distributed HPO
gbm = UnifiedGBMComponent(
    estimator="xgboost",
    compute_backend="ray",
    task="classification",
    compute_config=ComputeConfig(
        backend="ray",
        cluster_address="ray://ray-head:10001"
    )
)

# Distributed hyperparameter tuning
results = gbm.tune(
    data="s3://bucket/large_dataset.parquet",
    target_column="target",
    param_space={...},
    n_trials=1000
)
```

## Installation

```bash
# Basic installation
pip install unified-gbm

# With XGBoost
pip install unified-gbm[xgboost]

# With all estimators
pip install unified-gbm[all]

# For development
pip install unified-gbm[dev]
```

## Architecture

```
┌──────────────────────────────────────────────────────┐
│              UnifiedGBMComponent                     │
│  fit() | predict() | cv() | rfe() | tune() | eval() │
├──────────────────────────────────────────────────────┤
│           Estimator Abstraction Layer                │
│  XGBoost | LightGBM | CatBoost | Sklearn GBM        │
├──────────────────────────────────────────────────────┤
│           Compute Abstraction Layer                  │
│       Local (joblib) | Ray | Dask                    │
├──────────────────────────────────────────────────────┤
│           I/O Standardization Layer                  │
│     DataLoader | Schema Validation                   │
└──────────────────────────────────────────────────────┘
```

## Documentation

See [UNIFIED_GBM_ARCHITECTURE.md](../docs/UNIFIED_GBM_ARCHITECTURE.md) for detailed architecture documentation.

## License

Apache 2.0
