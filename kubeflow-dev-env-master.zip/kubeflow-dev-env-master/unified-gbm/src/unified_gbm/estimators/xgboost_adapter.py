"""XGBoost adapter for unified interface."""

from __future__ import annotations

import pickle
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from unified_gbm.estimators.base import EstimatorAdapter


class XGBoostAdapter(EstimatorAdapter):
    """
    Adapter for XGBoost estimator.
    
    Example:
        >>> adapter = XGBoostAdapter(task="classification", n_estimators=100)
        >>> adapter.fit(X_train, y_train, eval_set=[(X_val, y_val)])
        >>> predictions = adapter.predict(X_test)
    """
    
    def _translate_params(self) -> Dict[str, Any]:
        """Translate unified params to XGBoost params."""
        params = {
            "n_estimators": self.n_estimators,
            "learning_rate": self.learning_rate,
            "max_depth": self.max_depth,
            "min_child_weight": self.min_samples_leaf,
            "subsample": self.subsample,
            "colsample_bytree": self.colsample,
            "reg_lambda": self.l2_regularization,
            "random_state": self.random_state,
            "n_jobs": -1,
            "verbosity": 0,
        }
        
        # Set objective based on task
        if self.task == "classification":
            params["objective"] = "binary:logistic"
            params["eval_metric"] = "logloss"
        else:
            params["objective"] = "reg:squarederror"
            params["eval_metric"] = "rmse"
        
        # Add any extra params
        params.update(self.extra_params)
        
        return params
    
    def _create_model(self) -> Any:
        """Create XGBoost model."""
        try:
            import xgboost as xgb
        except ImportError:
            raise ImportError("xgboost is required. Install with: pip install xgboost")
        
        params = self._translate_params()
        
        if self.task == "classification":
            return xgb.XGBClassifier(**params)
        else:
            return xgb.XGBRegressor(**params)
    
    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        eval_set: Optional[List[Tuple]] = None,
        early_stopping_rounds: Optional[int] = None,
        verbose: bool = False,
        **kwargs
    ) -> "XGBoostAdapter":
        """Fit the XGBoost model."""
        self._store_feature_names(X)
        self._model = self._create_model()
        
        fit_params = {}
        if eval_set is not None:
            fit_params["eval_set"] = eval_set
        if early_stopping_rounds is not None:
            fit_params["early_stopping_rounds"] = early_stopping_rounds
        fit_params["verbose"] = verbose
        fit_params.update(kwargs)
        
        self._model.fit(X, y, **fit_params)
        self._is_fitted = True
        
        return self
    
    def predict(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """Make predictions."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before predict")
        return self._model.predict(X)
    
    def predict_proba(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """Predict class probabilities."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before predict_proba")
        if self.task != "classification":
            raise ValueError("predict_proba only available for classification")
        return self._model.predict_proba(X)
    
    def get_feature_importance(
        self,
        importance_type: str = "gain"
    ) -> Dict[str, float]:
        """Get feature importances."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before getting feature importance")
        
        # Map importance type
        xgb_importance_type = {
            "gain": "gain",
            "weight": "weight",
            "cover": "cover",
            "split": "weight",  # alias
        }.get(importance_type, "gain")
        
        booster = self._model.get_booster()
        importance = booster.get_score(importance_type=xgb_importance_type)
        
        # Map to feature names
        result = {}
        for i, name in enumerate(self._feature_names):
            key = f"f{i}"
            result[name] = importance.get(key, 0.0)
        
        return result
    
    def save(self, path: str) -> None:
        """Save model to path."""
        if not self._is_fitted:
            raise ValueError("Cannot save unfitted model")
        
        save_data = {
            "model": self._model,
            "params": self.get_params(),
            "feature_names": self._feature_names,
        }
        
        with open(path, "wb") as f:
            pickle.dump(save_data, f)
    
    @classmethod
    def load(cls, path: str) -> "XGBoostAdapter":
        """Load model from path."""
        with open(path, "rb") as f:
            save_data = pickle.load(f)
        
        adapter = cls(**save_data["params"])
        adapter._model = save_data["model"]
        adapter._feature_names = save_data["feature_names"]
        adapter._is_fitted = True
        
        return adapter
    
    def get_sklearn_estimator(self) -> Any:
        """Get the underlying sklearn-compatible XGBoost estimator."""
        if self._model is None:
            return self._create_model()
        return self._model
