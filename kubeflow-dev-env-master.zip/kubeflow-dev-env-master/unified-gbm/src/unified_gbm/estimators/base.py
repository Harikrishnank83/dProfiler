"""Base class for estimator adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd


class EstimatorType(Enum):
    """Supported estimator types."""
    XGBOOST = "xgboost"
    LIGHTGBM = "lightgbm"
    CATBOOST = "catboost"
    SKLEARN_GBM = "sklearn_gbm"
    HIST_GBM = "hist_gbm"


class EstimatorAdapter(ABC):
    """
    Abstract base class for GBM estimator adapters.
    
    Provides a unified interface for all GBM implementations:
    - XGBoost
    - LightGBM
    - CatBoost
    - Scikit-learn GradientBoosting
    - Scikit-learn HistGradientBoosting
    """
    
    # Unified parameter names that map to estimator-specific params
    UNIFIED_PARAMS = {
        "n_estimators",
        "learning_rate",
        "max_depth",
        "min_samples_leaf",
        "subsample",
        "colsample",
        "l2_regularization",
        "random_state",
    }
    
    def __init__(
        self,
        task: str = "classification",
        n_estimators: int = 100,
        learning_rate: float = 0.1,
        max_depth: int = 6,
        min_samples_leaf: int = 1,
        subsample: float = 1.0,
        colsample: float = 1.0,
        l2_regularization: float = 0.0,
        random_state: Optional[int] = None,
        **kwargs
    ):
        """
        Initialize estimator with unified parameters.
        
        Args:
            task: "classification" or "regression"
            n_estimators: Number of boosting rounds
            learning_rate: Learning rate / shrinkage
            max_depth: Maximum tree depth
            min_samples_leaf: Minimum samples in leaf node
            subsample: Row subsampling ratio
            colsample: Column subsampling ratio
            l2_regularization: L2 regularization term
            random_state: Random seed for reproducibility
            **kwargs: Additional estimator-specific parameters
        """
        self.task = task.lower()
        if self.task not in ("classification", "regression"):
            raise ValueError(f"task must be 'classification' or 'regression', got {task}")
        
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.subsample = subsample
        self.colsample = colsample
        self.l2_regularization = l2_regularization
        self.random_state = random_state
        self.extra_params = kwargs
        
        self._model = None
        self._feature_names: Optional[List[str]] = None
        self._is_fitted = False
    
    @property
    def is_fitted(self) -> bool:
        """Check if model has been fitted."""
        return self._is_fitted
    
    @abstractmethod
    def _create_model(self) -> Any:
        """Create the underlying estimator model."""
        pass
    
    @abstractmethod
    def _translate_params(self) -> Dict[str, Any]:
        """Translate unified params to estimator-specific params."""
        pass
    
    @abstractmethod
    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        eval_set: Optional[List[Tuple]] = None,
        early_stopping_rounds: Optional[int] = None,
        verbose: bool = False,
        **kwargs
    ) -> "EstimatorAdapter":
        """
        Fit the model.
        
        Args:
            X: Features (DataFrame or array)
            y: Target (Series or array)
            eval_set: List of (X, y) tuples for evaluation
            early_stopping_rounds: Stop if no improvement for N rounds
            verbose: Print training progress
            **kwargs: Additional fit parameters
        
        Returns:
            self
        """
        pass
    
    @abstractmethod
    def predict(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """
        Make predictions.
        
        Args:
            X: Features
        
        Returns:
            Predictions array
        """
        pass
    
    @abstractmethod
    def predict_proba(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """
        Predict class probabilities (classification only).
        
        Args:
            X: Features
        
        Returns:
            Probability array of shape (n_samples, n_classes)
        """
        pass
    
    @abstractmethod
    def get_feature_importance(
        self,
        importance_type: str = "gain"
    ) -> Dict[str, float]:
        """
        Get feature importances.
        
        Args:
            importance_type: Type of importance ("gain", "weight", "cover")
        
        Returns:
            Dictionary mapping feature names to importance scores
        """
        pass
    
    def get_params(self) -> Dict[str, Any]:
        """Get all parameters."""
        params = {
            "task": self.task,
            "n_estimators": self.n_estimators,
            "learning_rate": self.learning_rate,
            "max_depth": self.max_depth,
            "min_samples_leaf": self.min_samples_leaf,
            "subsample": self.subsample,
            "colsample": self.colsample,
            "l2_regularization": self.l2_regularization,
            "random_state": self.random_state,
        }
        params.update(self.extra_params)
        return params
    
    def set_params(self, **params) -> "EstimatorAdapter":
        """Set parameters."""
        for key, value in params.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                self.extra_params[key] = value
        return self
    
    @abstractmethod
    def save(self, path: str) -> None:
        """Save model to path."""
        pass
    
    @classmethod
    @abstractmethod
    def load(cls, path: str) -> "EstimatorAdapter":
        """Load model from path."""
        pass
    
    def clone(self) -> "EstimatorAdapter":
        """Create a clone with same parameters but unfitted."""
        return self.__class__(**self.get_params())
    
    def _store_feature_names(self, X: Union[pd.DataFrame, np.ndarray]) -> None:
        """Store feature names from input data."""
        if isinstance(X, pd.DataFrame):
            self._feature_names = list(X.columns)
        else:
            self._feature_names = [f"feature_{i}" for i in range(X.shape[1])]
