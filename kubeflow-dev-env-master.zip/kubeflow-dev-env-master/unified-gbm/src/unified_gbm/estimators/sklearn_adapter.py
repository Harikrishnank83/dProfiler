"""Scikit-learn GBM adapters for unified interface."""

from __future__ import annotations

import pickle
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor

from unified_gbm.estimators.base import EstimatorAdapter


class SklearnGBMAdapter(EstimatorAdapter):
    """
    Adapter for Scikit-learn GradientBoosting estimator.
    
    Example:
        >>> adapter = SklearnGBMAdapter(task="classification", n_estimators=100)
        >>> adapter.fit(X_train, y_train)
        >>> predictions = adapter.predict(X_test)
    """
    
    def _translate_params(self) -> Dict[str, Any]:
        """Translate unified params to sklearn GBM params."""
        params = {
            "n_estimators": self.n_estimators,
            "learning_rate": self.learning_rate,
            "max_depth": self.max_depth,
            "min_samples_leaf": self.min_samples_leaf,
            "subsample": self.subsample,
            "max_features": self.colsample if self.colsample < 1.0 else None,
            "random_state": self.random_state,
        }
        
        # Add any extra params
        params.update(self.extra_params)
        
        return params
    
    def _create_model(self) -> Any:
        """Create sklearn GBM model."""
        params = self._translate_params()
        
        if self.task == "classification":
            return GradientBoostingClassifier(**params)
        else:
            return GradientBoostingRegressor(**params)
    
    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        eval_set: Optional[List[Tuple]] = None,
        early_stopping_rounds: Optional[int] = None,
        verbose: bool = False,
        **kwargs
    ) -> "SklearnGBMAdapter":
        """Fit the sklearn GBM model."""
        self._store_feature_names(X)
        self._model = self._create_model()
        
        # sklearn GBM doesn't support eval_set directly
        # Early stopping is done via n_iter_no_change
        if early_stopping_rounds is not None:
            self._model.set_params(
                n_iter_no_change=early_stopping_rounds,
                validation_fraction=0.1
            )
        
        self._model.fit(X, y)
        self._is_fitted = True
        
        return self
    
    def predict(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """Make predictions."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before predict")
        return self._model.predict(X)
    
    def predict_proba(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """Predict class probabilities."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before predict_proba")
        if self.task != "classification":
            raise ValueError("predict_proba only available for classification")
        return self._model.predict_proba(X)
    
    def get_feature_importance(
        self,
        importance_type: str = "gain"
    ) -> Dict[str, float]:
        """Get feature importances."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before getting feature importance")
        
        # sklearn GBM only has one importance type (impurity-based)
        importance = self._model.feature_importances_
        
        return {
            name: float(imp)
            for name, imp in zip(self._feature_names, importance)
        }
    
    def save(self, path: str) -> None:
        """Save model to path."""
        if not self._is_fitted:
            raise ValueError("Cannot save unfitted model")
        
        save_data = {
            "model": self._model,
            "params": self.get_params(),
            "feature_names": self._feature_names,
        }
        
        with open(path, "wb") as f:
            pickle.dump(save_data, f)
    
    @classmethod
    def load(cls, path: str) -> "SklearnGBMAdapter":
        """Load model from path."""
        with open(path, "rb") as f:
            save_data = pickle.load(f)
        
        adapter = cls(**save_data["params"])
        adapter._model = save_data["model"]
        adapter._feature_names = save_data["feature_names"]
        adapter._is_fitted = True
        
        return adapter
    
    def get_sklearn_estimator(self) -> Any:
        """Get the underlying sklearn estimator."""
        if self._model is None:
            return self._create_model()
        return self._model


class HistGradientBoostingAdapter(EstimatorAdapter):
    """
    Adapter for Scikit-learn HistGradientBoosting estimator.
    
    This is faster than GradientBoosting for larger datasets.
    
    Example:
        >>> adapter = HistGradientBoostingAdapter(task="classification")
        >>> adapter.fit(X_train, y_train)
        >>> predictions = adapter.predict(X_test)
    """
    
    def _translate_params(self) -> Dict[str, Any]:
        """Translate unified params to HistGradientBoosting params."""
        params = {
            "max_iter": self.n_estimators,
            "learning_rate": self.learning_rate,
            "max_depth": self.max_depth,
            "min_samples_leaf": self.min_samples_leaf,
            "l2_regularization": self.l2_regularization,
            "random_state": self.random_state,
        }
        
        # Add any extra params
        params.update(self.extra_params)
        
        return params
    
    def _create_model(self) -> Any:
        """Create HistGradientBoosting model."""
        from sklearn.ensemble import (
            HistGradientBoostingClassifier,
            HistGradientBoostingRegressor,
        )
        
        params = self._translate_params()
        
        if self.task == "classification":
            return HistGradientBoostingClassifier(**params)
        else:
            return HistGradientBoostingRegressor(**params)
    
    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        eval_set: Optional[List[Tuple]] = None,
        early_stopping_rounds: Optional[int] = None,
        verbose: bool = False,
        **kwargs
    ) -> "HistGradientBoostingAdapter":
        """Fit the HistGradientBoosting model."""
        self._store_feature_names(X)
        self._model = self._create_model()
        
        # HistGradientBoosting supports early stopping
        if early_stopping_rounds is not None:
            self._model.set_params(
                early_stopping=True,
                n_iter_no_change=early_stopping_rounds,
                validation_fraction=0.1
            )
        
        self._model.fit(X, y)
        self._is_fitted = True
        
        return self
    
    def predict(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """Make predictions."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before predict")
        return self._model.predict(X)
    
    def predict_proba(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """Predict class probabilities."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before predict_proba")
        if self.task != "classification":
            raise ValueError("predict_proba only available for classification")
        return self._model.predict_proba(X)
    
    def get_feature_importance(
        self,
        importance_type: str = "gain"
    ) -> Dict[str, float]:
        """Get feature importances."""
        if not self._is_fitted:
            raise ValueError("Model must be fitted before getting feature importance")
        
        # Note: HistGradientBoosting doesn't have feature_importances_ by default
        # We use permutation importance or return zeros
        try:
            importance = self._model.feature_importances_
        except AttributeError:
            # Return uniform importance if not available
            n_features = len(self._feature_names)
            importance = np.ones(n_features) / n_features
        
        return {
            name: float(imp)
            for name, imp in zip(self._feature_names, importance)
        }
    
    def save(self, path: str) -> None:
        """Save model to path."""
        if not self._is_fitted:
            raise ValueError("Cannot save unfitted model")
        
        save_data = {
            "model": self._model,
            "params": self.get_params(),
            "feature_names": self._feature_names,
        }
        
        with open(path, "wb") as f:
            pickle.dump(save_data, f)
    
    @classmethod
    def load(cls, path: str) -> "HistGradientBoostingAdapter":
        """Load model from path."""
        with open(path, "rb") as f:
            save_data = pickle.load(f)
        
        adapter = cls(**save_data["params"])
        adapter._model = save_data["model"]
        adapter._feature_names = save_data["feature_names"]
        adapter._is_fitted = True
        
        return adapter
    
    def get_sklearn_estimator(self) -> Any:
        """Get the underlying sklearn estimator."""
        if self._model is None:
            return self._create_model()
        return self._model
