"""Estimator Abstraction Layer for Unified GBM."""

from unified_gbm.estimators.base import EstimatorAdapter, EstimatorType

__all__ = [
    "EstimatorAdapter",
    "EstimatorType",
    "get_estimator",
]


def get_estimator(
    estimator_type: str,
    task: str = "classification",
    **kwargs
) -> EstimatorAdapter:
    """
    Factory function to get the appropriate estimator adapter.
    
    Args:
        estimator_type: Type of estimator ("xgboost", "lightgbm", "catboost", "sklearn_gbm")
        task: Task type ("classification" or "regression")
        **kwargs: Estimator parameters
    
    Returns:
        EstimatorAdapter instance
    """
    estimator_type = estimator_type.lower()
    
    if estimator_type == "xgboost":
        from unified_gbm.estimators.xgboost_adapter import XGBoostAdapter
        return XGBoostAdapter(task=task, **kwargs)
    elif estimator_type == "lightgbm":
        from unified_gbm.estimators.lightgbm_adapter import LightGBMAdapter
        return LightGBMAdapter(task=task, **kwargs)
    elif estimator_type == "catboost":
        from unified_gbm.estimators.catboost_adapter import CatBoostAdapter
        return CatBoostAdapter(task=task, **kwargs)
    elif estimator_type in ("sklearn_gbm", "sklearn", "gbm"):
        from unified_gbm.estimators.sklearn_adapter import SklearnGBMAdapter
        return SklearnGBMAdapter(task=task, **kwargs)
    elif estimator_type in ("hist_gbm", "hgbm", "histgradientboosting"):
        from unified_gbm.estimators.sklearn_adapter import HistGradientBoostingAdapter
        return HistGradientBoostingAdapter(task=task, **kwargs)
    else:
        raise ValueError(
            f"Unknown estimator type: {estimator_type}. "
            f"Supported: xgboost, lightgbm, catboost, sklearn_gbm, hist_gbm"
        )
