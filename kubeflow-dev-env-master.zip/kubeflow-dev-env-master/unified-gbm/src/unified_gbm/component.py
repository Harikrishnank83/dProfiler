"""
UnifiedGBMComponent: High-level interface for GBM operations.

This is the main entry point for data scientists to train, tune, and
evaluate GBM models using a consistent interface.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from unified_gbm.compute import ComputeConfig, get_backend
from unified_gbm.estimators import EstimatorAdapter, get_estimator
from unified_gbm.io import DataLoader


class UnifiedGBMComponent:
    """
    Unified GBM Component for Kubeflow Pipelines.
    
    Provides a high-level interface for:
    - Training with train/eval split and early stopping
    - Cross-validation with multiple strategies
    - Recursive Feature Elimination (RFE)
    - Hyperparameter tuning with Ray/Optuna
    - Model evaluation with comprehensive metrics
    
    Example:
        >>> from unified_gbm import UnifiedGBMComponent
        >>> 
        >>> gbm = UnifiedGBMComponent(
        ...     estimator="xgboost",
        ...     compute_backend="local",
        ...     task="classification"
        ... )
        >>> 
        >>> # Train with early stopping
        >>> model = gbm.fit(
        ...     data="data/train.parquet",
        ...     target_column="churn",
        ...     eval_split=0.2,
        ...     early_stopping_rounds=50
        ... )
        >>> 
        >>> # Cross-validate
        >>> cv_results = gbm.cross_validate(
        ...     data="data/train.parquet",
        ...     target_column="churn",
        ...     cv=5
        ... )
    """
    
    def __init__(
        self,
        estimator: str = "xgboost",
        compute_backend: str = "local",
        task: str = "classification",
        compute_config: Optional[ComputeConfig] = None,
        **estimator_params
    ):
        """
        Initialize UnifiedGBMComponent.
        
        Args:
            estimator: Type of GBM estimator 
                ("xgboost", "lightgbm", "catboost", "sklearn_gbm", "hist_gbm")
            compute_backend: Compute backend ("local", "ray", "dask")
            task: Task type ("classification" or "regression")
            compute_config: Optional ComputeConfig for fine-grained control
            **estimator_params: Parameters passed to the estimator
        """
        self.estimator_type = estimator
        self.compute_backend_name = compute_backend
        self.task = task
        self.estimator_params = estimator_params
        
        # Initialize compute config
        if compute_config is None:
            compute_config = ComputeConfig(backend=compute_backend)
        self.compute_config = compute_config
        
        # Data loader with matching backend
        self.data_loader = DataLoader(compute_backend=compute_backend)
        
        # Fitted model (set after fit)
        self._fitted_estimator: Optional[EstimatorAdapter] = None
    
    def _create_estimator(self, **override_params) -> EstimatorAdapter:
        """Create a new estimator instance."""
        params = {**self.estimator_params, **override_params}
        return get_estimator(
            self.estimator_type,
            task=self.task,
            **params
        )
    
    def _load_data(
        self,
        data: Union[str, pd.DataFrame],
        target_column: Optional[str] = None,
        feature_columns: Optional[List[str]] = None
    ) -> Tuple[pd.DataFrame, Optional[pd.Series]]:
        """Load data and optionally split into X and y."""
        # Load if path
        if isinstance(data, str):
            df = self.data_loader.read(data)
        else:
            df = data.copy()
        
        # Select features
        if feature_columns is not None:
            if target_column and target_column not in feature_columns:
                cols = feature_columns + [target_column]
            else:
                cols = feature_columns
            df = df[cols]
        
        # Split X and y
        if target_column is not None:
            y = df[target_column]
            X = df.drop(columns=[target_column])
            return X, y
        
        return df, None
    
    def fit(
        self,
        data: Union[str, pd.DataFrame],
        target_column: str,
        feature_columns: Optional[List[str]] = None,
        eval_split: float = 0.0,
        eval_metric: Optional[str] = None,
        early_stopping_rounds: Optional[int] = None,
        stratify: bool = True,
        random_state: int = 42,
        **fit_params
    ) -> EstimatorAdapter:
        """
        Fit the GBM model.
        
        Args:
            data: Path to data file or DataFrame
            target_column: Name of target column
            feature_columns: List of feature columns (optional, uses all if None)
            eval_split: Fraction of data for evaluation (0-1)
            eval_metric: Metric for evaluation
            early_stopping_rounds: Stop if no improvement for N rounds
            stratify: Stratify split for classification
            random_state: Random seed
            **fit_params: Additional parameters passed to estimator.fit()
        
        Returns:
            Fitted EstimatorAdapter
        """
        X, y = self._load_data(data, target_column, feature_columns)
        
        # Create estimator
        estimator = self._create_estimator(random_state=random_state)
        
        # Train/eval split if requested
        eval_set = None
        if eval_split > 0:
            stratify_y = y if (stratify and self.task == "classification") else None
            X_train, X_val, y_train, y_val = train_test_split(
                X, y,
                test_size=eval_split,
                random_state=random_state,
                stratify=stratify_y
            )
            eval_set = [(X_val, y_val)]
        else:
            X_train, y_train = X, y
        
        # Fit
        estimator.fit(
            X_train, y_train,
            eval_set=eval_set,
            early_stopping_rounds=early_stopping_rounds,
            **fit_params
        )
        
        self._fitted_estimator = estimator
        return estimator
    
    def predict(
        self,
        model: Optional[EstimatorAdapter] = None,
        data: Union[str, pd.DataFrame] = None,
        output_path: Optional[str] = None,
        include_probabilities: bool = False,
        **kwargs
    ) -> pd.DataFrame:
        """
        Make predictions on new data.
        
        Args:
            model: Fitted estimator (uses self._fitted_estimator if None)
            data: Path to data file or DataFrame
            output_path: Optional path to save predictions
            include_probabilities: Include probability columns (classification only)
        
        Returns:
            DataFrame with predictions
        """
        if model is None:
            model = self._fitted_estimator
        if model is None:
            raise ValueError("No model provided and no fitted model available")
        
        X, _ = self._load_data(data)
        
        predictions = model.predict(X)
        result = pd.DataFrame({"prediction": predictions})
        
        if include_probabilities and self.task == "classification":
            probas = model.predict_proba(X)
            for i in range(probas.shape[1]):
                result[f"probability_class_{i}"] = probas[:, i]
        
        if output_path:
            self.data_loader.write(result, output_path)
        
        return result
    
    def cross_validate(
        self,
        data: Union[str, pd.DataFrame],
        target_column: str,
        feature_columns: Optional[List[str]] = None,
        cv: int = 5,
        cv_strategy: str = "stratified",
        scoring: Optional[Union[str, List[str]]] = None,
        return_train_score: bool = True,
        random_state: int = 42,
        **cv_params
    ) -> Dict[str, Any]:
        """
        Perform cross-validation.
        
        Args:
            data: Path to data file or DataFrame
            target_column: Name of target column
            feature_columns: List of feature columns
            cv: Number of folds
            cv_strategy: CV strategy ("stratified", "kfold", "timeseries", "group")
            scoring: Scoring metric(s)
            return_train_score: Include training scores
            random_state: Random seed
        
        Returns:
            Dictionary with CV results
        """
        from sklearn.model_selection import (
            StratifiedKFold, KFold, TimeSeriesSplit, cross_validate as sklearn_cv
        )
        
        X, y = self._load_data(data, target_column, feature_columns)
        
        # Create CV splitter
        if cv_strategy == "stratified" and self.task == "classification":
            cv_splitter = StratifiedKFold(n_splits=cv, shuffle=True, random_state=random_state)
        elif cv_strategy == "timeseries":
            cv_splitter = TimeSeriesSplit(n_splits=cv)
        else:
            cv_splitter = KFold(n_splits=cv, shuffle=True, random_state=random_state)
        
        # Get sklearn estimator
        estimator = self._create_estimator(random_state=random_state)
        sklearn_est = estimator.get_sklearn_estimator()
        
        # Default scoring
        if scoring is None:
            scoring = "roc_auc" if self.task == "classification" else "neg_mean_squared_error"
        
        # Run CV with compute backend
        backend = get_backend(self.compute_config)
        with backend:
            results = backend.cross_validate(
                sklearn_est, X, y,
                cv=cv_splitter,
                scoring=scoring,
                return_train_score=return_train_score,
                **cv_params
            )
        
        # Compute summary statistics
        summary = {}
        for key, values in results.items():
            if isinstance(values, np.ndarray):
                summary[f"mean_{key}"] = float(values.mean())
                summary[f"std_{key}"] = float(values.std())
                summary[key] = values.tolist()
        
        return summary
    
    def rfe(
        self,
        data: Union[str, pd.DataFrame],
        target_column: str,
        feature_columns: Optional[List[str]] = None,
        n_features_to_select: int = 10,
        step: int = 1,
        cv: int = 3,
        scoring: Optional[str] = None,
        random_state: int = 42
    ) -> Dict[str, Any]:
        """
        Recursive Feature Elimination.
        
        Args:
            data: Path to data file or DataFrame
            target_column: Name of target column
            feature_columns: List of feature columns
            n_features_to_select: Number of features to select
            step: Number of features to remove per iteration
            cv: Number of CV folds
            scoring: Scoring metric
            random_state: Random seed
        
        Returns:
            Dictionary with selected features and rankings
        """
        from sklearn.feature_selection import RFECV
        
        X, y = self._load_data(data, target_column, feature_columns)
        
        # Create estimator
        estimator = self._create_estimator(random_state=random_state)
        sklearn_est = estimator.get_sklearn_estimator()
        
        # Default scoring
        if scoring is None:
            scoring = "roc_auc" if self.task == "classification" else "neg_mean_squared_error"
        
        # Run RFE with CV
        rfe = RFECV(
            estimator=sklearn_est,
            step=step,
            cv=cv,
            scoring=scoring,
            min_features_to_select=n_features_to_select,
            n_jobs=-1
        )
        rfe.fit(X, y)
        
        # Get results
        feature_names = list(X.columns)
        selected_mask = rfe.support_
        rankings = rfe.ranking_
        
        return {
            "selected_features": [f for f, s in zip(feature_names, selected_mask) if s],
            "feature_ranking": {f: int(r) for f, r in zip(feature_names, rankings)},
            "n_features_selected": int(rfe.n_features_),
            "cv_scores": rfe.cv_results_["mean_test_score"].tolist(),
        }
    
    def tune(
        self,
        data: Union[str, pd.DataFrame],
        target_column: str,
        param_space: Dict[str, Any],
        feature_columns: Optional[List[str]] = None,
        n_trials: int = 100,
        cv: int = 5,
        scoring: Optional[str] = None,
        search_algorithm: str = "random",
        random_state: int = 42,
        **tune_params
    ) -> Dict[str, Any]:
        """
        Hyperparameter tuning.
        
        Args:
            data: Path to data file or DataFrame
            target_column: Name of target column
            param_space: Parameter search space
            feature_columns: List of feature columns
            n_trials: Number of trials
            cv: Number of CV folds
            scoring: Scoring metric
            search_algorithm: "random", "grid", or "optuna" (if Ray backend)
            random_state: Random seed
        
        Returns:
            Dictionary with best params, best score, and all trials
        """
        X, y = self._load_data(data, target_column, feature_columns)
        
        # Factory function for creating estimators
        def estimator_factory(params):
            merged_params = {**self.estimator_params, **params}
            est = get_estimator(self.estimator_type, task=self.task, **merged_params)
            return est.get_sklearn_estimator()
        
        # Default scoring
        if scoring is None:
            scoring = "roc_auc" if self.task == "classification" else "neg_mean_squared_error"
        
        # Run tuning with compute backend
        backend = get_backend(self.compute_config)
        with backend:
            best_params, best_score, trials_df = backend.hyperparameter_tune(
                estimator_factory=estimator_factory,
                X=X,
                y=y,
                param_space=param_space,
                n_trials=n_trials,
                cv=cv,
                scoring=scoring,
                search_algorithm=search_algorithm,
                random_state=random_state,
                **tune_params
            )
        
        return {
            "best_params": best_params,
            "best_score": float(best_score),
            "all_trials": trials_df.to_dict("records"),
        }
    
    def evaluate(
        self,
        model: Optional[EstimatorAdapter] = None,
        data: Union[str, pd.DataFrame] = None,
        target_column: str = None,
        metrics: Optional[List[str]] = None,
        threshold: float = 0.5
    ) -> Dict[str, Any]:
        """
        Evaluate model performance.
        
        Args:
            model: Fitted estimator (uses self._fitted_estimator if None)
            data: Path to test data or DataFrame
            target_column: Name of target column
            metrics: List of metrics to compute
            threshold: Classification threshold
        
        Returns:
            Dictionary with evaluation metrics
        """
        from sklearn.metrics import (
            accuracy_score, precision_score, recall_score, f1_score,
            roc_auc_score, confusion_matrix, mean_squared_error, r2_score
        )
        
        if model is None:
            model = self._fitted_estimator
        if model is None:
            raise ValueError("No model provided and no fitted model available")
        
        X, y_true = self._load_data(data, target_column)
        
        y_pred = model.predict(X)
        
        results = {}
        
        if self.task == "classification":
            # Get probabilities for ROC AUC
            try:
                y_proba = model.predict_proba(X)[:, 1]
            except:
                y_proba = None
            
            # Default metrics
            if metrics is None:
                metrics = ["accuracy", "precision", "recall", "f1", "roc_auc"]
            
            if "accuracy" in metrics:
                results["accuracy"] = float(accuracy_score(y_true, y_pred))
            if "precision" in metrics:
                results["precision"] = float(precision_score(y_true, y_pred, zero_division=0))
            if "recall" in metrics:
                results["recall"] = float(recall_score(y_true, y_pred, zero_division=0))
            if "f1" in metrics:
                results["f1"] = float(f1_score(y_true, y_pred, zero_division=0))
            if "roc_auc" in metrics and y_proba is not None:
                results["roc_auc"] = float(roc_auc_score(y_true, y_proba))
            if "confusion_matrix" in metrics:
                cm = confusion_matrix(y_true, y_pred)
                results["confusion_matrix"] = cm.tolist()
        
        else:  # regression
            if metrics is None:
                metrics = ["mse", "rmse", "r2"]
            
            mse = mean_squared_error(y_true, y_pred)
            if "mse" in metrics:
                results["mse"] = float(mse)
            if "rmse" in metrics:
                results["rmse"] = float(np.sqrt(mse))
            if "r2" in metrics:
                results["r2"] = float(r2_score(y_true, y_pred))
        
        return results
    
    def get_feature_importance(
        self,
        model: Optional[EstimatorAdapter] = None,
        importance_type: str = "gain",
        top_n: Optional[int] = None
    ) -> Dict[str, float]:
        """
        Get feature importances from fitted model.
        
        Args:
            model: Fitted estimator (uses self._fitted_estimator if None)
            importance_type: Type of importance ("gain", "weight", "cover")
            top_n: Return only top N features
        
        Returns:
            Dictionary mapping feature names to importance scores
        """
        if model is None:
            model = self._fitted_estimator
        if model is None:
            raise ValueError("No model provided and no fitted model available")
        
        importance = model.get_feature_importance(importance_type)
        
        # Sort by importance
        sorted_importance = dict(
            sorted(importance.items(), key=lambda x: x[1], reverse=True)
        )
        
        if top_n is not None:
            sorted_importance = dict(list(sorted_importance.items())[:top_n])
        
        return sorted_importance
    
    def save_model(self, path: str, model: Optional[EstimatorAdapter] = None) -> str:
        """Save model to path."""
        if model is None:
            model = self._fitted_estimator
        if model is None:
            raise ValueError("No model to save")
        
        model.save(path)
        return path
    
    def load_model(self, path: str) -> EstimatorAdapter:
        """Load model from path."""
        # Determine estimator class
        estimator = self._create_estimator()
        self._fitted_estimator = estimator.__class__.load(path)
        return self._fitted_estimator
