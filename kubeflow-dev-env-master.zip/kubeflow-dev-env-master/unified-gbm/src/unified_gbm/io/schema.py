"""
Schema validation for data in the Unified GBM framework.

Provides a declarative way to define and validate feature schemas.
"""

from __future__ import annotations

from dataclasses import dataclass, field as dataclass_field
from typing import Any, Dict, List, Optional, Set, Type, Union

import pandas as pd


@dataclass
class FieldSpec:
    """Specification for a single field in a schema."""
    
    name: str
    dtype: Optional[str] = None
    nullable: bool = True
    primary_key: bool = False
    target: bool = False
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    enum: Optional[List[Any]] = None
    pattern: Optional[str] = None
    description: str = ""
    
    def validate(self, series: pd.Series) -> List[str]:
        """Validate a pandas Series against this field spec."""
        errors = []
        
        # Check nullability
        if not self.nullable and series.isna().any():
            null_count = series.isna().sum()
            errors.append(f"Field '{self.name}' has {null_count} null values but is not nullable")
        
        # Check min/max for numeric fields
        if self.min_value is not None:
            below_min = (series < self.min_value).sum()
            if below_min > 0:
                errors.append(
                    f"Field '{self.name}' has {below_min} values below minimum {self.min_value}"
                )
        
        if self.max_value is not None:
            above_max = (series > self.max_value).sum()
            if above_max > 0:
                errors.append(
                    f"Field '{self.name}' has {above_max} values above maximum {self.max_value}"
                )
        
        # Check enum values
        if self.enum is not None:
            invalid = ~series.isin(self.enum) & ~series.isna()
            if invalid.any():
                invalid_vals = series[invalid].unique()[:5]  # Show first 5
                errors.append(
                    f"Field '{self.name}' has invalid values: {list(invalid_vals)}. "
                    f"Allowed: {self.enum}"
                )
        
        return errors


def field(
    dtype: Optional[str] = None,
    nullable: bool = True,
    primary_key: bool = False,
    target: bool = False,
    min_value: Optional[float] = None,
    max_value: Optional[float] = None,
    enum: Optional[List[Any]] = None,
    pattern: Optional[str] = None,
    description: str = ""
) -> Any:
    """
    Define a field in a FeatureSchema.
    
    Args:
        dtype: Expected data type (e.g., "int64", "float64", "str")
        nullable: Whether null values are allowed
        primary_key: Whether this is a primary key column
        target: Whether this is the target column
        min_value: Minimum allowed value (for numeric types)
        max_value: Maximum allowed value (for numeric types)
        enum: List of allowed values
        pattern: Regex pattern for string validation
        description: Human-readable description
    
    Returns:
        Field specification for use in FeatureSchema
    
    Example:
        class MySchema(FeatureSchema):
            age: int = field(min_value=0, max_value=120)
            status: str = field(enum=["active", "inactive"])
    """
    return FieldSpec(
        name="",  # Will be set by FeatureSchema metaclass
        dtype=dtype,
        nullable=nullable,
        primary_key=primary_key,
        target=target,
        min_value=min_value,
        max_value=max_value,
        enum=enum,
        pattern=pattern,
        description=description
    )


class FeatureSchemaMeta(type):
    """Metaclass for FeatureSchema that collects field definitions."""
    
    def __new__(mcs, name: str, bases: tuple, namespace: dict) -> Type:
        fields: Dict[str, FieldSpec] = {}
        
        # Collect fields from base classes
        for base in bases:
            if hasattr(base, "_fields"):
                fields.update(base._fields)
        
        # Collect fields from this class
        annotations = namespace.get("__annotations__", {})
        for field_name, field_type in annotations.items():
            if field_name.startswith("_"):
                continue
            
            field_spec = namespace.get(field_name)
            if isinstance(field_spec, FieldSpec):
                field_spec.name = field_name
                fields[field_name] = field_spec
            else:
                # Create default field spec
                fields[field_name] = FieldSpec(name=field_name)
        
        namespace["_fields"] = fields
        return super().__new__(mcs, name, bases, namespace)


class FeatureSchema(metaclass=FeatureSchemaMeta):
    """
    Base class for defining feature schemas with validation.
    
    Example:
        class CustomerSchema(FeatureSchema):
            customer_id: str = field(primary_key=True)
            age: int = field(min_value=0, max_value=120)
            income: float = field(min_value=0)
            status: str = field(enum=["active", "churned"])
            is_churned: int = field(target=True, enum=[0, 1])
        
        # Validate data
        validated_df = CustomerSchema.validate(df)
    """
    
    _fields: Dict[str, FieldSpec] = {}
    
    @classmethod
    def validate(
        cls,
        df: pd.DataFrame,
        raise_on_error: bool = True
    ) -> pd.DataFrame:
        """
        Validate a DataFrame against this schema.
        
        Args:
            df: DataFrame to validate
            raise_on_error: Whether to raise an exception on validation errors
        
        Returns:
            Validated DataFrame (with appropriate dtypes if specified)
        
        Raises:
            ValueError: If validation fails and raise_on_error is True
        """
        all_errors: List[str] = []
        
        # Check for required columns
        missing_cols = set(cls._fields.keys()) - set(df.columns)
        if missing_cols:
            all_errors.append(f"Missing required columns: {missing_cols}")
        
        # Validate each field
        for field_name, field_spec in cls._fields.items():
            if field_name not in df.columns:
                continue
            
            errors = field_spec.validate(df[field_name])
            all_errors.extend(errors)
        
        if all_errors and raise_on_error:
            error_msg = "\n".join(f"  - {e}" for e in all_errors)
            raise ValueError(f"Schema validation failed:\n{error_msg}")
        
        return df
    
    @classmethod
    def get_feature_columns(cls) -> List[str]:
        """Get list of feature column names (excluding target and primary key)."""
        return [
            name for name, spec in cls._fields.items()
            if not spec.target and not spec.primary_key
        ]
    
    @classmethod
    def get_target_column(cls) -> Optional[str]:
        """Get the target column name."""
        for name, spec in cls._fields.items():
            if spec.target:
                return name
        return None
    
    @classmethod
    def get_primary_key(cls) -> Optional[str]:
        """Get the primary key column name."""
        for name, spec in cls._fields.items():
            if spec.primary_key:
                return name
        return None
    
    @classmethod
    def to_dict(cls) -> Dict[str, Dict[str, Any]]:
        """Convert schema to dictionary representation."""
        return {
            name: {
                "dtype": spec.dtype,
                "nullable": spec.nullable,
                "primary_key": spec.primary_key,
                "target": spec.target,
                "min_value": spec.min_value,
                "max_value": spec.max_value,
                "enum": spec.enum,
                "description": spec.description
            }
            for name, spec in cls._fields.items()
        }


# Example schemas for common use cases

class BinaryClassificationSchema(FeatureSchema):
    """Base schema for binary classification problems."""
    target: int = field(target=True, enum=[0, 1])


class RegressionSchema(FeatureSchema):
    """Base schema for regression problems."""
    target: float = field(target=True)
