"""
DataLoader: Unified data loading interface for multiple formats and backends.

Provides a consistent API for reading and writing data across:
- Formats: Parquet, CSV, Delta, JSON
- Backends: Local (pandas), Ray, Dask
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, Union

import pandas as pd

from unified_gbm.io.schema import FeatureSchema


class DataLoader:
    """
    Unified data loader that abstracts format and compute backend differences.
    
    Example:
        >>> loader = DataLoader(compute_backend="local")
        >>> df = loader.read("data/train.parquet")
        >>> loader.write(df, "data/output.parquet")
    """
    
    SUPPORTED_FORMATS = {"parquet", "csv", "json", "delta"}
    SUPPORTED_BACKENDS = {"local", "ray", "dask"}
    
    def __init__(
        self,
        compute_backend: str = "local",
        **backend_kwargs: Any
    ):
        """
        Initialize DataLoader.
        
        Args:
            compute_backend: Compute backend to use ("local", "ray", "dask")
            **backend_kwargs: Additional arguments passed to the backend
        """
        if compute_backend not in self.SUPPORTED_BACKENDS:
            raise ValueError(
                f"Unsupported compute backend: {compute_backend}. "
                f"Supported: {self.SUPPORTED_BACKENDS}"
            )
        
        self.compute_backend = compute_backend
        self.backend_kwargs = backend_kwargs
        self._backend = self._init_backend()
    
    def _init_backend(self) -> Any:
        """Initialize the compute backend."""
        if self.compute_backend == "local":
            return None  # Use pandas directly
        elif self.compute_backend == "ray":
            try:
                import ray
                if not ray.is_initialized():
                    ray.init(**self.backend_kwargs)
                return ray
            except ImportError:
                raise ImportError("ray is required. Install with: pip install ray[data]")
        elif self.compute_backend == "dask":
            try:
                from dask.distributed import Client
                address = self.backend_kwargs.get("address")
                if address:
                    return Client(address)
                return Client()
            except ImportError:
                raise ImportError("dask is required. Install with: pip install dask[distributed]")
        return None
    
    def _detect_format(self, path: str) -> str:
        """Auto-detect file format from path extension."""
        path_lower = path.lower()
        if path_lower.endswith(".parquet") or path_lower.endswith(".pq"):
            return "parquet"
        elif path_lower.endswith(".csv"):
            return "csv"
        elif path_lower.endswith(".json") or path_lower.endswith(".jsonl"):
            return "json"
        elif "delta" in path_lower or path_lower.endswith("/_delta_log"):
            return "delta"
        else:
            # Default to parquet for directories (common for partitioned data)
            if os.path.isdir(path):
                return "parquet"
            raise ValueError(f"Cannot detect format for path: {path}")
    
    def read(
        self,
        path: str,
        format: Optional[str] = None,
        columns: Optional[List[str]] = None,
        filters: Optional[List[tuple]] = None,
        schema: Optional[Type[FeatureSchema]] = None,
        **kwargs: Any
    ) -> pd.DataFrame:
        """
        Read data from the specified path.
        
        Args:
            path: Path to data file or directory (local or cloud storage)
            format: Data format ("parquet", "csv", "json", "delta"). Auto-detected if None.
            columns: List of columns to read (optional, reads all if None)
            filters: List of filter tuples for predicate pushdown 
                     e.g., [("date", ">=", "2024-01-01")]
            schema: Optional FeatureSchema class for validation
            **kwargs: Additional format-specific arguments
        
        Returns:
            DataFrame (pandas, ray.data.Dataset, or dask.dataframe based on backend)
        """
        # Auto-detect format if not specified
        if format is None:
            format = self._detect_format(path)
        
        if format not in self.SUPPORTED_FORMATS:
            raise ValueError(
                f"Unsupported format: {format}. Supported: {self.SUPPORTED_FORMATS}"
            )
        
        # Read based on backend and format
        df = self._read_impl(path, format, columns, filters, **kwargs)
        
        # Validate against schema if provided
        if schema is not None:
            df = self._validate_schema(df, schema)
        
        return df
    
    def _read_impl(
        self,
        path: str,
        format: str,
        columns: Optional[List[str]],
        filters: Optional[List[tuple]],
        **kwargs: Any
    ) -> pd.DataFrame:
        """Implementation of read for different backends and formats."""
        
        if self.compute_backend == "local":
            return self._read_local(path, format, columns, filters, **kwargs)
        elif self.compute_backend == "ray":
            return self._read_ray(path, format, columns, filters, **kwargs)
        elif self.compute_backend == "dask":
            return self._read_dask(path, format, columns, filters, **kwargs)
        
        raise ValueError(f"Unknown backend: {self.compute_backend}")
    
    def _read_local(
        self,
        path: str,
        format: str,
        columns: Optional[List[str]],
        filters: Optional[List[tuple]],
        **kwargs: Any
    ) -> pd.DataFrame:
        """Read data using pandas."""
        if format == "parquet":
            import pyarrow.parquet as pq
            
            # Build pyarrow filters if provided
            pa_filters = None
            if filters:
                pa_filters = self._build_pyarrow_filters(filters)
            
            df = pd.read_parquet(
                path,
                columns=columns,
                filters=pa_filters,
                **kwargs
            )
        elif format == "csv":
            df = pd.read_csv(path, usecols=columns, **kwargs)
            if filters:
                df = self._apply_pandas_filters(df, filters)
        elif format == "json":
            df = pd.read_json(path, lines=True, **kwargs)
            if columns:
                df = df[columns]
            if filters:
                df = self._apply_pandas_filters(df, filters)
        elif format == "delta":
            try:
                from deltalake import DeltaTable
                dt = DeltaTable(path)
                df = dt.to_pandas(columns=columns)
                if filters:
                    df = self._apply_pandas_filters(df, filters)
            except ImportError:
                raise ImportError("deltalake is required. Install with: pip install deltalake")
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        return df
    
    def _read_ray(
        self,
        path: str,
        format: str,
        columns: Optional[List[str]],
        filters: Optional[List[tuple]],
        **kwargs: Any
    ) -> pd.DataFrame:
        """Read data using Ray Data."""
        import ray.data
        
        if format == "parquet":
            ds = ray.data.read_parquet(path, columns=columns, **kwargs)
        elif format == "csv":
            ds = ray.data.read_csv(path, **kwargs)
            if columns:
                ds = ds.select_columns(columns)
        elif format == "json":
            ds = ray.data.read_json(path, **kwargs)
            if columns:
                ds = ds.select_columns(columns)
        else:
            raise ValueError(f"Ray backend does not support format: {format}")
        
        # Apply filters
        if filters:
            for col, op, val in filters:
                if op == "==":
                    ds = ds.filter(lambda row: row[col] == val)
                elif op == ">=":
                    ds = ds.filter(lambda row: row[col] >= val)
                elif op == "<=":
                    ds = ds.filter(lambda row: row[col] <= val)
                elif op == ">":
                    ds = ds.filter(lambda row: row[col] > val)
                elif op == "<":
                    ds = ds.filter(lambda row: row[col] < val)
        
        # Convert to pandas for consistent API
        return ds.to_pandas()
    
    def _read_dask(
        self,
        path: str,
        format: str,
        columns: Optional[List[str]],
        filters: Optional[List[tuple]],
        **kwargs: Any
    ) -> pd.DataFrame:
        """Read data using Dask."""
        import dask.dataframe as dd
        
        if format == "parquet":
            ddf = dd.read_parquet(path, columns=columns, filters=filters, **kwargs)
        elif format == "csv":
            ddf = dd.read_csv(path, **kwargs)
            if columns:
                ddf = ddf[columns]
        elif format == "json":
            ddf = dd.read_json(path, lines=True, **kwargs)
            if columns:
                ddf = ddf[columns]
        else:
            raise ValueError(f"Dask backend does not support format: {format}")
        
        if filters and format != "parquet":
            ddf = self._apply_dask_filters(ddf, filters)
        
        # Compute to pandas for consistent API
        return ddf.compute()
    
    def _build_pyarrow_filters(self, filters: List[tuple]) -> List:
        """Convert filter tuples to PyArrow filter format."""
        import pyarrow.compute as pc
        
        pa_filters = []
        for col, op, val in filters:
            pa_filters.append((col, op, val))
        return pa_filters
    
    def _apply_pandas_filters(self, df: pd.DataFrame, filters: List[tuple]) -> pd.DataFrame:
        """Apply filters to pandas DataFrame."""
        for col, op, val in filters:
            if op == "==":
                df = df[df[col] == val]
            elif op == "!=":
                df = df[df[col] != val]
            elif op == ">=":
                df = df[df[col] >= val]
            elif op == "<=":
                df = df[df[col] <= val]
            elif op == ">":
                df = df[df[col] > val]
            elif op == "<":
                df = df[df[col] < val]
            elif op == "in":
                df = df[df[col].isin(val)]
        return df
    
    def _apply_dask_filters(self, ddf, filters: List[tuple]):
        """Apply filters to Dask DataFrame."""
        for col, op, val in filters:
            if op == "==":
                ddf = ddf[ddf[col] == val]
            elif op == "!=":
                ddf = ddf[ddf[col] != val]
            elif op == ">=":
                ddf = ddf[ddf[col] >= val]
            elif op == "<=":
                ddf = ddf[ddf[col] <= val]
            elif op == ">":
                ddf = ddf[ddf[col] > val]
            elif op == "<":
                ddf = ddf[ddf[col] < val]
        return ddf
    
    def _validate_schema(
        self, 
        df: pd.DataFrame, 
        schema: Type[FeatureSchema]
    ) -> pd.DataFrame:
        """Validate DataFrame against schema."""
        return schema.validate(df)
    
    def write(
        self,
        data: pd.DataFrame,
        path: str,
        format: Optional[str] = None,
        partition_by: Optional[List[str]] = None,
        **kwargs: Any
    ) -> str:
        """
        Write data to the specified path.
        
        Args:
            data: DataFrame to write
            path: Output path (local or cloud storage)
            format: Output format (auto-detected if None)
            partition_by: Columns to partition by (for parquet)
            **kwargs: Additional format-specific arguments
        
        Returns:
            Path where data was written
        """
        if format is None:
            format = self._detect_format(path)
        
        if format == "parquet":
            data.to_parquet(
                path,
                partition_cols=partition_by,
                index=False,
                **kwargs
            )
        elif format == "csv":
            data.to_csv(path, index=False, **kwargs)
        elif format == "json":
            data.to_json(path, orient="records", lines=True, **kwargs)
        else:
            raise ValueError(f"Writing to format {format} not supported")
        
        return path
    
    def to_artifact(
        self,
        data: pd.DataFrame,
        artifact_path: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Save data as a Kubeflow artifact with metadata.
        
        Args:
            data: DataFrame to save
            artifact_path: Path for the artifact
            metadata: Optional metadata dictionary
        
        Returns:
            Artifact path
        """
        # Write data
        self.write(data, artifact_path, format="parquet")
        
        # Write metadata
        if metadata:
            import json
            meta_path = artifact_path.replace(".parquet", "_metadata.json")
            with open(meta_path, "w") as f:
                json.dump(metadata, f, indent=2, default=str)
        
        return artifact_path
