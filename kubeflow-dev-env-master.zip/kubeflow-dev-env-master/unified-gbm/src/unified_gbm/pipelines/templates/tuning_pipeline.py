"""Hyperparameter tuning pipeline template."""

try:
    from kfp import dsl
    from kfp.dsl import pipeline
    
    KFP_AVAILABLE = True
except ImportError:
    KFP_AVAILABLE = False


def create_tuning_pipeline(
    name: str = "gbm-tuning-pipeline",
    description: str = "Hyperparameter tuning pipeline for GBM models"
):
    """
    Create a hyperparameter tuning pipeline.
    
    Args:
        name: Pipeline name
        description: Pipeline description
    
    Returns:
        KFP pipeline function
    """
    if not KFP_AVAILABLE:
        raise ImportError("kfp is required. Install with: pip install kfp>=2.0.0")
    
    @pipeline(name=name, description=description)
    def gbm_tuning_pipeline(
        data_path: str,
        target_column: str,
        estimator: str = "xgboost",
        task: str = "classification",
        n_trials: int = 50,
        cv: int = 5,
        final_eval_split: float = 0.2,
        early_stopping_rounds: int = 50,
    ):
        """
        Tune hyperparameters and train final model.
        
        Args:
            data_path: Path to training data
            target_column: Target column name
            estimator: GBM estimator type
            task: classification or regression
            n_trials: Number of HPO trials
            cv: CV folds for tuning
            final_eval_split: Eval split for final model
            early_stopping_rounds: Early stopping patience
        """
        from unified_gbm.pipelines.components.tune import tune_hyperparameters_component
        from unified_gbm.pipelines.components.train import train_gbm_component
        
        # Run hyperparameter tuning
        tune_task = tune_hyperparameters_component(
            data_path=data_path,
            target_column=target_column,
            estimator=estimator,
            task=task,
            n_trials=n_trials,
            cv=cv,
        )
        
        # Train final model with best params
        # Note: In practice, you'd parse best_params_json and use those values
        train_task = train_gbm_component(
            data_path=data_path,
            target_column=target_column,
            estimator=estimator,
            task=task,
            eval_split=final_eval_split,
            early_stopping_rounds=early_stopping_rounds,
        )
        train_task.after(tune_task)
    
    return gbm_tuning_pipeline


# Create default pipeline
if KFP_AVAILABLE:
    gbm_tuning_pipeline = create_tuning_pipeline()
else:
    gbm_tuning_pipeline = None
