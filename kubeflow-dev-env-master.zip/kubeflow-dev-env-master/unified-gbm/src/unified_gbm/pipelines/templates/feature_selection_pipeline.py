"""Feature selection pipeline template."""

try:
    from kfp import dsl
    from kfp.dsl import pipeline, component
    
    KFP_AVAILABLE = True
except ImportError:
    KFP_AVAILABLE = False


# Define RFE component inline if KFP is available
if KFP_AVAILABLE:
    from typing import NamedTuple
    
    @component(
        base_image="python:3.10-slim",
        packages_to_install=["unified-gbm[xgboost]", "pyarrow"],
    )
    def rfe_component(
        data_path: str,
        target_column: str,
        n_features_to_select: int = 10,
        step: int = 1,
        cv: int = 3,
        estimator: str = "xgboost",
        task: str = "classification",
    ) -> NamedTuple("RFEOutput", [
        ("selected_features_json", str),
        ("n_features_selected", int),
    ]):
        """Run Recursive Feature Elimination."""
        import json
        from collections import namedtuple
        
        from unified_gbm import UnifiedGBMComponent
        
        gbm = UnifiedGBMComponent(
            estimator=estimator,
            compute_backend="local",
            task=task,
        )
        
        results = gbm.rfe(
            data=data_path,
            target_column=target_column,
            n_features_to_select=n_features_to_select,
            step=step,
            cv=cv,
        )
        
        RFEOutput = namedtuple("RFEOutput", ["selected_features_json", "n_features_selected"])
        return RFEOutput(
            selected_features_json=json.dumps(results["selected_features"]),
            n_features_selected=results["n_features_selected"],
        )


def create_feature_selection_pipeline(
    name: str = "gbm-feature-selection-pipeline",
    description: str = "Feature selection and model comparison pipeline"
):
    """
    Create a feature selection pipeline.
    
    Args:
        name: Pipeline name
        description: Pipeline description
    
    Returns:
        KFP pipeline function
    """
    if not KFP_AVAILABLE:
        raise ImportError("kfp is required. Install with: pip install kfp>=2.0.0")
    
    @pipeline(name=name, description=description)
    def feature_selection_pipeline(
        data_path: str,
        target_column: str,
        n_features_to_select: int = 10,
        estimator: str = "xgboost",
        task: str = "classification",
        eval_split: float = 0.2,
    ):
        """
        Select features and compare model performance.
        
        Args:
            data_path: Path to training data
            target_column: Target column name
            n_features_to_select: Number of features to select
            estimator: GBM estimator type
            task: classification or regression
            eval_split: Validation split fraction
        """
        from unified_gbm.pipelines.components.train import train_gbm_component
        
        # Run RFE
        rfe_task = rfe_component(
            data_path=data_path,
            target_column=target_column,
            n_features_to_select=n_features_to_select,
            estimator=estimator,
            task=task,
        )
        
        # Train model with all features (baseline)
        full_model_task = train_gbm_component(
            data_path=data_path,
            target_column=target_column,
            estimator=estimator,
            task=task,
            eval_split=eval_split,
        )
        
        # Train model with selected features
        # Note: In practice, would filter data using selected_features_json
        selected_model_task = train_gbm_component(
            data_path=data_path,
            target_column=target_column,
            estimator=estimator,
            task=task,
            eval_split=eval_split,
        )
        selected_model_task.after(rfe_task)
    
    return feature_selection_pipeline


# Create default pipeline
if KFP_AVAILABLE:
    feature_selection_pipeline = create_feature_selection_pipeline()
else:
    feature_selection_pipeline = None
