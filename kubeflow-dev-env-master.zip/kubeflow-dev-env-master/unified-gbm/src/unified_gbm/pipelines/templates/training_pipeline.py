"""Standard GBM training pipeline template."""

from typing import Optional

try:
    from kfp import dsl
    from kfp.dsl import pipeline, component, Input, Output, Artifact, Model
    
    KFP_AVAILABLE = True
except ImportError:
    KFP_AVAILABLE = False


def create_training_pipeline(
    name: str = "gbm-training-pipeline",
    description: str = "End-to-end GBM model training pipeline"
):
    """
    Create a GBM training pipeline.
    
    This factory function creates a customizable training pipeline.
    
    Args:
        name: Pipeline name
        description: Pipeline description
    
    Returns:
        KFP pipeline function
    """
    if not KFP_AVAILABLE:
        raise ImportError("kfp is required. Install with: pip install kfp>=2.0.0")
    
    @pipeline(name=name, description=description)
    def gbm_training_pipeline(
        data_path: str,
        target_column: str,
        estimator: str = "xgboost",
        task: str = "classification",
        eval_split: float = 0.2,
        early_stopping_rounds: int = 50,
        n_estimators: int = 100,
        learning_rate: float = 0.1,
        max_depth: int = 6,
        model_output_path: str = "/tmp/model.pkl",
        test_data_path: Optional[str] = None,
    ):
        """
        Train and evaluate a GBM model.
        
        Args:
            data_path: Path to training data
            target_column: Target column name
            estimator: GBM estimator type
            task: classification or regression
            eval_split: Validation split fraction
            early_stopping_rounds: Early stopping patience
            n_estimators: Number of boosting rounds
            learning_rate: Learning rate
            max_depth: Max tree depth
            model_output_path: Where to save model
            test_data_path: Optional test data for evaluation
        """
        from unified_gbm.pipelines.components.train import train_gbm_component
        from unified_gbm.pipelines.components.evaluate import evaluate_model_component
        
        # Train the model
        train_task = train_gbm_component(
            data_path=data_path,
            target_column=target_column,
            estimator=estimator,
            task=task,
            eval_split=eval_split,
            early_stopping_rounds=early_stopping_rounds,
            n_estimators=n_estimators,
            learning_rate=learning_rate,
            max_depth=max_depth,
        )
        
        # Evaluate if test data provided
        if test_data_path:
            evaluate_task = evaluate_model_component(
                model=train_task.outputs["model_output"],
                data_path=test_data_path,
                target_column=target_column,
                estimator=estimator,
                task=task,
            )
            evaluate_task.after(train_task)
    
    return gbm_training_pipeline


# Create default pipeline
if KFP_AVAILABLE:
    gbm_training_pipeline = create_training_pipeline()
else:
    gbm_training_pipeline = None
