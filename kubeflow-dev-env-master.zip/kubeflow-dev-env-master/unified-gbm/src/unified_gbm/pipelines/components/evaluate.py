"""Kubeflow component for model evaluation."""

from typing import List, NamedTuple, Optional


def evaluate_model(
    model_path: str,
    data_path: str,
    target_column: str,
    estimator: str = "xgboost",
    task: str = "classification",
    metrics: Optional[List[str]] = None,
    threshold: float = 0.5,
) -> NamedTuple("EvalOutput", [
    ("accuracy", float),
    ("precision", float),
    ("recall", float),
    ("f1", float),
    ("roc_auc", float),
    ("metrics_json", str),
]):
    """
    Evaluate a trained GBM model.
    
    Args:
        model_path: Path to saved model
        data_path: Path to test data
        target_column: Name of target column
        estimator: Type of GBM estimator
        task: "classification" or "regression"
        metrics: List of metrics to compute
        threshold: Classification threshold
    
    Returns:
        Named tuple with evaluation metrics
    """
    import json
    from collections import namedtuple
    
    from unified_gbm import UnifiedGBMComponent
    
    # Initialize component
    gbm = UnifiedGBMComponent(
        estimator=estimator,
        compute_backend="local",
        task=task,
    )
    
    # Load model
    gbm.load_model(model_path)
    
    # Default metrics
    if metrics is None:
        if task == "classification":
            metrics = ["accuracy", "precision", "recall", "f1", "roc_auc"]
        else:
            metrics = ["mse", "rmse", "r2"]
    
    # Evaluate
    results = gbm.evaluate(
        data=data_path,
        target_column=target_column,
        metrics=metrics,
        threshold=threshold,
    )
    
    metrics_json = json.dumps(results)
    
    EvalOutput = namedtuple("EvalOutput", [
        "accuracy", "precision", "recall", "f1", "roc_auc", "metrics_json"
    ])
    
    return EvalOutput(
        accuracy=results.get("accuracy", 0.0),
        precision=results.get("precision", 0.0),
        recall=results.get("recall", 0.0),
        f1=results.get("f1", 0.0),
        roc_auc=results.get("roc_auc", 0.0),
        metrics_json=metrics_json,
    )


# Create KFP component if kfp is available
try:
    from kfp import dsl
    from kfp.dsl import component, Input, Artifact, Model
    
    @component(
        base_image="python:3.10-slim",
        packages_to_install=["unified-gbm[xgboost]", "pyarrow"],
    )
    def evaluate_model_component(
        model: Input[Model],
        data_path: str,
        target_column: str,
        estimator: str = "xgboost",
        task: str = "classification",
        threshold: float = 0.5,
    ) -> NamedTuple("EvalMetrics", [
        ("accuracy", float),
        ("roc_auc", float),
        ("metrics_json", str),
    ]):
        """KFP-wrapped evaluate component."""
        result = evaluate_model(
            model_path=model.path,
            data_path=data_path,
            target_column=target_column,
            estimator=estimator,
            task=task,
            threshold=threshold,
        )
        
        from collections import namedtuple
        EvalMetrics = namedtuple("EvalMetrics", ["accuracy", "roc_auc", "metrics_json"])
        return EvalMetrics(result.accuracy, result.roc_auc, result.metrics_json)

except ImportError:
    evaluate_model_component = None
