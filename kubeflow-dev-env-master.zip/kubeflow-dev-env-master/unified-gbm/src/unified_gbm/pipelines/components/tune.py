"""Kubeflow component for hyperparameter tuning."""

from typing import Any, Dict, List, NamedTuple, Optional


def tune_hyperparameters(
    data_path: str,
    target_column: str,
    estimator: str = "xgboost",
    task: str = "classification",
    n_trials: int = 50,
    cv: int = 5,
    scoring: Optional[str] = None,
    n_estimators_range: Optional[List[int]] = None,
    learning_rate_range: Optional[List[float]] = None,
    max_depth_range: Optional[List[int]] = None,
    random_state: int = 42,
) -> NamedTuple("TuneOutput", [
    ("best_params_json", str),
    ("best_score", float),
    ("n_trials_completed", int),
]):
    """
    Tune hyperparameters for a GBM model.
    
    Args:
        data_path: Path to training data
        target_column: Name of target column
        estimator: Type of GBM estimator
        task: "classification" or "regression"
        n_trials: Number of HPO trials
        cv: Number of cross-validation folds
        scoring: Scoring metric
        n_estimators_range: Range for n_estimators
        learning_rate_range: Range for learning_rate
        max_depth_range: Range for max_depth
        random_state: Random seed
    
    Returns:
        Named tuple with best parameters and score
    """
    import json
    from collections import namedtuple
    
    from unified_gbm import UnifiedGBMComponent
    
    # Build parameter space
    param_space: Dict[str, Any] = {}
    
    if n_estimators_range:
        param_space["n_estimators"] = n_estimators_range
    else:
        param_space["n_estimators"] = [50, 100, 200, 500]
    
    if learning_rate_range:
        param_space["learning_rate"] = learning_rate_range
    else:
        param_space["learning_rate"] = [0.01, 0.05, 0.1, 0.2]
    
    if max_depth_range:
        param_space["max_depth"] = max_depth_range
    else:
        param_space["max_depth"] = [3, 5, 7, 10]
    
    param_space["subsample"] = [0.7, 0.8, 0.9, 1.0]
    param_space["colsample"] = [0.7, 0.8, 0.9, 1.0]
    
    # Initialize component
    gbm = UnifiedGBMComponent(
        estimator=estimator,
        compute_backend="local",
        task=task,
    )
    
    # Run tuning
    results = gbm.tune(
        data=data_path,
        target_column=target_column,
        param_space=param_space,
        n_trials=n_trials,
        cv=cv,
        scoring=scoring,
        random_state=random_state,
    )
    
    best_params_json = json.dumps(results["best_params"])
    
    TuneOutput = namedtuple("TuneOutput", [
        "best_params_json", "best_score", "n_trials_completed"
    ])
    
    return TuneOutput(
        best_params_json=best_params_json,
        best_score=results["best_score"],
        n_trials_completed=len(results.get("all_trials", [])),
    )


# Create KFP component if kfp is available
try:
    from kfp import dsl
    from kfp.dsl import component
    
    @component(
        base_image="python:3.10-slim",
        packages_to_install=["unified-gbm[xgboost]", "pyarrow"],
    )
    def tune_hyperparameters_component(
        data_path: str,
        target_column: str,
        estimator: str = "xgboost",
        task: str = "classification",
        n_trials: int = 50,
        cv: int = 5,
    ) -> NamedTuple("TuneMetrics", [
        ("best_params_json", str),
        ("best_score", float),
    ]):
        """KFP-wrapped tune component."""
        result = tune_hyperparameters(
            data_path=data_path,
            target_column=target_column,
            estimator=estimator,
            task=task,
            n_trials=n_trials,
            cv=cv,
        )
        
        from collections import namedtuple
        TuneMetrics = namedtuple("TuneMetrics", ["best_params_json", "best_score"])
        return TuneMetrics(result.best_params_json, result.best_score)

except ImportError:
    tune_hyperparameters_component = None
