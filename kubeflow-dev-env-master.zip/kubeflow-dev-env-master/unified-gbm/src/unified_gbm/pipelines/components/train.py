"""Kubeflow component for GBM training."""

from typing import List, NamedTuple, Optional


def train_gbm(
    data_path: str,
    target_column: str,
    model_output_path: str,
    estimator: str = "xgboost",
    task: str = "classification",
    feature_columns: Optional[List[str]] = None,
    eval_split: float = 0.2,
    early_stopping_rounds: int = 50,
    n_estimators: int = 100,
    learning_rate: float = 0.1,
    max_depth: int = 6,
    random_state: int = 42,
) -> NamedTuple("TrainOutput", [
    ("model_path", str),
    ("train_score", float),
    ("eval_score", float),
    ("feature_importance", str),
]):
    """
    Train a GBM model using the Unified GBM Component.
    
    Args:
        data_path: Path to training data (parquet or csv)
        target_column: Name of the target column
        model_output_path: Path to save the trained model
        estimator: Type of GBM ("xgboost", "lightgbm", "catboost", "sklearn_gbm")
        task: "classification" or "regression"
        feature_columns: Optional list of feature column names
        eval_split: Fraction of data for validation
        early_stopping_rounds: Stop if no improvement for N rounds
        n_estimators: Number of boosting rounds
        learning_rate: Learning rate
        max_depth: Maximum tree depth
        random_state: Random seed
    
    Returns:
        Named tuple with model path, scores, and feature importance
    """
    import json
    from collections import namedtuple
    
    from unified_gbm import UnifiedGBMComponent
    
    # Initialize component
    gbm = UnifiedGBMComponent(
        estimator=estimator,
        compute_backend="local",
        task=task,
        n_estimators=n_estimators,
        learning_rate=learning_rate,
        max_depth=max_depth,
        random_state=random_state,
    )
    
    # Train model
    model = gbm.fit(
        data=data_path,
        target_column=target_column,
        feature_columns=feature_columns,
        eval_split=eval_split,
        early_stopping_rounds=early_stopping_rounds,
    )
    
    # Save model
    gbm.save_model(model_output_path)
    
    # Get feature importance
    importance = gbm.get_feature_importance(top_n=20)
    importance_json = json.dumps(importance)
    
    # Evaluate on training data (for reporting)
    train_metrics = gbm.evaluate(
        data=data_path,
        target_column=target_column,
    )
    
    train_score = train_metrics.get("roc_auc", train_metrics.get("r2", 0.0))
    eval_score = train_score  # Would need separate eval set for true eval score
    
    TrainOutput = namedtuple("TrainOutput", [
        "model_path", "train_score", "eval_score", "feature_importance"
    ])
    
    return TrainOutput(
        model_path=model_output_path,
        train_score=train_score,
        eval_score=eval_score,
        feature_importance=importance_json,
    )


# Create KFP component if kfp is available
try:
    from kfp import dsl
    from kfp.dsl import component, Output, Artifact, Model
    
    @component(
        base_image="python:3.10-slim",
        packages_to_install=["unified-gbm[xgboost]", "pyarrow"],
    )
    def train_gbm_component(
        data_path: str,
        target_column: str,
        model_output: Output[Model],
        estimator: str = "xgboost",
        task: str = "classification",
        eval_split: float = 0.2,
        early_stopping_rounds: int = 50,
        n_estimators: int = 100,
        learning_rate: float = 0.1,
        max_depth: int = 6,
        random_state: int = 42,
    ) -> NamedTuple("TrainMetrics", [("train_score", float), ("feature_importance", str)]):
        """KFP-wrapped train component."""
        result = train_gbm(
            data_path=data_path,
            target_column=target_column,
            model_output_path=model_output.path,
            estimator=estimator,
            task=task,
            eval_split=eval_split,
            early_stopping_rounds=early_stopping_rounds,
            n_estimators=n_estimators,
            learning_rate=learning_rate,
            max_depth=max_depth,
            random_state=random_state,
        )
        
        from collections import namedtuple
        TrainMetrics = namedtuple("TrainMetrics", ["train_score", "feature_importance"])
        return TrainMetrics(result.train_score, result.feature_importance)

except ImportError:
    # kfp not available - skip component decorator
    train_gbm_component = None
