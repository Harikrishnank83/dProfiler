"""Configuration for compute backends."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class ComputeConfig:
    """
    Configuration for compute backends.
    
    Example:
        # Auto-select based on data size
        config = ComputeConfig.auto(data_size_gb=50)
        
        # Explicit configuration
        config = ComputeConfig(
            backend="ray",
            cluster_address="ray://ray-head:10001",
            num_cpus=32,
            num_gpus=4
        )
    """
    
    backend: str = "local"
    cluster_address: Optional[str] = None
    num_cpus: Optional[int] = None
    num_gpus: int = 0
    memory_per_worker: Optional[str] = None
    npartitions: int = 8
    extra_config: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        valid_backends = {"local", "ray", "dask"}
        if self.backend not in valid_backends:
            raise ValueError(
                f"Invalid backend: {self.backend}. Must be one of {valid_backends}"
            )
    
    @classmethod
    def auto(
        cls,
        data_size_gb: float = 0,
        prefer_distributed: bool = False
    ) -> ComputeConfig:
        """
        Auto-select compute backend based on data size.
        
        Args:
            data_size_gb: Estimated size of the dataset in GB
            prefer_distributed: Whether to prefer distributed backends
        
        Returns:
            ComputeConfig with appropriate settings
        """
        if data_size_gb < 1 and not prefer_distributed:
            # Small data: use local backend
            return cls(backend="local")
        elif data_size_gb < 10:
            # Medium data: use Ray with default settings
            return cls(
                backend="ray",
                num_cpus=None  # Auto-detect
            )
        else:
            # Large data: use Ray with more resources
            return cls(
                backend="ray",
                num_cpus=None,  # Auto-detect
                memory_per_worker="8GB"
            )
    
    @classmethod
    def for_hpo(cls, n_trials: int = 100) -> ComputeConfig:
        """
        Get configuration optimized for hyperparameter optimization.
        
        Args:
            n_trials: Number of HPO trials to run
        
        Returns:
            ComputeConfig for HPO
        """
        return cls(
            backend="ray",
            extra_config={
                "tune": {
                    "max_concurrent_trials": min(n_trials, 10),
                    "resources_per_trial": {"cpu": 2}
                }
            }
        )
    
    @classmethod
    def for_large_data(cls, data_size_gb: float) -> ComputeConfig:
        """
        Get configuration optimized for large data processing.
        
        Args:
            data_size_gb: Size of data in GB
        
        Returns:
            ComputeConfig for large data
        """
        # Use Dask for large data preprocessing, Ray for training
        npartitions = max(8, int(data_size_gb * 2))
        return cls(
            backend="dask",
            npartitions=npartitions,
            memory_per_worker="4GB"
        )
