"""Base class for compute backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, Tuple, Type

import numpy as np
import pandas as pd

from unified_gbm.compute.config import ComputeConfig


class ComputeBackend(ABC):
    """
    Abstract base class for compute backends.
    
    Provides a unified interface for local, Ray, and Dask backends.
    """
    
    def __init__(self, config: ComputeConfig):
        self.config = config
        self._initialized = False
    
    @abstractmethod
    def initialize(self) -> None:
        """Initialize the compute cluster/backend."""
        pass
    
    @abstractmethod
    def shutdown(self) -> None:
        """Shutdown the compute cluster/backend."""
        pass
    
    @property
    def is_initialized(self) -> bool:
        """Check if backend is initialized."""
        return self._initialized
    
    @abstractmethod
    def parallel_map(
        self,
        func: Callable,
        items: List[Any],
        **kwargs
    ) -> List[Any]:
        """
        Execute a function in parallel across items.
        
        Args:
            func: Function to execute
            items: List of items to process
            **kwargs: Additional arguments passed to func
        
        Returns:
            List of results
        """
        pass
    
    @abstractmethod
    def cross_validate(
        self,
        estimator: Any,
        X: pd.DataFrame,
        y: pd.Series,
        cv: int = 5,
        scoring: Optional[str] = None,
        **kwargs
    ) -> Dict[str, np.ndarray]:
        """
        Perform cross-validation.
        
        Args:
            estimator: Estimator to cross-validate
            X: Features
            y: Target
            cv: Number of folds
            scoring: Scoring metric
        
        Returns:
            Dictionary with cross-validation results
        """
        pass
    
    @abstractmethod
    def hyperparameter_tune(
        self,
        estimator_factory: Callable,
        X: pd.DataFrame,
        y: pd.Series,
        param_space: Dict[str, Any],
        n_trials: int = 100,
        cv: int = 5,
        scoring: Optional[str] = None,
        **kwargs
    ) -> Tuple[Dict[str, Any], float, pd.DataFrame]:
        """
        Perform hyperparameter tuning.
        
        Args:
            estimator_factory: Factory function that creates estimator with params
            X: Features
            y: Target
            param_space: Parameter search space
            n_trials: Number of trials
            cv: Number of CV folds
            scoring: Scoring metric
        
        Returns:
            Tuple of (best_params, best_score, all_trials_df)
        """
        pass
    
    def __enter__(self) -> "ComputeBackend":
        """Context manager entry."""
        if not self._initialized:
            self.initialize()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.shutdown()
