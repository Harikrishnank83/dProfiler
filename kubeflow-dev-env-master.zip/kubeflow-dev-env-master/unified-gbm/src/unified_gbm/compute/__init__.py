"""Compute Abstraction Layer for Unified GBM."""

from unified_gbm.compute.config import ComputeConfig
from unified_gbm.compute.base import ComputeBackend
from unified_gbm.compute.local import LocalBackend

__all__ = [
    "ComputeConfig",
    "ComputeBackend",
    "LocalBackend",
]


def get_backend(config: ComputeConfig) -> ComputeBackend:
    """Factory function to get the appropriate compute backend."""
    if config.backend == "local":
        return LocalBackend(config)
    elif config.backend == "ray":
        from unified_gbm.compute.ray_backend import RayBackend
        return RayBackend(config)
    elif config.backend == "dask":
        from unified_gbm.compute.dask_backend import DaskBackend
        return DaskBackend(config)
    else:
        raise ValueError(f"Unknown compute backend: {config.backend}")
