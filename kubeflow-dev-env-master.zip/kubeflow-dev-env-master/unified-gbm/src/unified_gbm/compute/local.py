"""Local compute backend using joblib for parallelism."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import cross_validate as sklearn_cv

from unified_gbm.compute.base import ComputeBackend
from unified_gbm.compute.config import ComputeConfig


class LocalBackend(ComputeBackend):
    """
    Local compute backend using joblib for parallelism.
    
    Suitable for small to medium datasets that fit in memory.
    """
    
    def __init__(self, config: ComputeConfig):
        super().__init__(config)
        self.n_jobs = config.num_cpus or -1  # -1 means use all CPUs
    
    def initialize(self) -> None:
        """Local backend doesn't need initialization."""
        self._initialized = True
    
    def shutdown(self) -> None:
        """Local backend doesn't need cleanup."""
        self._initialized = False
    
    def parallel_map(
        self,
        func: Callable,
        items: List[Any],
        **kwargs
    ) -> List[Any]:
        """Execute function in parallel using joblib."""
        from joblib import Parallel, delayed
        
        return Parallel(n_jobs=self.n_jobs)(
            delayed(func)(item, **kwargs) for item in items
        )
    
    def cross_validate(
        self,
        estimator: Any,
        X: pd.DataFrame,
        y: pd.Series,
        cv: int = 5,
        scoring: Optional[str] = None,
        **kwargs
    ) -> Dict[str, np.ndarray]:
        """Perform cross-validation using sklearn."""
        results = sklearn_cv(
            estimator,
            X,
            y,
            cv=cv,
            scoring=scoring,
            n_jobs=self.n_jobs,
            return_train_score=kwargs.get("return_train_score", True),
            **{k: v for k, v in kwargs.items() if k != "return_train_score"}
        )
        return results
    
    def hyperparameter_tune(
        self,
        estimator_factory: Callable,
        X: pd.DataFrame,
        y: pd.Series,
        param_space: Dict[str, Any],
        n_trials: int = 100,
        cv: int = 5,
        scoring: Optional[str] = None,
        search_algorithm: str = "random",
        **kwargs
    ) -> Tuple[Dict[str, Any], float, pd.DataFrame]:
        """
        Perform hyperparameter tuning using sklearn.
        
        Args:
            estimator_factory: Factory that takes params and returns estimator
            X: Features
            y: Target
            param_space: Parameter distributions/values
            n_trials: Number of trials (for random search)
            cv: Number of CV folds
            scoring: Scoring metric
            search_algorithm: "grid" or "random"
        
        Returns:
            Tuple of (best_params, best_score, all_trials_df)
        """
        from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
        
        # Create base estimator
        base_estimator = estimator_factory({})
        
        if search_algorithm == "grid":
            search = GridSearchCV(
                base_estimator,
                param_space,
                cv=cv,
                scoring=scoring,
                n_jobs=self.n_jobs,
                return_train_score=True
            )
        else:
            search = RandomizedSearchCV(
                base_estimator,
                param_space,
                n_iter=n_trials,
                cv=cv,
                scoring=scoring,
                n_jobs=self.n_jobs,
                return_train_score=True,
                random_state=kwargs.get("random_state", 42)
            )
        
        search.fit(X, y)
        
        # Convert results to DataFrame
        results_df = pd.DataFrame(search.cv_results_)
        
        return search.best_params_, search.best_score_, results_df
