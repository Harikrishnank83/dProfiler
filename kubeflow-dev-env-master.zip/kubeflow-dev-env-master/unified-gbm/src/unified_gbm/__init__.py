"""
Unified GBM Component for Kubeflow Pipelines.

A unified interface for Gradient Boosting Machine models with support for:
- Multiple estimators: XGBoost, LightGBM, CatBoost, Scikit-learn
- Multiple compute backends: Local, Ray, Dask
- Standardized I/O for various data formats
- Built-in cross-validation, feature selection, and hyperparameter tuning
"""

from unified_gbm.component import UnifiedGBMComponent
from unified_gbm.io import DataLoader
from unified_gbm.compute import ComputeConfig

__version__ = "0.1.0"
__all__ = [
    "UnifiedGBMComponent",
    "DataLoader",
    "ComputeConfig",
]
