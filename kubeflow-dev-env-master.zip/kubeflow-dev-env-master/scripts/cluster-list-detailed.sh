#!/usr/bin/env bash
# List existing K3d clusters with detailed information (K8s version, KFP version, status)
# Usage: ./cluster-list-detailed.sh [--format table|json]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

# Default format
FORMAT="table"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --format)
            FORMAT="$2"
            shift 2
            ;;
        --help|-h)
            echo "List K3d clusters with detailed information"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --format FORMAT    Output format: table or json (default: table)"
            echo "  --help             Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Check if k3d is installed
if ! command -v k3d &> /dev/null; then
    log_error "k3d is not installed"
    exit 1
fi

# Get list of clusters
CLUSTERS=$(k3d cluster list -o json 2>/dev/null || echo "[]")

if [[ "$CLUSTERS" == "[]" ]] || [[ -z "$CLUSTERS" ]]; then
    if [[ "$FORMAT" == "json" ]]; then
        echo "[]"
    else
        log_info "No K3d clusters found"
    fi
    exit 0
fi

# Function to get K8s version from cluster
get_k8s_version() {
    local cluster_name="$1"
    local context="k3d-$cluster_name"
    
    # Try to get version from current context
    if kubectl config use-context "$context" &>/dev/null 2>&1; then
        local version=$(kubectl version --short 2>/dev/null | grep "Server Version" | awk '{print $3}' | sed 's/v//')
        if [[ -n "$version" ]]; then
            echo "$version"
            return 0
        fi
    fi
    
    # Fallback: Try to get from docker inspect
    local k8s_version=$(docker inspect "k3d-${cluster_name}-server-0" 2>/dev/null | grep -o 'K3S_VERSION=[^"]*' | cut -d'=' -f2 | cut -d'+' -f1 | sed 's/v//' || echo "unknown")
    echo "$k8s_version"
}

# Function to get KFP version from cluster
get_kfp_version() {
    local cluster_name="$1"
    local context="k3d-$cluster_name"
    
    # Switch context
    if ! kubectl config use-context "$context" &>/dev/null 2>&1; then
        echo "unknown"
        return 0
    fi
    
    # Check if kubeflow namespace exists
    if ! kubectl get namespace kubeflow &>/dev/null 2>&1; then
        echo "not-installed"
        return 0
    fi
    
    # Try to get KFP version from deployment
    local kfp_version=$(kubectl get deployment -n kubeflow ml-pipeline -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null | grep -o 'v[0-9]\+\.[0-9]\+\.[0-9]\+' | sed 's/v//' || echo "unknown")
    
    if [[ -z "$kfp_version" ]] || [[ "$kfp_version" == "unknown" ]]; then
        # Fallback: Check if any KFP pods exist
        if kubectl get pods -n kubeflow -l app=ml-pipeline &>/dev/null 2>&1 | grep -q "ml-pipeline"; then
            kfp_version="installed"
        else
            kfp_version="not-installed"
        fi
    fi
    
    echo "$kfp_version"
}

# Function to get cluster status
get_cluster_status() {
    local cluster_name="$1"
    
    # Check if cluster is running
    if docker ps --filter "name=k3d-${cluster_name}-server" --format "{{.Status}}" 2>/dev/null | grep -q "Up"; then
        echo "running"
    else
        echo "stopped"
    fi
}

# Function to get cluster node count
get_node_count() {
    local cluster_name="$1"
    local context="k3d-$cluster_name"
    
    if kubectl config use-context "$context" &>/dev/null 2>&1; then
        local count=$(kubectl get nodes --no-headers 2>/dev/null | wc -l | tr -d ' ')
        echo "${count:-0}"
    else
        echo "0"
    fi
}

# Parse cluster information
declare -a CLUSTER_INFO=()

# Get simple cluster list
CLUSTER_NAMES=$(k3d cluster list -o json 2>/dev/null | grep -o '"name":"[^"]*"' | cut -d'"' -f4)

if [[ -z "$CLUSTER_NAMES" ]]; then
    if [[ "$FORMAT" == "json" ]]; then
        echo "[]"
    else
        log_info "No K3d clusters found"
    fi
    exit 0
fi

# Collect detailed information
while IFS= read -r cluster_name; do
    [[ -z "$cluster_name" ]] && continue
    
    log_debug "Getting details for cluster: $cluster_name"
    
    local status=$(get_cluster_status "$cluster_name")
    local k8s_version=$(get_k8s_version "$cluster_name")
    local kfp_version=$(get_kfp_version "$cluster_name")
    local node_count=$(get_node_count "$cluster_name")
    
    CLUSTER_INFO+=("$cluster_name|$status|$k8s_version|$kfp_version|$node_count")
done <<< "$CLUSTER_NAMES"

# Output results
if [[ "$FORMAT" == "json" ]]; then
    # JSON output
    echo "["
    local first=true
    for info in "${CLUSTER_INFO[@]}"; do
        IFS='|' read -r name status k8s kfp nodes <<< "$info"
        
        if [[ "$first" == "true" ]]; then
            first=false
        else
            echo ","
        fi
        
        echo "  {"
        echo "    \"name\": \"$name\","
        echo "    \"status\": \"$status\","
        echo "    \"k8s_version\": \"$k8s\","
        echo "    \"kfp_version\": \"$kfp\","
        echo "    \"node_count\": $nodes"
        echo -n "  }"
    done
    echo ""
    echo "]"
else
    # Table output
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    printf "%-20s %-12s %-15s %-15s %-8s\n" "CLUSTER NAME" "STATUS" "K8s VERSION" "KFP VERSION" "NODES"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    for info in "${CLUSTER_INFO[@]}"; do
        IFS='|' read -r name status k8s kfp nodes <<< "$info"
        
        # Color status
        local status_colored="$status"
        if [[ "$status" == "running" ]]; then
            status_colored="${GREEN}●${NC} running"
        else
            status_colored="${RED}●${NC} stopped"
        fi
        
        # Color KFP version
        local kfp_colored="$kfp"
        if [[ "$kfp" == "not-installed" ]]; then
            kfp_colored="${YELLOW}not-installed${NC}"
        elif [[ "$kfp" == "unknown" ]]; then
            kfp_colored="${DIM}unknown${NC}"
        else
            kfp_colored="${GREEN}$kfp${NC}"
        fi
        
        printf "%-20s %-22s %-15s %-25s %-8s\n" "$name" "$status_colored" "$k8s" "$kfp_colored" "$nodes"
    done
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
fi

# Return the count
exit 0
