#!/usr/bin/env bash
# Import cluster configuration from export file
# Usage: ./import-cluster.sh --file my-setup.yaml

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

INPUT_FILE=""
SKIP_VERIFY="false"

while [[ $# -gt 0 ]]; do
    case $1 in
        --file|-f)
            INPUT_FILE="$2"
            shift 2
            ;;
        --skip-verify)
            SKIP_VERIFY="true"
            shift
            ;;
        --help|-h)
            echo "Import cluster configuration"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --file, -f FILE    Import file path (required)"
            echo "  --skip-verify      Skip verification checks"
            echo "  --help             Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [[ -z "$INPUT_FILE" ]]; then
    log_error "Input file is required"
    echo "Use --file to specify the export file"
    exit 1
fi

if [[ ! -f "$INPUT_FILE" ]]; then
    log_error "File not found: $INPUT_FILE"
    exit 1
fi

log_info "Importing cluster configuration from: $INPUT_FILE"

# Parse export file
K8S_VERSION=$(yq '.cluster.k8s_version' "$INPUT_FILE")
KFP_VERSION=$(yq '.cluster.kfp_version' "$INPUT_FILE")
CLUSTER_MODE=$(yq '.cluster.mode' "$INPUT_FILE")
CLUSTER_NAME=$(yq '.cluster.name' "$INPUT_FILE")

DASK_ENABLED=$(yq '.operators.dask' "$INPUT_FILE")
RAY_ENABLED=$(yq '.operators.ray' "$INPUT_FILE")

print_header "Import Configuration"
print_kv "K8s Version" "$K8S_VERSION"
print_kv "KFP Version" "$KFP_VERSION"
print_kv "Cluster Mode" "$CLUSTER_MODE"
print_kv "Cluster Name" "$CLUSTER_NAME"
print_kv "Dask Operator" "$DASK_ENABLED"
print_kv "Ray Operator" "$RAY_ENABLED"
echo ""

# Verify versions are available
if [[ "$SKIP_VERIFY" != "true" ]]; then
    log_info "Verifying version compatibility..."
    "$SCRIPT_DIR/version-manager.sh" check "$K8S_VERSION" "$KFP_VERSION" || {
        log_error "Version compatibility check failed"
        exit 1
    }
fi

# Confirm
if ! confirm "Proceed with cluster creation?"; then
    log_info "Aborted"
    exit 0
fi

# Create cluster
log_info "Creating cluster..."
"$SCRIPT_DIR/cluster-create.sh" \
    --name "$CLUSTER_NAME" \
    --k8s "$K8S_VERSION" \
    --kfp "$KFP_VERSION" \
    --mode "$CLUSTER_MODE"

# Install operators if enabled
if [[ "$DASK_ENABLED" == "true" ]]; then
    log_info "Installing Dask operator..."
    "$SCRIPT_DIR/install-operators.sh" --dask
fi

if [[ "$RAY_ENABLED" == "true" ]]; then
    log_info "Installing Ray operator..."
    "$SCRIPT_DIR/install-operators.sh" --ray
fi

log_success "Cluster imported successfully!"
echo ""
echo "Next steps:"
echo "  1. Build components: make build-all"
echo "  2. Access UI: make port-forward"
