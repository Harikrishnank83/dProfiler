#!/usr/bin/env bash
# Export cluster configuration for reproduction on another machine
# Usage: ./export-cluster.sh --output my-setup.yaml

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

OUTPUT_FILE=""
INCLUDE_DATA="false"

while [[ $# -gt 0 ]]; do
    case $1 in
        --output|-o)
            OUTPUT_FILE="$2"
            shift 2
            ;;
        --include-data)
            INCLUDE_DATA="true"
            shift
            ;;
        --help|-h)
            echo "Export cluster configuration"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --output, -o FILE     Output file path (required)"
            echo "  --include-data        Include data volumes in export"
            echo "  --help                Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [[ -z "$OUTPUT_FILE" ]]; then
    OUTPUT_FILE="$PROJECT_ROOT/exports/cluster-export-$(date +%Y%m%d%H%M%S).yaml"
fi

mkdir -p "$(dirname "$OUTPUT_FILE")"

# Get current cluster info
CLUSTER_NAME=$(get_current_cluster)
K8S_VERSION=$(get_current_k8s_version)
KFP_VERSION=$(get_current_kfp_version)

STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"

log_info "Exporting cluster configuration..."

# Create export file
cat > "$OUTPUT_FILE" << EOF
# Kubeflow Development Environment - Cluster Export
# Generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
# Use: ./scripts/import-cluster.sh --file $OUTPUT_FILE

export:
  version: "1.0"
  created_at: "$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  machine: "$(hostname)"

cluster:
  name: "${CLUSTER_NAME:-unknown}"
  k8s_version: "${K8S_VERSION:-unknown}"
  kfp_version: "${KFP_VERSION:-unknown}"
  mode: "$(yq '.cluster.mode // "single"' "$STATE_FILE" 2>/dev/null || echo "single")"

registry:
  port: $(yq '.cluster.registry.port // 5000' "$STATE_FILE" 2>/dev/null || echo "5000")

operators:
  dask: $(yq '.cluster.operators.dask // false' "$STATE_FILE" 2>/dev/null || echo "false")
  ray: $(yq '.cluster.operators.ray // false' "$STATE_FILE" 2>/dev/null || echo "false")

components:
$(for comp in "$PROJECT_ROOT/components"/*/; do
    name=$(basename "$comp")
    if [[ "$name" != "component-template" && -f "$comp/Dockerfile" ]]; then
        echo "  - name: $name"
        echo "    version: $(yq '.version // "1.0.0"' "$comp/component.yaml" 2>/dev/null || echo "1.0.0")"
    fi
done)

installation:
  mode: "dev"
  modules:
    - cluster
    - kubeflow
EOF

# Add data info if requested
if [[ "$INCLUDE_DATA" == "true" ]]; then
    log_info "Including data volume information..."
    cat >> "$OUTPUT_FILE" << EOF

data:
  artifacts_size: "$(du -sh "$PROJECT_ROOT/data/artifacts" 2>/dev/null | cut -f1 || echo "0")"
  minio_size: "$(du -sh "$PROJECT_ROOT/data/minio" 2>/dev/null | cut -f1 || echo "0")"
  note: "Data volumes not included in export. Sync separately if needed."
EOF
fi

log_success "Cluster exported to: $OUTPUT_FILE"
echo ""
echo "To import on another machine:"
echo "  1. Copy $OUTPUT_FILE to the target machine"
echo "  2. Clone the repository"
echo "  3. Run: ./scripts/import-cluster.sh --file <path-to-export>"
