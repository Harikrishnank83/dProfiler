#!/usr/bin/env bash
# Create a new K3d cluster with specified K8s and Kubeflow versions
# Usage: ./cluster-create.sh --k8s 1.28.5 --kfp 2.1.0 [--mode single|multi] [--name cluster-name]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

# Default values
K8S_VERSION=""
KFP_VERSION=""
CLUSTER_MODE="single"
CLUSTER_NAME=""
REGISTRY_PORT="5000"
SKIP_KFP="false"
DRY_RUN="false"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --k8s)
            K8S_VERSION="$2"
            shift 2
            ;;
        --kfp)
            KFP_VERSION="$2"
            shift 2
            ;;
        --mode)
            CLUSTER_MODE="$2"
            shift 2
            ;;
        --name)
            CLUSTER_NAME="$2"
            shift 2
            ;;
        --registry-port)
            REGISTRY_PORT="$2"
            shift 2
            ;;
        --skip-kfp)
            SKIP_KFP="true"
            shift
            ;;
        --dry-run)
            DRY_RUN="true"
            shift
            ;;
        --help|-h)
            echo "Create a new K3d cluster with Kubeflow Pipelines"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --k8s VERSION        Kubernetes version (e.g., 1.28.5)"
            echo "  --kfp VERSION        Kubeflow Pipelines version (e.g., 2.1.0)"
            echo "  --mode MODE          Cluster mode: single or multi (default: single)"
            echo "  --name NAME          Cluster name (default: kfp-dev)"
            echo "  --registry-port PORT Local registry port (default: 5000)"
            echo "  --skip-kfp           Skip Kubeflow Pipelines installation"
            echo "  --dry-run            Print configuration without creating cluster"
            echo "  --help               Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Use defaults if not specified
if [[ -z "$K8S_VERSION" ]]; then
    K8S_VERSION=$("$SCRIPT_DIR/version-manager.sh" default-k8s)
    log_info "Using default K8s version: $K8S_VERSION"
fi

if [[ -z "$KFP_VERSION" ]]; then
    KFP_VERSION=$("$SCRIPT_DIR/version-manager.sh" default-kfp)
    log_info "Using default KFP version: $KFP_VERSION"
fi

if [[ -z "$CLUSTER_NAME" ]]; then
    CLUSTER_NAME="kfp-dev"
fi

# Validate versions
log_info "Validating versions..."
"$SCRIPT_DIR/version-manager.sh" validate k8s "$K8S_VERSION" || exit 1
"$SCRIPT_DIR/version-manager.sh" validate kfp "$KFP_VERSION" || exit 1

# Check compatibility
log_info "Checking version compatibility..."
"$SCRIPT_DIR/version-manager.sh" check "$K8S_VERSION" "$KFP_VERSION" || exit 1

# Get K3s image
K3S_IMAGE=$("$SCRIPT_DIR/version-manager.sh" get-k3s-image "$K8S_VERSION")
log_info "Using K3s image: $K3S_IMAGE"

# Generate cluster token
CLUSTER_TOKEN=$(openssl rand -hex 16 2>/dev/null || echo "kfp-dev-token-$(date +%s)")

# Registry name based on cluster name
REGISTRY_NAME="${CLUSTER_NAME}-registry"

# Select template based on mode
if [[ "$CLUSTER_MODE" == "multi" ]]; then
    TEMPLATE_FILE="$PROJECT_ROOT/infra/k3d-multi-node.yaml.tmpl"
else
    TEMPLATE_FILE="$PROJECT_ROOT/infra/k3d-single-node.yaml.tmpl"
fi

if [[ ! -f "$TEMPLATE_FILE" ]]; then
    log_error "Template file not found: $TEMPLATE_FILE"
    exit 1
fi

# Create data directories
mkdir -p "$PROJECT_ROOT/data/artifacts"
mkdir -p "$PROJECT_ROOT/data/minio"

# Generate config file
CONFIG_FILE="$PROJECT_ROOT/.generated/k3d-config-${CLUSTER_NAME}.yaml"
mkdir -p "$(dirname "$CONFIG_FILE")"

log_info "Generating cluster configuration..."
sed -e "s|{{K3S_IMAGE}}|$K3S_IMAGE|g" \
    -e "s|{{CLUSTER_NAME}}|$CLUSTER_NAME|g" \
    -e "s|{{REGISTRY_NAME}}|$REGISTRY_NAME|g" \
    -e "s|{{REGISTRY_PORT}}|$REGISTRY_PORT|g" \
    -e "s|{{PROJECT_ROOT}}|$PROJECT_ROOT|g" \
    -e "s|{{CLUSTER_TOKEN}}|$CLUSTER_TOKEN|g" \
    "$TEMPLATE_FILE" > "$CONFIG_FILE"

# Show configuration in dry-run mode
if [[ "$DRY_RUN" == "true" ]]; then
    echo ""
    echo "Generated configuration:"
    echo "========================"
    cat "$CONFIG_FILE"
    echo ""
    echo "Cluster settings:"
    echo "  Name: $CLUSTER_NAME"
    echo "  K8s Version: $K8S_VERSION"
    echo "  KFP Version: $KFP_VERSION"
    echo "  Mode: $CLUSTER_MODE"
    echo "  Registry: $REGISTRY_NAME:$REGISTRY_PORT"
    exit 0
fi

# Check if cluster already exists
if k3d cluster list 2>/dev/null | grep -q "^$CLUSTER_NAME "; then
    log_error "Cluster '$CLUSTER_NAME' already exists. Use cluster-destroy.sh first or choose a different name."
    exit 1
fi

# Create the cluster
log_info "Creating K3d cluster '$CLUSTER_NAME'..."
k3d cluster create --config "$CONFIG_FILE"

# Wait for cluster to be ready
log_info "Waiting for cluster to be ready..."
kubectl wait --for=condition=Ready nodes --all --timeout=300s

# Save cluster state
STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
mkdir -p "$(dirname "$STATE_FILE")"
cat > "$STATE_FILE" << EOF
# Current cluster state - auto-generated
cluster:
  name: $CLUSTER_NAME
  k8s_version: $K8S_VERSION
  kfp_version: $KFP_VERSION
  mode: $CLUSTER_MODE
  registry:
    name: $REGISTRY_NAME
    port: $REGISTRY_PORT
  created_at: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
  config_file: $CONFIG_FILE
EOF

log_success "Cluster '$CLUSTER_NAME' created successfully!"

# Install Kubeflow Pipelines if not skipped
if [[ "$SKIP_KFP" != "true" ]]; then
    log_info "Installing Kubeflow Pipelines $KFP_VERSION..."
    "$SCRIPT_DIR/install-kubeflow.sh" --version "$KFP_VERSION"
else
    log_info "Skipping Kubeflow Pipelines installation (--skip-kfp)"
fi

# Print summary
echo ""
echo "========================================"
echo "Cluster Summary"
echo "========================================"
echo "Name:          $CLUSTER_NAME"
echo "K8s Version:   $K8S_VERSION"
echo "KFP Version:   $KFP_VERSION"
echo "Mode:          $CLUSTER_MODE"
echo "Registry:      localhost:$REGISTRY_PORT"
echo ""
echo "Next steps:"
echo "  1. Access KFP UI:  make port-forward"
echo "  2. Build components: make build-all"
echo "  3. Deploy pipeline: make deploy-pipeline PIPELINE=gbm-training"
echo ""
