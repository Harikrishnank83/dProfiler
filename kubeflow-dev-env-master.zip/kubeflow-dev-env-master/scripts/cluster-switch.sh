#!/usr/bin/env bash
# Switch kubectl context to a different K3d cluster
# Usage: ./cluster-switch.sh <cluster-name>

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

CLUSTER_NAME="${1:-}"

# Parse arguments
if [[ "$CLUSTER_NAME" == "--help" || "$CLUSTER_NAME" == "-h" ]]; then
    echo "Switch to a different K3d cluster"
    echo ""
    echo "Usage: $0 <cluster-name>"
    echo ""
    echo "Arguments:"
    echo "  cluster-name    Name of the cluster to switch to"
    echo ""
    echo "Example:"
    echo "  $0 kfp-dev-v2.1"
    exit 0
fi

if [[ -z "$CLUSTER_NAME" ]]; then
    log_error "Cluster name is required"
    echo ""
    echo "Available clusters:"
    k3d cluster list 2>/dev/null || echo "  No clusters found"
    exit 1
fi

# Check if cluster exists
if ! k3d cluster list 2>/dev/null | grep -q "^$CLUSTER_NAME "; then
    log_error "Cluster '$CLUSTER_NAME' does not exist"
    echo ""
    echo "Available clusters:"
    k3d cluster list 2>/dev/null || echo "  No clusters found"
    exit 1
fi

# Switch context
CONTEXT_NAME="k3d-$CLUSTER_NAME"
log_info "Switching to cluster '$CLUSTER_NAME'..."

# Check if context exists
if ! kubectl config get-contexts "$CONTEXT_NAME" &>/dev/null; then
    # Context doesn't exist, might need to recreate kubeconfig
    log_info "Context not found, updating kubeconfig..."
    k3d kubeconfig merge "$CLUSTER_NAME" --kubeconfig-switch-context
else
    kubectl config use-context "$CONTEXT_NAME"
fi

# Verify connection
log_info "Verifying cluster connection..."
if ! kubectl cluster-info &>/dev/null; then
    log_error "Could not connect to cluster"
    exit 1
fi

# Update cluster state file with new current cluster
# Note: This requires reading the cluster's actual versions
# For now, we'll just update the name and mark versions as unknown
STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
mkdir -p "$(dirname "$STATE_FILE")"

# Try to read existing config for this cluster if available
CONFIG_FILE="$PROJECT_ROOT/.generated/k3d-config-${CLUSTER_NAME}.yaml"
if [[ -f "$CONFIG_FILE" ]]; then
    log_info "Found cluster configuration file"
fi

# Update state file
cat > "$STATE_FILE" << EOF
# Current cluster state - auto-generated
cluster:
  name: $CLUSTER_NAME
  k8s_version: unknown
  kfp_version: unknown
  mode: unknown
  switched_at: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
  note: "Switched via cluster-switch.sh. Run 'make status' to update version info."
EOF

log_success "Switched to cluster '$CLUSTER_NAME'"

# Show cluster info
echo ""
echo "Current context: $CONTEXT_NAME"
echo ""
echo "Cluster nodes:"
kubectl get nodes 2>/dev/null || log_warning "Could not get node information"

echo ""
log_info "Run 'make status' to verify cluster state"
