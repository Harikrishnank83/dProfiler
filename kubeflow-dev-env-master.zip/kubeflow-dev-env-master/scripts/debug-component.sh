#!/usr/bin/env bash
# Debug a component locally without Docker
# Usage: ./debug-component.sh --component NAME

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

COMPONENT=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --component)
            COMPONENT="$2"
            shift 2
            ;;
        --help|-h)
            echo "Debug a component locally"
            echo ""
            echo "Usage: $0 --component NAME"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [[ -z "$COMPONENT" ]]; then
    log_error "Component name is required"
    exit 1
fi

COMPONENT_DIR="$PROJECT_ROOT/components/$COMPONENT"
if [[ ! -d "$COMPONENT_DIR" ]]; then
    log_error "Component not found: $COMPONENT"
    exit 1
fi

log_info "Debugging component: $COMPONENT"
log_info "Component directory: $COMPONENT_DIR"
echo ""

# Activate virtual environment if it exists
if [[ -d "$PROJECT_ROOT/.venv" ]]; then
    source "$PROJECT_ROOT/.venv/bin/activate"
fi

# Set PYTHONPATH
export PYTHONPATH="$COMPONENT_DIR/src:${PYTHONPATH:-}"

# Start interactive Python shell
cd "$COMPONENT_DIR"
log_info "Starting Python shell in $COMPONENT_DIR"
log_info "Component source is available in PYTHONPATH"
echo ""
python -i -c "
import sys
sys.path.insert(0, 'src')
print('Component debugging session')
print('Import your module: from main import *')
"
