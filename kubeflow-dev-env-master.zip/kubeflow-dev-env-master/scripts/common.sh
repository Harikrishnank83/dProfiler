#!/usr/bin/env bash
# Common utilities for shell scripts

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Print colored output
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_debug() { 
    if [[ "${DEBUG:-false}" == "true" ]]; then
        echo -e "${MAGENTA}[DEBUG]${NC} $1"
    fi
}
log_step() { echo -e "${CYAN}[STEP]${NC} $1"; }

# Check if a command exists
command_exists() {
    command -v "$1" &> /dev/null
}

# Check required dependencies
check_dependencies() {
    local deps=("$@")
    local missing=()
    
    for dep in "${deps[@]}"; do
        if ! command_exists "$dep"; then
            missing+=("$dep")
        fi
    done
    
    if [[ ${#missing[@]} -gt 0 ]]; then
        log_error "Missing dependencies: ${missing[*]}"
        return 1
    fi
    return 0
}

# Wait for a condition with timeout
wait_for() {
    local condition="$1"
    local timeout="${2:-60}"
    local interval="${3:-5}"
    local elapsed=0
    
    while [[ $elapsed -lt $timeout ]]; do
        if eval "$condition"; then
            return 0
        fi
        sleep "$interval"
        elapsed=$((elapsed + interval))
        log_debug "Waiting... ($elapsed/$timeout seconds)"
    done
    
    log_error "Timeout waiting for condition: $condition"
    return 1
}

# Get the project root directory
get_project_root() {
    local script_dir
    script_dir="$(cd "$(dirname "${BASH_SOURCE[1]}")" && pwd)"
    dirname "$script_dir"
}

# Load configuration from YAML file
load_config() {
    local config_file="$1"
    if [[ ! -f "$config_file" ]]; then
        log_error "Configuration file not found: $config_file"
        return 1
    fi
    
    if ! command_exists yq; then
        log_error "yq is required to parse YAML configuration"
        return 1
    fi
}

# Get current cluster name from state file
get_current_cluster() {
    local project_root
    project_root=$(get_project_root)
    local state_file="$project_root/config/cluster-state.yaml"
    
    if [[ -f "$state_file" ]] && command_exists yq; then
        yq '.cluster.name' "$state_file"
    else
        echo ""
    fi
}

# Get current K8s version from state file
get_current_k8s_version() {
    local project_root
    project_root=$(get_project_root)
    local state_file="$project_root/config/cluster-state.yaml"
    
    if [[ -f "$state_file" ]] && command_exists yq; then
        yq '.cluster.k8s_version' "$state_file"
    else
        echo ""
    fi
}

# Get current KFP version from state file
get_current_kfp_version() {
    local project_root
    project_root=$(get_project_root)
    local state_file="$project_root/config/cluster-state.yaml"
    
    if [[ -f "$state_file" ]] && command_exists yq; then
        yq '.cluster.kfp_version' "$state_file"
    else
        echo ""
    fi
}

# Confirm action with user
confirm() {
    local message="${1:-Are you sure?}"
    local default="${2:-n}"
    
    if [[ "$default" == "y" ]]; then
        read -rp "$message [Y/n] " response
        [[ -z "$response" || "$response" =~ ^[Yy] ]]
    else
        read -rp "$message [y/N] " response
        [[ "$response" =~ ^[Yy] ]]
    fi
}

# Print a section header
print_header() {
    local title="$1"
    local width="${2:-50}"
    local line
    line=$(printf '=%.0s' $(seq 1 "$width"))
    echo ""
    echo "$line"
    echo "$title"
    echo "$line"
}

# Print key-value pair
print_kv() {
    local key="$1"
    local value="$2"
    local width="${3:-20}"
    printf "%-${width}s %s\n" "$key:" "$value"
}

# Generate a random string
random_string() {
    local length="${1:-16}"
    openssl rand -hex "$length" 2>/dev/null | head -c "$length" || \
        cat /dev/urandom | tr -dc 'a-zA-Z0-9' | head -c "$length"
}

# Cleanup function for trap
cleanup_on_exit() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code: $exit_code"
    fi
    # Add cleanup tasks here
    exit $exit_code
}

# Set up trap for cleanup (call this at the beginning of scripts if needed)
setup_cleanup_trap() {
    trap cleanup_on_exit EXIT
}
