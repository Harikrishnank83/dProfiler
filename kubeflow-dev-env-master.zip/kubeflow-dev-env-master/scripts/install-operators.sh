#!/usr/bin/env bash
# Install optional operators (Dask, Ray)
# Usage: ./install-operators.sh [--dask] [--ray] [--all]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

# Default values
INSTALL_DASK="false"
INSTALL_RAY="false"
SKIP_HELM_REPOS="false"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dask)
            INSTALL_DASK="true"
            shift
            ;;
        --ray)
            INSTALL_RAY="true"
            shift
            ;;
        --all)
            INSTALL_DASK="true"
            INSTALL_RAY="true"
            shift
            ;;
        --skip-helm-repos)
            SKIP_HELM_REPOS="true"
            shift
            ;;
        --help|-h)
            echo "Install optional Kubernetes operators"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --dask              Install Dask Kubernetes Operator"
            echo "  --ray               Install Ray (KubeRay) Operator"
            echo "  --all               Install all operators"
            echo "  --skip-helm-repos   Skip adding Helm repositories"
            echo "  --help              Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [[ "$INSTALL_DASK" == "false" && "$INSTALL_RAY" == "false" ]]; then
    log_warning "No operators specified. Use --dask, --ray, or --all"
    exit 0
fi

# Check if Helm is installed
if ! command_exists helm; then
    log_error "Helm is required to install operators"
    log_info "Install Helm: https://helm.sh/docs/intro/install/"
    exit 1
fi

# Check cluster connectivity
log_info "Checking cluster connectivity..."
if ! kubectl cluster-info &>/dev/null; then
    log_error "Cannot connect to Kubernetes cluster"
    exit 1
fi

# Add Helm repositories
if [[ "$SKIP_HELM_REPOS" != "true" ]]; then
    log_info "Adding Helm repositories..."
    
    if [[ "$INSTALL_DASK" == "true" ]]; then
        helm repo add dask https://helm.dask.org 2>/dev/null || true
    fi
    
    if [[ "$INSTALL_RAY" == "true" ]]; then
        helm repo add kuberay https://ray-project.github.io/kuberay-helm 2>/dev/null || true
    fi
    
    helm repo update
fi

# Install Dask Operator
if [[ "$INSTALL_DASK" == "true" ]]; then
    log_step "Installing Dask Kubernetes Operator..."
    
    # Create namespace
    kubectl create namespace dask-operator --dry-run=client -o yaml | kubectl apply -f -
    
    # Install via Helm
    helm upgrade --install dask-operator dask/dask-kubernetes-operator \
        --namespace dask-operator \
        --wait \
        --timeout 300s
    
    log_success "Dask Operator installed!"
    
    # Verify installation
    kubectl get pods -n dask-operator
fi

# Install Ray Operator
if [[ "$INSTALL_RAY" == "true" ]]; then
    log_step "Installing KubeRay Operator..."
    
    # Create namespace
    kubectl create namespace ray-system --dry-run=client -o yaml | kubectl apply -f -
    
    # Install via Helm
    helm upgrade --install kuberay-operator kuberay/kuberay-operator \
        --namespace ray-system \
        --wait \
        --timeout 300s
    
    log_success "Ray Operator installed!"
    
    # Verify installation
    kubectl get pods -n ray-system
fi

# Update cluster state
STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
if [[ -f "$STATE_FILE" ]]; then
    if [[ "$INSTALL_DASK" == "true" ]]; then
        yq -i ".cluster.operators.dask = true" "$STATE_FILE"
    fi
    if [[ "$INSTALL_RAY" == "true" ]]; then
        yq -i ".cluster.operators.ray = true" "$STATE_FILE"
    fi
fi

echo ""
log_success "Operator installation complete!"
echo ""
echo "Installed operators:"
if [[ "$INSTALL_DASK" == "true" ]]; then
    echo "  - Dask Kubernetes Operator (namespace: dask-operator)"
fi
if [[ "$INSTALL_RAY" == "true" ]]; then
    echo "  - KubeRay Operator (namespace: ray-system)"
fi
