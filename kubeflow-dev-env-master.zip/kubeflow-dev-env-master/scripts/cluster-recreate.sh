#!/usr/bin/env bash
# Destroy and recreate a cluster with the same or different versions
# Usage: ./cluster-recreate.sh [--k8s VERSION] [--kfp VERSION] [--name NAME]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

# Default values - will be populated from current cluster if not specified
K8S_VERSION=""
KFP_VERSION=""
CLUSTER_NAME=""
CLUSTER_MODE=""
PRESERVE_DATA="true"
SNAPSHOT="true"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --k8s)
            K8S_VERSION="$2"
            shift 2
            ;;
        --kfp)
            KFP_VERSION="$2"
            shift 2
            ;;
        --name)
            CLUSTER_NAME="$2"
            shift 2
            ;;
        --mode)
            CLUSTER_MODE="$2"
            shift 2
            ;;
        --no-preserve)
            PRESERVE_DATA="false"
            shift
            ;;
        --no-snapshot)
            SNAPSHOT="false"
            shift
            ;;
        --help|-h)
            echo "Destroy and recreate a cluster"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --k8s VERSION     New Kubernetes version (default: current)"
            echo "  --kfp VERSION     New Kubeflow version (default: current)"
            echo "  --name NAME       Cluster name (default: current)"
            echo "  --mode MODE       Cluster mode: single or multi (default: current)"
            echo "  --no-preserve     Don't preserve data volumes"
            echo "  --no-snapshot     Don't create snapshot before recreating"
            echo "  --help            Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Load current cluster state
STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
if [[ -f "$STATE_FILE" ]]; then
    CURRENT_NAME=$(yq '.cluster.name' "$STATE_FILE" 2>/dev/null || echo "")
    CURRENT_K8S=$(yq '.cluster.k8s_version' "$STATE_FILE" 2>/dev/null || echo "")
    CURRENT_KFP=$(yq '.cluster.kfp_version' "$STATE_FILE" 2>/dev/null || echo "")
    CURRENT_MODE=$(yq '.cluster.mode' "$STATE_FILE" 2>/dev/null || echo "single")
else
    log_warning "No current cluster state found"
    CURRENT_NAME=""
    CURRENT_K8S=""
    CURRENT_KFP=""
    CURRENT_MODE="single"
fi

# Use current values as defaults
CLUSTER_NAME="${CLUSTER_NAME:-$CURRENT_NAME}"
K8S_VERSION="${K8S_VERSION:-$CURRENT_K8S}"
KFP_VERSION="${KFP_VERSION:-$CURRENT_KFP}"
CLUSTER_MODE="${CLUSTER_MODE:-$CURRENT_MODE}"

if [[ -z "$CLUSTER_NAME" || "$CLUSTER_NAME" == "null" ]]; then
    CLUSTER_NAME="kfp-dev"
fi

if [[ -z "$K8S_VERSION" || "$K8S_VERSION" == "null" ]]; then
    K8S_VERSION=$("$SCRIPT_DIR/version-manager.sh" default-k8s)
fi

if [[ -z "$KFP_VERSION" || "$KFP_VERSION" == "null" ]]; then
    KFP_VERSION=$("$SCRIPT_DIR/version-manager.sh" default-kfp)
fi

# Show recreation plan
print_header "Cluster Recreation Plan"
echo ""
echo "Current configuration:"
print_kv "  Name" "${CURRENT_NAME:-none}"
print_kv "  K8s" "${CURRENT_K8S:-none}"
print_kv "  KFP" "${CURRENT_KFP:-none}"
print_kv "  Mode" "${CURRENT_MODE:-unknown}"
echo ""
echo "New configuration:"
print_kv "  Name" "$CLUSTER_NAME"
print_kv "  K8s" "$K8S_VERSION"
print_kv "  KFP" "$KFP_VERSION"
print_kv "  Mode" "$CLUSTER_MODE"
echo ""

# Confirm
if ! confirm "Proceed with cluster recreation?"; then
    log_info "Aborted"
    exit 0
fi

# Create snapshot if requested
if [[ "$SNAPSHOT" == "true" && -n "$CURRENT_NAME" && "$CURRENT_NAME" != "null" ]]; then
    log_info "Creating snapshot before recreation..."
    "$SCRIPT_DIR/snapshot-cluster.sh" --name "$CURRENT_NAME" 2>/dev/null || \
        log_warning "Could not create snapshot (cluster may not exist)"
fi

# Destroy existing cluster
if [[ -n "$CURRENT_NAME" && "$CURRENT_NAME" != "null" ]]; then
    log_info "Destroying existing cluster '$CURRENT_NAME'..."
    if [[ "$PRESERVE_DATA" == "true" ]]; then
        "$SCRIPT_DIR/cluster-destroy.sh" --name "$CURRENT_NAME" --force
    else
        "$SCRIPT_DIR/cluster-destroy.sh" --name "$CURRENT_NAME" --force --purge
    fi
fi

# Create new cluster
log_info "Creating new cluster..."
"$SCRIPT_DIR/cluster-create.sh" \
    --name "$CLUSTER_NAME" \
    --k8s "$K8S_VERSION" \
    --kfp "$KFP_VERSION" \
    --mode "$CLUSTER_MODE"

log_success "Cluster recreated successfully!"
