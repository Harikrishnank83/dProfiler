#!/usr/bin/env bash
# Upgrade Kubeflow version on existing cluster
# Note: K8s version upgrades require cluster recreation
# Usage: ./cluster-upgrade.sh --kfp VERSION

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

# Default values
KFP_VERSION=""
DRY_RUN="false"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --kfp)
            KFP_VERSION="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN="true"
            shift
            ;;
        --help|-h)
            echo "Upgrade Kubeflow Pipelines version on existing cluster"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --kfp VERSION    Target Kubeflow Pipelines version"
            echo "  --dry-run        Show what would be done without making changes"
            echo "  --help           Show this help message"
            echo ""
            echo "Note: Kubernetes version upgrades require cluster recreation."
            echo "      Use cluster-recreate.sh for K8s version changes."
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [[ -z "$KFP_VERSION" ]]; then
    log_error "KFP version is required"
    echo "Use --kfp VERSION to specify the target version"
    exit 1
fi

# Get current cluster info
CLUSTER_NAME=$(get_current_cluster)
CURRENT_K8S=$(get_current_k8s_version)
CURRENT_KFP=$(get_current_kfp_version)

if [[ -z "$CLUSTER_NAME" || "$CLUSTER_NAME" == "null" ]]; then
    log_error "No current cluster found"
    exit 1
fi

# Validate new version
"$SCRIPT_DIR/version-manager.sh" validate kfp "$KFP_VERSION" || exit 1

# Check compatibility with current K8s version
if [[ -n "$CURRENT_K8S" && "$CURRENT_K8S" != "null" ]]; then
    "$SCRIPT_DIR/version-manager.sh" check "$CURRENT_K8S" "$KFP_VERSION" || exit 1
fi

# Show upgrade plan
print_header "Kubeflow Pipelines Upgrade Plan"
echo ""
print_kv "Cluster" "$CLUSTER_NAME"
print_kv "K8s Version" "$CURRENT_K8S"
print_kv "Current KFP" "$CURRENT_KFP"
print_kv "Target KFP" "$KFP_VERSION"
echo ""

if [[ "$CURRENT_KFP" == "$KFP_VERSION" ]]; then
    log_warning "Current version is already $KFP_VERSION"
    exit 0
fi

if [[ "$DRY_RUN" == "true" ]]; then
    log_info "Dry run mode - no changes will be made"
    echo ""
    echo "Would perform the following actions:"
    echo "  1. Backup current Kubeflow deployment"
    echo "  2. Apply new Kubeflow manifests for version $KFP_VERSION"
    echo "  3. Wait for rollout to complete"
    echo "  4. Update cluster state file"
    exit 0
fi

# Confirm
if ! confirm "Proceed with upgrade?"; then
    log_info "Aborted"
    exit 0
fi

# Create backup
log_info "Creating backup of current Kubeflow deployment..."
BACKUP_DIR="$PROJECT_ROOT/.backups/kfp-${CURRENT_KFP}-$(date +%Y%m%d%H%M%S)"
mkdir -p "$BACKUP_DIR"
kubectl get all -n kubeflow -o yaml > "$BACKUP_DIR/all-resources.yaml" 2>/dev/null || true
kubectl get configmaps -n kubeflow -o yaml > "$BACKUP_DIR/configmaps.yaml" 2>/dev/null || true
kubectl get secrets -n kubeflow -o yaml > "$BACKUP_DIR/secrets.yaml" 2>/dev/null || true
log_info "Backup saved to: $BACKUP_DIR"

# Get new manifest URL
MANIFEST_URL=$("$SCRIPT_DIR/version-manager.sh" get-kfp-manifest "$KFP_VERSION")
if [[ -z "$MANIFEST_URL" || "$MANIFEST_URL" == "null" ]]; then
    log_error "Could not get manifest URL for KFP version $KFP_VERSION"
    exit 1
fi

# Apply new manifests
log_info "Applying Kubeflow Pipelines $KFP_VERSION manifests..."
kubectl apply -k "github.com/kubeflow/pipelines/manifests/kustomize/cluster-scoped-resources?ref=$KFP_VERSION" 2>/dev/null || \
    kubectl apply -f "$MANIFEST_URL"

# Wait for rollout
log_info "Waiting for Kubeflow components to be ready..."
kubectl wait --for=condition=Available deployment -l app=ml-pipeline -n kubeflow --timeout=300s 2>/dev/null || \
    log_warning "Timeout waiting for ml-pipeline deployment"

# Update cluster state
STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
if [[ -f "$STATE_FILE" ]]; then
    # Update KFP version in state file
    yq -i ".cluster.kfp_version = \"$KFP_VERSION\"" "$STATE_FILE"
    yq -i ".cluster.upgraded_at = \"$(date -u +"%Y-%m-%dT%H:%M:%SZ")\"" "$STATE_FILE"
    yq -i ".cluster.previous_kfp_version = \"$CURRENT_KFP\"" "$STATE_FILE"
fi

log_success "Kubeflow Pipelines upgraded to $KFP_VERSION!"

echo ""
echo "Backup location: $BACKUP_DIR"
echo ""
log_info "Run 'make port-forward' to access the updated UI"
