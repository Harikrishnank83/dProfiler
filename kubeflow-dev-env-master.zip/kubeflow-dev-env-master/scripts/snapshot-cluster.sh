#!/usr/bin/env bash
# Create a snapshot of the current cluster state
# Usage: ./snapshot-cluster.sh [--name cluster-name]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

CLUSTER_NAME=""
OUTPUT_DIR=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --name)
            CLUSTER_NAME="$2"
            shift 2
            ;;
        --output)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --help|-h)
            echo "Create a snapshot of cluster state"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --name NAME       Cluster name (default: current cluster)"
            echo "  --output DIR      Output directory for snapshot"
            echo "  --help            Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Get cluster name
if [[ -z "$CLUSTER_NAME" ]]; then
    CLUSTER_NAME=$(get_current_cluster)
    if [[ -z "$CLUSTER_NAME" || "$CLUSTER_NAME" == "null" ]]; then
        log_error "No cluster name specified and no current cluster found"
        exit 1
    fi
fi

# Set output directory
TIMESTAMP=$(date +%Y%m%d%H%M%S)
if [[ -z "$OUTPUT_DIR" ]]; then
    OUTPUT_DIR="$PROJECT_ROOT/.snapshots/${CLUSTER_NAME}-${TIMESTAMP}"
fi

mkdir -p "$OUTPUT_DIR"

log_info "Creating snapshot of cluster '$CLUSTER_NAME'..."

# Save cluster state
STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
if [[ -f "$STATE_FILE" ]]; then
    cp "$STATE_FILE" "$OUTPUT_DIR/cluster-state.yaml"
fi

# Save k3d cluster config
CONFIG_FILE="$PROJECT_ROOT/.generated/k3d-config-${CLUSTER_NAME}.yaml"
if [[ -f "$CONFIG_FILE" ]]; then
    cp "$CONFIG_FILE" "$OUTPUT_DIR/k3d-config.yaml"
fi

# Save kubeconfig for this cluster
KUBECONFIG_FILE="$OUTPUT_DIR/kubeconfig.yaml"
k3d kubeconfig get "$CLUSTER_NAME" > "$KUBECONFIG_FILE" 2>/dev/null || \
    log_warning "Could not export kubeconfig"

# Export Kubernetes resources
log_info "Exporting Kubernetes resources..."

# Namespaces
kubectl get namespaces -o yaml > "$OUTPUT_DIR/namespaces.yaml" 2>/dev/null || true

# Kubeflow resources
mkdir -p "$OUTPUT_DIR/kubeflow"
kubectl get all -n kubeflow -o yaml > "$OUTPUT_DIR/kubeflow/all-resources.yaml" 2>/dev/null || true
kubectl get configmaps -n kubeflow -o yaml > "$OUTPUT_DIR/kubeflow/configmaps.yaml" 2>/dev/null || true
kubectl get pvc -n kubeflow -o yaml > "$OUTPUT_DIR/kubeflow/pvcs.yaml" 2>/dev/null || true

# Custom resources
kubectl get workflows.argoproj.io -n kubeflow -o yaml > "$OUTPUT_DIR/kubeflow/workflows.yaml" 2>/dev/null || true
kubectl get experiments.kubeflow.org -n kubeflow -o yaml > "$OUTPUT_DIR/kubeflow/experiments.yaml" 2>/dev/null || true
kubectl get runs.kubeflow.org -n kubeflow -o yaml > "$OUTPUT_DIR/kubeflow/runs.yaml" 2>/dev/null || true

# Create snapshot metadata
cat > "$OUTPUT_DIR/snapshot-metadata.yaml" << EOF
# Cluster Snapshot Metadata
snapshot:
  cluster_name: $CLUSTER_NAME
  created_at: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
  k8s_version: $(get_current_k8s_version)
  kfp_version: $(get_current_kfp_version)
  
contents:
  - cluster-state.yaml
  - k3d-config.yaml
  - kubeconfig.yaml
  - namespaces.yaml
  - kubeflow/
    - all-resources.yaml
    - configmaps.yaml
    - pvcs.yaml
    - workflows.yaml
    - experiments.yaml
    - runs.yaml
EOF

# Calculate snapshot size
SNAPSHOT_SIZE=$(du -sh "$OUTPUT_DIR" | cut -f1)

log_success "Snapshot created successfully!"
echo ""
print_kv "Location" "$OUTPUT_DIR"
print_kv "Size" "$SNAPSHOT_SIZE"
echo ""
log_info "To restore, use: ./scripts/import-cluster.sh --snapshot $OUTPUT_DIR"
