#!/bin/bash
#
# preflight-check.sh - Pre-flight checks for Kubeflow Development Environment
#
# Detects existing installations, versions, conflicts, and provides recommendations
#
# Usage:
#   ./scripts/preflight-check.sh              # Full check with recommendations
#   ./scripts/preflight-check.sh --json       # Output in JSON format
#   ./scripts/preflight-check.sh --strict     # Exit with error on any issue
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Flags
JSON_OUTPUT=false
STRICT_MODE=false
ISSUES_FOUND=0
WARNINGS_FOUND=0

# Parse arguments
for arg in "$@"; do
    case $arg in
        --json) JSON_OUTPUT=true ;;
        --strict) STRICT_MODE=true ;;
        *) ;;
    esac
done

# Results storage
declare -A RESULTS
declare -A VERSIONS
declare -A CONFLICTS
declare -A RECOMMENDATIONS

# Helper functions
log_section() {
    if ! $JSON_OUTPUT; then
        echo ""
        echo -e "${BOLD}${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo -e "${BOLD}${BLUE}▶ $1${NC}"
        echo -e "${BOLD}${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    fi
}

log_ok() {
    if ! $JSON_OUTPUT; then
        echo -e "${GREEN}  ✓${NC} $1"
    fi
    RESULTS["$2"]="ok"
}

log_warn() {
    if ! $JSON_OUTPUT; then
        echo -e "${YELLOW}  ⚠${NC} $1"
    fi
    RESULTS["$2"]="warning"
    ((WARNINGS_FOUND++))
}

log_error() {
    if ! $JSON_OUTPUT; then
        echo -e "${RED}  ✗${NC} $1"
    fi
    RESULTS["$2"]="error"
    ((ISSUES_FOUND++))
}

log_info() {
    if ! $JSON_OUTPUT; then
        echo -e "${CYAN}  ℹ${NC} $1"
    fi
}

log_conflict() {
    if ! $JSON_OUTPUT; then
        echo -e "${RED}  ⚠ CONFLICT:${NC} $1"
    fi
    CONFLICTS["$2"]="$1"
    ((ISSUES_FOUND++))
}

log_recommend() {
    if ! $JSON_OUTPUT; then
        echo -e "${CYAN}    → Recommendation:${NC} $1"
    fi
    RECOMMENDATIONS["$2"]="$1"
}

# Check Docker
check_docker() {
    log_section "Docker"
    
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed" "docker_installed"
        log_recommend "Install from: https://docs.docker.com/get-docker/" "docker_install"
        return 1
    fi
    
    VERSIONS["docker"]=$(docker version --format '{{.Client.Version}}' 2>/dev/null || echo "unknown")
    log_ok "Docker installed: v${VERSIONS[docker]}" "docker_installed"
    
    # Check if Docker daemon is running
    if ! docker info &> /dev/null; then
        log_error "Docker daemon is not running" "docker_running"
        if [[ "$OSTYPE" == "darwin"* ]]; then
            log_recommend "Start Docker Desktop: open -a Docker" "docker_start"
        else
            log_recommend "Start Docker: sudo systemctl start docker" "docker_start"
        fi
        return 1
    fi
    
    log_ok "Docker daemon is running" "docker_running"
    
    # Check Docker resources
    local mem_total=$(docker info --format '{{.MemTotal}}' 2>/dev/null || echo "0")
    local mem_gb=$((mem_total / 1024 / 1024 / 1024))
    VERSIONS["docker_memory_gb"]=$mem_gb
    
    if [[ $mem_gb -lt 4 ]]; then
        log_error "Docker memory too low: ${mem_gb}GB (minimum: 4GB)" "docker_memory"
        log_recommend "Increase in Docker Desktop > Settings > Resources > Memory" "docker_memory_increase"
    elif [[ $mem_gb -lt 8 ]]; then
        log_warn "Docker memory is adequate but recommended is 8GB+: ${mem_gb}GB" "docker_memory"
        log_recommend "For better performance, increase to 8GB+ in Docker Settings" "docker_memory_increase"
    else
        log_ok "Docker memory: ${mem_gb}GB" "docker_memory"
    fi
    
    # Check for existing k3d containers
    local k3d_containers=$(docker ps -a --filter "label=app=k3d" --format "{{.Names}}" 2>/dev/null)
    if [[ -n "$k3d_containers" ]]; then
        log_warn "Found existing k3d containers" "docker_k3d_containers"
        echo "$k3d_containers" | while read container; do
            local state=$(docker inspect --format='{{.State.Status}}' "$container" 2>/dev/null)
            log_info "  • $container (state: $state)"
        done
        log_recommend "Review existing containers: docker ps -a --filter 'label=app=k3d'" "docker_k3d_review"
    fi
    
    # Check for kfp-dev cluster specifically
    if docker ps -a --format "{{.Names}}" | grep -q "k3d-kfp-dev"; then
        log_conflict "k3d cluster 'kfp-dev' already exists" "cluster_exists"
        log_recommend "Delete existing cluster: k3d cluster delete kfp-dev" "cluster_delete"
        log_recommend "Or use existing cluster: k3d cluster start kfp-dev" "cluster_start"
    fi
    
    # Check for port conflicts
    check_port_usage 5000 "AirPlay Receiver or other service" "port_5000"
    check_port_usage 5050 "Alternative registry port (recommended)" "port_5050"
    check_port_usage 6443 "Kubernetes API" "port_6443"
    check_port_usage 8080 "Load balancer HTTP" "port_8080"
    check_port_usage 8888 "KFP API" "port_8888"
}

check_port_usage() {
    local port=$1
    local description=$2
    local key=$3
    
    local pid=$(lsof -ti:$port 2>/dev/null || echo "")
    if [[ -n "$pid" ]]; then
        local process=$(ps -p $pid -o comm= 2>/dev/null || echo "unknown")
        log_conflict "Port $port is in use by: $process (PID: $pid)" "$key"
        
        if [[ $port == "5000" ]] && [[ "$OSTYPE" == "darwin"* ]]; then
            log_recommend "On macOS, disable AirPlay Receiver in System Settings > General > AirDrop & Handoff" "port_5000_fix"
            log_recommend "Or use alternative port 5050 for registry" "port_5000_alternative"
        else
            log_recommend "Stop the process: kill $pid" "port_${port}_kill"
            log_recommend "Or use a different port when creating cluster" "port_${port}_alternative"
        fi
    fi
}

# Check k3d
check_k3d() {
    log_section "k3d"
    
    if ! command -v k3d &> /dev/null; then
        log_error "k3d is not installed" "k3d_installed"
        if command -v brew &> /dev/null; then
            log_recommend "Install via Homebrew: brew install k3d" "k3d_install"
        else
            log_recommend "Install via script: curl -s https://raw.githubusercontent.com/k3d-io/k3d/main/install.sh | bash" "k3d_install"
        fi
        return 1
    fi
    
    VERSIONS["k3d"]=$(k3d version 2>/dev/null | head -1 | awk '{print $3}')
    log_ok "k3d installed: ${VERSIONS[k3d]}" "k3d_installed"
    
    # Check for existing clusters
    local clusters=$(k3d cluster list 2>/dev/null | tail -n +2 | awk '{print $1}')
    if [[ -n "$clusters" ]]; then
        log_warn "Found existing k3d clusters" "k3d_clusters"
        echo "$clusters" | while read cluster; do
            local status=$(k3d cluster list 2>/dev/null | grep "^$cluster" | awk '{print $2}')
            log_info "  • $cluster (status: $status)"
            
            if [[ "$cluster" == "kfp-dev" ]]; then
                log_conflict "Target cluster 'kfp-dev' already exists" "kfp_dev_exists"
                log_recommend "Delete: k3d cluster delete kfp-dev" "kfp_dev_delete"
                log_recommend "Or reuse: k3d cluster start kfp-dev" "kfp_dev_reuse"
                log_recommend "Check status: ./scripts/diagnose.sh" "kfp_dev_diagnose"
            fi
        done
    else
        log_ok "No existing k3d clusters found" "k3d_clusters"
    fi
    
    # Check for registries
    local registries=$(docker ps --filter "name=k3d-.*-registry" --format "{{.Names}}" 2>/dev/null)
    if [[ -n "$registries" ]]; then
        log_warn "Found existing k3d registries" "k3d_registries"
        echo "$registries" | while read registry; do
            local port=$(docker port "$registry" 2>/dev/null | grep "5000/tcp" | cut -d':' -f2)
            log_info "  • $registry (port: ${port:-unknown})"
        done
        log_recommend "Review registries: docker ps --filter 'name=k3d-.*-registry'" "k3d_registries_review"
    fi
}

# Check kubectl
check_kubectl() {
    log_section "kubectl"
    
    if ! command -v kubectl &> /dev/null; then
        log_error "kubectl is not installed" "kubectl_installed"
        log_recommend "Install via Homebrew: brew install kubectl" "kubectl_install"
        return 1
    fi
    
    VERSIONS["kubectl"]=$(kubectl version --client -o json 2>/dev/null | jq -r '.clientVersion.gitVersion' || echo "unknown")
    log_ok "kubectl installed: ${VERSIONS[kubectl]}" "kubectl_installed"
    
    # Check current context
    local current_context=$(kubectl config current-context 2>/dev/null || echo "none")
    if [[ "$current_context" != "none" ]]; then
        log_info "Current context: $current_context"
        VERSIONS["kubectl_context"]=$current_context
        
        # Check if cluster is reachable
        if kubectl cluster-info &> /dev/null; then
            log_ok "Connected to cluster" "kubectl_connected"
            
            # Check if it's a k3d cluster
            if [[ "$current_context" == k3d-* ]]; then
                log_info "Connected to k3d cluster: $current_context"
                
                # Check for kubeflow namespace
                if kubectl get namespace kubeflow &> /dev/null; then
                    log_conflict "Kubeflow namespace already exists in current cluster" "kubeflow_namespace_exists"
                    log_recommend "This may be a previous installation" "kubeflow_previous"
                    log_recommend "Check status: kubectl get pods -n kubeflow" "kubeflow_check"
                    log_recommend "Or delete namespace: kubectl delete namespace kubeflow" "kubeflow_delete"
                fi
            fi
        else
            log_warn "Cannot connect to cluster at current context" "kubectl_connected"
        fi
    else
        log_ok "No kubectl context configured" "kubectl_context"
    fi
}

# Check Helm
check_helm() {
    log_section "Helm"
    
    if ! command -v helm &> /dev/null; then
        log_warn "Helm is not installed (optional)" "helm_installed"
        log_recommend "Install via Homebrew: brew install helm" "helm_install"
        return 0
    fi
    
    VERSIONS["helm"]=$(helm version --short 2>/dev/null | cut -d':' -f2 | tr -d ' ' || echo "unknown")
    log_ok "Helm installed: ${VERSIONS[helm]}" "helm_installed"
}

# Check Python
check_python() {
    log_section "Python Environment"
    
    if ! command -v python3 &> /dev/null; then
        log_error "Python 3 is not installed" "python_installed"
        log_recommend "Install Python 3.9+ from python.org or via Homebrew" "python_install"
        return 1
    fi
    
    VERSIONS["python"]=$(python3 --version 2>/dev/null | awk '{print $2}')
    local py_major=$(echo "${VERSIONS[python]}" | cut -d. -f1)
    local py_minor=$(echo "${VERSIONS[python]}" | cut -d. -f2)
    
    if [[ $py_major -lt 3 ]] || [[ $py_major -eq 3 && $py_minor -lt 9 ]]; then
        log_error "Python version ${VERSIONS[python]} is too old (minimum: 3.9)" "python_version"
        log_recommend "Upgrade Python to 3.9 or later" "python_upgrade"
    else
        log_ok "Python ${VERSIONS[python]}" "python_version"
    fi
    
    # Check pip
    if ! command -v pip3 &> /dev/null; then
        log_warn "pip3 is not installed" "pip_installed"
        log_recommend "Install pip: python3 -m ensurepip" "pip_install"
    else
        VERSIONS["pip"]=$(pip3 --version 2>/dev/null | awk '{print $2}')
        log_ok "pip ${VERSIONS[pip]}" "pip_installed"
    fi
    
    # Check for virtual environment tools
    if command -v virtualenv &> /dev/null || python3 -m venv --help &> /dev/null; then
        log_ok "Virtual environment support available" "venv_support"
    else
        log_warn "No virtual environment tool found" "venv_support"
        log_recommend "Install: pip3 install virtualenv" "venv_install"
    fi
}

# Check disk space
check_disk_space() {
    log_section "Disk Space"
    
    local available_gb=$(df -h "$PROJECT_ROOT" | tail -1 | awk '{print $4}' | sed 's/Gi*//')
    VERSIONS["disk_available_gb"]=$available_gb
    
    if [[ $(echo "$available_gb < 10" | bc -l 2>/dev/null || echo "0") -eq 1 ]]; then
        log_error "Low disk space: ${available_gb}GB available (minimum: 10GB)" "disk_space"
        log_recommend "Free up disk space before installation" "disk_space_free"
    elif [[ $(echo "$available_gb < 20" | bc -l 2>/dev/null || echo "0") -eq 1 ]]; then
        log_warn "Disk space is adequate but recommended is 20GB+: ${available_gb}GB" "disk_space"
        log_recommend "Consider freeing up space for better performance" "disk_space_free"
    else
        log_ok "Disk space: ${available_gb}GB available" "disk_space"
    fi
}

# Check Docker images
check_docker_images() {
    log_section "Docker Images"
    
    if ! docker info &> /dev/null; then
        log_info "Skipping (Docker not running)"
        return 0
    fi
    
    # Check for KFP-related images
    local kfp_images=$(docker images --format "{{.Repository}}:{{.Tag}}" | grep -E "(kubeflow|ml-pipeline|minio|mysql|argo)" || echo "")
    
    if [[ -n "$kfp_images" ]]; then
        log_warn "Found existing Kubeflow/ML images" "docker_kfp_images"
        local image_count=$(echo "$kfp_images" | wc -l | tr -d ' ')
        log_info "Found $image_count related images"
        
        echo "$kfp_images" | head -5 | while read image; do
            log_info "  • $image"
        done
        
        if [[ $image_count -gt 5 ]]; then
            log_info "  ... and $((image_count - 5)) more"
        fi
        
        log_recommend "These images may be reused during installation" "docker_images_reuse"
        log_recommend "To clean: docker system prune -a" "docker_images_clean"
    else
        log_ok "No existing KFP images found (will be pulled during installation)" "docker_kfp_images"
    fi
    
    # Check for custom component images
    local custom_images=$(docker images --format "{{.Repository}}:{{.Tag}}" | grep "localhost:5" || echo "")
    if [[ -n "$custom_images" ]]; then
        log_info "Found custom component images in local registry"
        echo "$custom_images" | head -3 | while read image; do
            log_info "  • $image"
        done
    fi
}

# Check network connectivity
check_network() {
    log_section "Network Connectivity"
    
    # Check Docker Hub
    if curl -s --connect-timeout 5 https://hub.docker.com > /dev/null; then
        log_ok "Docker Hub is reachable" "network_dockerhub"
    else
        log_warn "Cannot reach Docker Hub" "network_dockerhub"
        log_recommend "Check your internet connection and proxy settings" "network_check"
    fi
    
    # Check GitHub
    if curl -s --connect-timeout 5 https://github.com > /dev/null; then
        log_ok "GitHub is reachable" "network_github"
    else
        log_warn "Cannot reach GitHub" "network_github"
        log_recommend "Some manifests may fail to download" "network_github_warn"
    fi
    
    # Check GCR (may fail, which is expected)
    if curl -s --connect-timeout 5 https://gcr.io > /dev/null; then
        log_ok "GCR is reachable (but images may be deprecated)" "network_gcr"
    else
        log_info "GCR not reachable (expected, will use alternative images)" "network_gcr"
    fi
}

# Generate summary
generate_summary() {
    if $JSON_OUTPUT; then
        generate_json_report
        return
    fi
    
    log_section "Pre-flight Check Summary"
    
    echo ""
    if [[ $ISSUES_FOUND -eq 0 ]] && [[ $WARNINGS_FOUND -eq 0 ]]; then
        echo -e "${GREEN}${BOLD}✓ All checks passed!${NC}"
        echo -e "${GREEN}Your system is ready for Kubeflow installation.${NC}"
        echo ""
        echo "Next steps:"
        echo "  1. Run: make install          # Full installation"
        echo "  2. Or:  make cluster-create   # Create cluster only"
    elif [[ $ISSUES_FOUND -eq 0 ]]; then
        echo -e "${YELLOW}${BOLD}⚠ Checks completed with warnings ($WARNINGS_FOUND)${NC}"
        echo -e "${YELLOW}You can proceed with installation, but consider addressing warnings.${NC}"
        echo ""
        echo "To see detailed recommendations, scroll up or run with: ./scripts/preflight-check.sh | less"
    else
        echo -e "${RED}${BOLD}✗ Critical issues found: $ISSUES_FOUND${NC}"
        echo -e "${RED}Please resolve these issues before installation.${NC}"
        echo ""
        echo "Quick fixes:"
        if [[ ${CONFLICTS[cluster_exists]+_} ]]; then
            echo "  • Delete existing cluster: k3d cluster delete kfp-dev"
        fi
        if [[ ${CONFLICTS[port_5000]+_}  ]] || [[ ${CONFLICTS[port_5050]+_} ]]; then
            echo "  • Free up ports or use alternative ports during installation"
        fi
        if [[ ${RESULTS[docker_running]} == "error" ]]; then
            echo "  • Start Docker: open -a Docker  (macOS) or sudo systemctl start docker"
        fi
    fi
    
    echo ""
    echo -e "${CYAN}For detailed troubleshooting, see: docs/TROUBLESHOOTING.md${NC}"
    echo -e "${CYAN}For automated diagnosis: ./scripts/diagnose.sh${NC}"
}

generate_json_report() {
    local json="{"
    json+="\"summary\":{"
    json+="\"issues\":$ISSUES_FOUND,"
    json+="\"warnings\":$WARNINGS_FOUND,"
    json+="\"status\":\"$( [[ $ISSUES_FOUND -eq 0 ]] && echo "ready" || echo "blocked" )\""
    json+="},"
    
    json+="\"versions\":{"
    local first=true
    for key in "${!VERSIONS[@]}"; do
        $first || json+=","
        json+="\"$key\":\"${VERSIONS[$key]}\""
        first=false
    done
    json+="},"
    
    json+="\"results\":{"
    first=true
    for key in "${!RESULTS[@]}"; do
        $first || json+=","
        json+="\"$key\":\"${RESULTS[$key]}\""
        first=false
    done
    json+="},"
    
    json+="\"conflicts\":{"
    first=true
    for key in "${!CONFLICTS[@]}"; do
        $first || json+=","
        json+="\"$key\":\"${CONFLICTS[$key]}\""
        first=false
    done
    json+="},"
    
    json+="\"recommendations\":{"
    first=true
    for key in "${!RECOMMENDATIONS[@]}"; do
        $first || json+=","
        json+="\"$key\":\"${RECOMMENDATIONS[$key]}\""
        first=false
    done
    json+="}"
    
    json+="}"
    echo "$json" | jq '.' 2>/dev/null || echo "$json"
}

# Main execution
main() {
    if ! $JSON_OUTPUT; then
        echo -e "${BOLD}${BLUE}"
        echo "╔═══════════════════════════════════════════════════════════════════════╗"
        echo "║  Kubeflow Development Environment - Pre-flight Check                 ║"
        echo "╚═══════════════════════════════════════════════════════════════════════╝"
        echo -e "${NC}"
    fi
    
    check_docker
    check_k3d
    check_kubectl
    check_helm
    check_python
    check_disk_space
    check_docker_images
    check_network
    
    generate_summary
    
    # Exit code
    if $STRICT_MODE && [[ $ISSUES_FOUND -gt 0 ]]; then
        exit 1
    elif [[ $ISSUES_FOUND -gt 0 ]]; then
        exit 2
    elif [[ $WARNINGS_FOUND -gt 0 ]]; then
        exit 3
    else
        exit 0
    fi
}

main
