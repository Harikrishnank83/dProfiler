#!/usr/bin/env bash
# Port forward to Kubeflow Pipelines UI
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"

log_info "Starting port forward to Kubeflow Pipelines UI..."
log_info "Access at: http://localhost:8080"
log_info "Press Ctrl+C to stop"

kubectl port-forward -n kubeflow svc/ml-pipeline-ui 8080:80
