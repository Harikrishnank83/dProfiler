#!/usr/bin/env bash
# Destroy a K3d cluster and optionally clean up data
# Usage: ./cluster-destroy.sh [--name cluster-name] [--purge] [--force]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

# Default values
CLUSTER_NAME=""
PURGE_DATA="false"
FORCE="false"
SNAPSHOT="false"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --name)
            CLUSTER_NAME="$2"
            shift 2
            ;;
        --purge)
            PURGE_DATA="true"
            shift
            ;;
        --force|-f)
            FORCE="true"
            shift
            ;;
        --snapshot)
            SNAPSHOT="true"
            shift
            ;;
        --help|-h)
            echo "Destroy a K3d cluster"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --name NAME    Cluster name to destroy (default: current cluster)"
            echo "  --purge        Also delete data volumes (artifacts, minio data)"
            echo "  --snapshot     Create snapshot before destroying"
            echo "  --force, -f    Skip confirmation prompts"
            echo "  --help         Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Get cluster name from state if not specified
if [[ -z "$CLUSTER_NAME" ]]; then
    CLUSTER_NAME=$(get_current_cluster)
    if [[ -z "$CLUSTER_NAME" || "$CLUSTER_NAME" == "null" ]]; then
        log_error "No cluster name specified and no current cluster found"
        log_info "Use --name to specify a cluster or check 'k3d cluster list'"
        exit 1
    fi
    log_info "Using current cluster: $CLUSTER_NAME"
fi

# Check if cluster exists
if ! k3d cluster list 2>/dev/null | grep -q "^$CLUSTER_NAME "; then
    log_warning "Cluster '$CLUSTER_NAME' does not exist"
    
    # Still clean up state file if it references this cluster
    STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
    if [[ -f "$STATE_FILE" ]]; then
        current_in_state=$(yq '.cluster.name' "$STATE_FILE" 2>/dev/null || echo "")
        if [[ "$current_in_state" == "$CLUSTER_NAME" ]]; then
            rm -f "$STATE_FILE"
            log_info "Removed stale cluster state file"
        fi
    fi
    exit 0
fi

# Create snapshot if requested
if [[ "$SNAPSHOT" == "true" ]]; then
    log_info "Creating snapshot before destruction..."
    "$SCRIPT_DIR/snapshot-cluster.sh" --name "$CLUSTER_NAME"
fi

# Confirmation
if [[ "$FORCE" != "true" ]]; then
    echo ""
    log_warning "This will destroy cluster '$CLUSTER_NAME'"
    if [[ "$PURGE_DATA" == "true" ]]; then
        log_warning "Data volumes will also be deleted (--purge)"
    fi
    echo ""
    if ! confirm "Are you sure you want to continue?"; then
        log_info "Aborted"
        exit 0
    fi
fi

# Get registry name
REGISTRY_NAME="${CLUSTER_NAME}-registry"

# Delete the cluster
log_info "Destroying cluster '$CLUSTER_NAME'..."
k3d cluster delete "$CLUSTER_NAME"

# Delete the registry if it exists
if docker ps -a --format '{{.Names}}' | grep -q "^$REGISTRY_NAME$"; then
    log_info "Removing registry '$REGISTRY_NAME'..."
    docker rm -f "$REGISTRY_NAME" 2>/dev/null || true
fi

# Remove generated config files
CONFIG_FILE="$PROJECT_ROOT/.generated/k3d-config-${CLUSTER_NAME}.yaml"
if [[ -f "$CONFIG_FILE" ]]; then
    rm -f "$CONFIG_FILE"
    log_info "Removed generated config file"
fi

# Clean up data if --purge is specified
if [[ "$PURGE_DATA" == "true" ]]; then
    log_info "Purging data volumes..."
    rm -rf "$PROJECT_ROOT/data/artifacts"/*
    rm -rf "$PROJECT_ROOT/data/minio"/*
    log_info "Data volumes purged"
fi

# Remove cluster state file
STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
if [[ -f "$STATE_FILE" ]]; then
    current_in_state=$(yq '.cluster.name' "$STATE_FILE" 2>/dev/null || echo "")
    if [[ "$current_in_state" == "$CLUSTER_NAME" ]]; then
        rm -f "$STATE_FILE"
        log_info "Removed cluster state file"
    fi
fi

log_success "Cluster '$CLUSTER_NAME' destroyed successfully!"

# List remaining clusters
remaining=$(k3d cluster list 2>/dev/null | tail -n +2 | wc -l | tr -d ' ')
if [[ "$remaining" -gt 0 ]]; then
    echo ""
    log_info "Remaining clusters:"
    k3d cluster list
fi
