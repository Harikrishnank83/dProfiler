#!/usr/bin/env bash
# Install Kubeflow Pipelines on the current cluster
# Usage: ./install-kubeflow.sh --version 2.1.0

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

# Default values
KFP_VERSION=""
NAMESPACE="kubeflow"
WAIT_TIMEOUT="600s"
SKIP_WAIT="false"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --version)
            KFP_VERSION="$2"
            shift 2
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --timeout)
            WAIT_TIMEOUT="$2"
            shift 2
            ;;
        --skip-wait)
            SKIP_WAIT="true"
            shift
            ;;
        --help|-h)
            echo "Install Kubeflow Pipelines"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --version VERSION    KFP version to install (required)"
            echo "  --namespace NS       Target namespace (default: kubeflow)"
            echo "  --timeout DURATION   Wait timeout (default: 600s)"
            echo "  --skip-wait          Don't wait for pods to be ready"
            echo "  --help               Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [[ -z "$KFP_VERSION" ]]; then
    KFP_VERSION=$("$SCRIPT_DIR/version-manager.sh" default-kfp)
    log_info "Using default KFP version: $KFP_VERSION"
fi

# Validate version
"$SCRIPT_DIR/version-manager.sh" validate kfp "$KFP_VERSION" || exit 1

# Check cluster connectivity
log_info "Checking cluster connectivity..."
if ! kubectl cluster-info &>/dev/null; then
    log_error "Cannot connect to Kubernetes cluster"
    log_info "Make sure you have a running cluster and kubectl is configured"
    exit 1
fi

# Get manifest URL
MANIFEST_URL=$("$SCRIPT_DIR/version-manager.sh" get-kfp-manifest "$KFP_VERSION")
if [[ -z "$MANIFEST_URL" || "$MANIFEST_URL" == "null" ]]; then
    log_error "Could not get manifest URL for KFP version $KFP_VERSION"
    exit 1
fi

log_info "Installing Kubeflow Pipelines $KFP_VERSION..."
log_info "Manifest URL: $MANIFEST_URL"

# Create namespace if it doesn't exist
if ! kubectl get namespace "$NAMESPACE" &>/dev/null; then
    log_info "Creating namespace '$NAMESPACE'..."
    kubectl create namespace "$NAMESPACE"
fi

# Apply the KFP manifests
log_step "Applying Kubeflow Pipelines manifests..."

# Try kustomize first, fall back to direct manifest
KUSTOMIZE_URL="github.com/kubeflow/pipelines/manifests/kustomize/env/platform-agnostic-pns?ref=$KFP_VERSION"
if kubectl apply -k "$KUSTOMIZE_URL" 2>/dev/null; then
    log_success "Applied KFP manifests via kustomize"
else
    log_warning "Kustomize failed, trying direct manifest..."
    kubectl apply -f "$MANIFEST_URL"
fi

if [[ "$SKIP_WAIT" != "true" ]]; then
    # Wait for critical components
    log_step "Waiting for Kubeflow components to be ready..."
    
    # Wait for deployments
    DEPLOYMENTS=(
        "ml-pipeline"
        "ml-pipeline-ui"
        "ml-pipeline-persistenceagent"
        "ml-pipeline-scheduledworkflow"
        "ml-pipeline-viewer-crd"
    )
    
    for deployment in "${DEPLOYMENTS[@]}"; do
        log_info "Waiting for $deployment..."
        kubectl wait --for=condition=Available deployment/"$deployment" \
            -n "$NAMESPACE" --timeout="$WAIT_TIMEOUT" 2>/dev/null || \
            log_warning "Timeout waiting for $deployment"
    done
    
    # Wait for MySQL
    log_info "Waiting for MySQL..."
    kubectl wait --for=condition=Ready pod -l app=mysql \
        -n "$NAMESPACE" --timeout="$WAIT_TIMEOUT" 2>/dev/null || \
        log_warning "Timeout waiting for MySQL"
    
    # Wait for MinIO
    log_info "Waiting for MinIO..."
    kubectl wait --for=condition=Ready pod -l app=minio \
        -n "$NAMESPACE" --timeout="$WAIT_TIMEOUT" 2>/dev/null || \
        log_warning "Timeout waiting for MinIO"
fi

# Verify installation
log_step "Verifying installation..."
echo ""
echo "Kubeflow Pipelines pods:"
kubectl get pods -n "$NAMESPACE" -o wide

echo ""
echo "Kubeflow Pipelines services:"
kubectl get svc -n "$NAMESPACE"

# Update cluster state
STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
if [[ -f "$STATE_FILE" ]]; then
    yq -i ".cluster.kfp_version = \"$KFP_VERSION\"" "$STATE_FILE"
    yq -i ".cluster.kfp_installed_at = \"$(date -u +"%Y-%m-%dT%H:%M:%SZ")\"" "$STATE_FILE"
fi

log_success "Kubeflow Pipelines $KFP_VERSION installed successfully!"

echo ""
echo "Next steps:"
echo "  1. Port forward to access UI: make port-forward"
echo "  2. Open http://localhost:8080 in your browser"
echo "  3. Deploy a pipeline: make deploy-pipeline PIPELINE=gbm-training"
