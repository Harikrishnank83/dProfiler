#!/usr/bin/env bash
# Version Manager for Kubeflow Development Environment
# Handles version switching, validation, and compatibility checks

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
VERSIONS_FILE="${PROJECT_ROOT}/versions/versions.yaml"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored output
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check if yq is installed
check_yq() {
    if ! command -v yq &> /dev/null; then
        log_error "yq is required but not installed."
        log_info "Install with: brew install yq (macOS) or snap install yq (Linux)"
        exit 1
    fi
}

# Get default K8s version
get_default_k8s_version() {
    check_yq
    yq '.kubernetes[] | select(.default == true) | .version' "$VERSIONS_FILE" | head -1
}

# Get default Kubeflow version
get_default_kfp_version() {
    check_yq
    yq '.kubeflow[] | select(.default == true) | .version' "$VERSIONS_FILE" | head -1
}

# List available K8s versions
list_k8s_versions() {
    check_yq
    echo "Available Kubernetes versions:"
    echo "=============================="
    yq '.kubernetes[] | [.version, .supported, .notes] | @tsv' "$VERSIONS_FILE" | \
        while IFS=$'\t' read -r version supported notes; do
            default_marker=""
            if [[ $(yq ".kubernetes[] | select(.version == \"$version\") | .default // false" "$VERSIONS_FILE") == "true" ]]; then
                default_marker=" (default)"
            fi
            if [[ "$supported" == "true" ]]; then
                echo -e "  ${GREEN}✓${NC} $version$default_marker - $notes"
            else
                echo -e "  ${RED}✗${NC} $version$default_marker - $notes (unsupported)"
            fi
        done
}

# List available Kubeflow versions
list_kfp_versions() {
    check_yq
    echo "Available Kubeflow Pipelines versions:"
    echo "======================================="
    yq '.kubeflow[] | [.version, .supported, .notes] | @tsv' "$VERSIONS_FILE" | \
        while IFS=$'\t' read -r version supported notes; do
            default_marker=""
            if [[ $(yq ".kubeflow[] | select(.version == \"$version\") | .default // false" "$VERSIONS_FILE") == "true" ]]; then
                default_marker=" (default)"
            fi
            compatible=$(yq ".kubeflow[] | select(.version == \"$version\") | .compatible_k8s | join(\", \")" "$VERSIONS_FILE")
            if [[ "$supported" == "true" ]]; then
                echo -e "  ${GREEN}✓${NC} $version$default_marker - $notes"
                echo -e "      Compatible K8s: $compatible"
            else
                echo -e "  ${RED}✗${NC} $version$default_marker - $notes (unsupported)"
            fi
        done
}

# List available operator versions
list_operator_versions() {
    check_yq
    echo "Available Operator versions:"
    echo "============================"
    echo ""
    echo "Dask Operator:"
    yq '.operators.dask[] | [.version, .chart_name] | @tsv' "$VERSIONS_FILE" | \
        while IFS=$'\t' read -r version chart; do
            echo -e "  ${GREEN}✓${NC} $version - $chart"
        done
    echo ""
    echo "Ray Operator:"
    yq '.operators.ray[] | [.version, .chart_name] | @tsv' "$VERSIONS_FILE" | \
        while IFS=$'\t' read -r version chart; do
            echo -e "  ${GREEN}✓${NC} $version - $chart"
        done
}

# Check compatibility between K8s and KFP versions
check_compatibility() {
    local k8s_version="$1"
    local kfp_version="$2"
    
    check_yq
    
    # Extract major.minor from k8s version
    local k8s_minor="${k8s_version%.*}"
    
    # Check if KFP version supports this K8s version
    local compatible
    compatible=$(yq ".kubeflow[] | select(.version == \"$kfp_version\") | .compatible_k8s | .[] | select(. == \"$k8s_minor\")" "$VERSIONS_FILE")
    
    if [[ -n "$compatible" ]]; then
        log_success "K8s $k8s_version is compatible with KFP $kfp_version"
        return 0
    else
        log_error "K8s $k8s_version is NOT compatible with KFP $kfp_version"
        log_info "Compatible K8s versions for KFP $kfp_version:"
        yq ".kubeflow[] | select(.version == \"$kfp_version\") | .compatible_k8s[]" "$VERSIONS_FILE"
        return 1
    fi
}

# Get K3s image for K8s version
get_k3s_image() {
    local k8s_version="$1"
    check_yq
    yq ".kubernetes[] | select(.version == \"$k8s_version\") | .k3s_image" "$VERSIONS_FILE"
}

# Get KFP manifest URL
get_kfp_manifest_url() {
    local kfp_version="$1"
    check_yq
    yq ".kubeflow[] | select(.version == \"$kfp_version\") | .manifest_url" "$VERSIONS_FILE"
}

# Validate versions exist
validate_version() {
    local version_type="$1"
    local version="$2"
    
    check_yq
    
    local found
    if [[ "$version_type" == "k8s" ]]; then
        found=$(yq ".kubernetes[] | select(.version == \"$version\") | .version" "$VERSIONS_FILE")
    elif [[ "$version_type" == "kfp" ]]; then
        found=$(yq ".kubeflow[] | select(.version == \"$version\") | .version" "$VERSIONS_FILE")
    else
        log_error "Unknown version type: $version_type"
        return 1
    fi
    
    if [[ -n "$found" ]]; then
        return 0
    else
        log_error "$version_type version $version not found in versions.yaml"
        return 1
    fi
}

# Show version matrix
show_version_matrix() {
    check_yq
    echo ""
    echo "Version Compatibility Matrix"
    echo "============================"
    echo ""
    printf "%-12s" "K8s \\ KFP"
    for kfp_ver in $(yq '.kubeflow[].version' "$VERSIONS_FILE"); do
        printf "%-10s" "$kfp_ver"
    done
    echo ""
    echo "-------------------------------------------"
    
    for k8s_ver in $(yq '.kubernetes[].version' "$VERSIONS_FILE"); do
        k8s_minor="${k8s_ver%.*}"
        printf "%-12s" "$k8s_ver"
        for kfp_ver in $(yq '.kubeflow[].version' "$VERSIONS_FILE"); do
            compatible=$(yq ".kubeflow[] | select(.version == \"$kfp_ver\") | .compatible_k8s | .[] | select(. == \"$k8s_minor\")" "$VERSIONS_FILE")
            if [[ -n "$compatible" ]]; then
                printf "${GREEN}%-10s${NC}" "✓"
            else
                printf "${RED}%-10s${NC}" "✗"
            fi
        done
        echo ""
    done
    echo ""
}

# Main command handler
main() {
    local cmd="${1:-help}"
    shift || true
    
    case "$cmd" in
        list-k8s)
            list_k8s_versions
            ;;
        list-kfp)
            list_kfp_versions
            ;;
        list-operators)
            list_operator_versions
            ;;
        list-all)
            list_k8s_versions
            echo ""
            list_kfp_versions
            echo ""
            list_operator_versions
            ;;
        check)
            if [[ $# -lt 2 ]]; then
                log_error "Usage: $0 check <k8s-version> <kfp-version>"
                exit 1
            fi
            check_compatibility "$1" "$2"
            ;;
        matrix)
            show_version_matrix
            ;;
        default-k8s)
            get_default_k8s_version
            ;;
        default-kfp)
            get_default_kfp_version
            ;;
        get-k3s-image)
            if [[ $# -lt 1 ]]; then
                log_error "Usage: $0 get-k3s-image <k8s-version>"
                exit 1
            fi
            get_k3s_image "$1"
            ;;
        get-kfp-manifest)
            if [[ $# -lt 1 ]]; then
                log_error "Usage: $0 get-kfp-manifest <kfp-version>"
                exit 1
            fi
            get_kfp_manifest_url "$1"
            ;;
        validate)
            if [[ $# -lt 2 ]]; then
                log_error "Usage: $0 validate <k8s|kfp> <version>"
                exit 1
            fi
            validate_version "$1" "$2"
            ;;
        help|--help|-h)
            echo "Version Manager for Kubeflow Development Environment"
            echo ""
            echo "Usage: $0 <command> [options]"
            echo ""
            echo "Commands:"
            echo "  list-k8s              List available Kubernetes versions"
            echo "  list-kfp              List available Kubeflow Pipelines versions"
            echo "  list-operators        List available operator versions"
            echo "  list-all              List all available versions"
            echo "  check <k8s> <kfp>     Check compatibility between versions"
            echo "  matrix                Show version compatibility matrix"
            echo "  default-k8s           Get default Kubernetes version"
            echo "  default-kfp           Get default Kubeflow version"
            echo "  get-k3s-image <k8s>   Get K3s image for K8s version"
            echo "  get-kfp-manifest <kfp> Get KFP manifest URL"
            echo "  validate <type> <ver> Validate version exists"
            echo "  help                  Show this help message"
            ;;
        *)
            log_error "Unknown command: $cmd"
            echo "Use '$0 help' for usage information"
            exit 1
            ;;
    esac
}

main "$@"
