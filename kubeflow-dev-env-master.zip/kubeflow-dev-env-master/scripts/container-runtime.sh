#!/usr/bin/env bash
# Container Runtime Abstraction Layer
# Supports: Docker Desktop, Colima, Podman, Rancher Desktop
# Usage: source this file to use runtime-agnostic functions

set -euo pipefail

# Determine script location
if [[ -n "${BASH_SOURCE[0]:-}" ]]; then
    RUNTIME_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    RUNTIME_PROJECT_ROOT="$(dirname "$RUNTIME_SCRIPT_DIR")"
    
    # Source common utilities if available
    if [[ -f "$RUNTIME_SCRIPT_DIR/common.sh" ]]; then
        source "$RUNTIME_SCRIPT_DIR/common.sh"
    fi
fi

# Runtime configuration file
RUNTIME_CONFIG="${RUNTIME_PROJECT_ROOT:-$(pwd)}/config/runtime-config.yaml"

# Supported runtimes (bash 3.2 compatible)
# Format: runtime_name:description
# Note: Using a simple string format instead of associative arrays for bash 3.2 compatibility
SUPPORTED_RUNTIMES=""
SUPPORTED_RUNTIMES+="docker:Docker Desktop or Docker Engine"$'\n'
SUPPORTED_RUNTIMES+="colima:Colima (Containers on Lima)"$'\n'
SUPPORTED_RUNTIMES+="podman:Podman (Daemonless container engine)"$'\n'
SUPPORTED_RUNTIMES+="rancher-desktop:Rancher Desktop"$'\n'

# Runtime detection functions

detect_docker() {
    if ! command -v docker &> /dev/null; then
        return 1
    fi
    
    # Check if Docker is running
    if ! docker info &> /dev/null 2>&1; then
        return 1
    fi
    
    # Determine Docker variant
    local docker_info=$(docker info 2>/dev/null || echo "")
    
    if echo "$docker_info" | grep -qi "lima"; then
        echo "colima"
    elif echo "$docker_info" | grep -qi "rancher"; then
        echo "rancher-desktop"
    else
        echo "docker"
    fi
    return 0
}

detect_colima() {
    if ! command -v colima &> /dev/null; then
        return 1
    fi
    
    # Check if Colima is running
    if colima status &> /dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

detect_podman() {
    if ! command -v podman &> /dev/null; then
        return 1
    fi
    
    # Check if Podman machine is running (macOS/Windows)
    if [[ "$(uname)" == "Darwin" ]]; then
        if podman machine list 2>/dev/null | grep -q "Currently running"; then
            return 0
        fi
        return 1
    fi
    
    # On Linux, Podman runs natively
    if podman info &> /dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

detect_rancher_desktop() {
    # Check for Rancher Desktop specific indicators
    if [[ "$(uname)" == "Darwin" ]]; then
        if [[ -d "/Applications/Rancher Desktop.app" ]]; then
            # Check if it's running via Docker
            if docker info 2>/dev/null | grep -qi "rancher"; then
                return 0
            fi
        fi
    fi
    return 1
}

# Detect current active runtime
detect_active_runtime() {
    local runtime=""
    
    # Check for Docker-compatible runtimes first
    if runtime=$(detect_docker); then
        echo "$runtime"
        return 0
    fi
    
    # Check for Podman
    if detect_podman; then
        echo "podman"
        return 0
    fi
    
    # No runtime detected
    return 1
}

# Detect all available runtimes (installed but may not be running)
detect_available_runtimes() {
    local available=()
    
    if command -v docker &> /dev/null; then
        available+=("docker")
    fi
    
    if command -v colima &> /dev/null; then
        available+=("colima")
    fi
    
    if command -v podman &> /dev/null; then
        available+=("podman")
    fi
    
    if [[ "$(uname)" == "Darwin" ]] && [[ -d "/Applications/Rancher Desktop.app" ]]; then
        available+=("rancher-desktop")
    fi
    
    echo "${available[@]}"
}

# Start runtime
start_runtime() {
    local runtime="$1"
    
    case "$runtime" in
        docker)
            if [[ "$(uname)" == "Darwin" ]]; then
                log_info "Starting Docker Desktop..."
                open -a Docker
                sleep 15
                if docker info &> /dev/null; then
                    log_success "Docker Desktop started"
                    return 0
                fi
            else
                log_info "Starting Docker..."
                sudo systemctl start docker
                sleep 5
                if docker info &> /dev/null; then
                    log_success "Docker started"
                    return 0
                fi
            fi
            return 1
            ;;
            
        colima)
            log_info "Starting Colima..."
            # Load saved config if exists
            local cpu=4
            local mem=8
            local disk=100
            
            if [[ -f "$RUNTIME_CONFIG" ]]; then
                cpu=$(yq '.colima.cpu // 4' "$RUNTIME_CONFIG" 2>/dev/null || echo 4)
                mem=$(yq '.colima.memory // 8' "$RUNTIME_CONFIG" 2>/dev/null || echo 8)
                disk=$(yq '.colima.disk // 100' "$RUNTIME_CONFIG" 2>/dev/null || echo 100)
            fi
            
            colima start --cpu "$cpu" --memory "$mem" --disk "$disk" 2>&1
            
            if colima status &> /dev/null; then
                log_success "Colima started"
                return 0
            fi
            return 1
            ;;
            
        podman)
            log_info "Starting Podman..."
            if [[ "$(uname)" == "Darwin" ]]; then
                # macOS requires Podman machine
                if ! podman machine list 2>/dev/null | grep -q "podman-machine"; then
                    log_info "Initializing Podman machine..."
                    podman machine init
                fi
                podman machine start
            fi
            
            if detect_podman; then
                log_success "Podman started"
                return 0
            fi
            return 1
            ;;
            
        rancher-desktop)
            if [[ "$(uname)" == "Darwin" ]]; then
                log_info "Starting Rancher Desktop..."
                open -a "Rancher Desktop"
                sleep 20
                if docker info 2>/dev/null | grep -qi "rancher"; then
                    log_success "Rancher Desktop started"
                    return 0
                fi
            fi
            return 1
            ;;
            
        *)
            log_error "Unknown runtime: $runtime"
            return 1
            ;;
    esac
}

# Stop runtime
stop_runtime() {
    local runtime="$1"
    
    case "$runtime" in
        colima)
            colima stop
            ;;
        podman)
            if [[ "$(uname)" == "Darwin" ]]; then
                podman machine stop
            fi
            ;;
        docker|rancher-desktop)
            log_warning "Please stop $runtime manually"
            ;;
    esac
}

# Get runtime-specific Docker socket
get_docker_socket() {
    local runtime="$1"
    
    case "$runtime" in
        docker|colima|rancher-desktop)
            echo "/var/run/docker.sock"
            ;;
        podman)
            if [[ "$(uname)" == "Darwin" ]]; then
                # Podman socket location on macOS
                local machine_name=$(podman machine list --format "{{.Name}}" 2>/dev/null | head -1)
                echo "$HOME/.local/share/containers/podman/machine/${machine_name}/podman.sock"
            else
                # Linux Podman socket
                echo "/run/podman/podman.sock"
            fi
            ;;
    esac
}

# Get container command (docker or podman)
get_container_cmd() {
    local runtime="${1:-$(detect_active_runtime)}"
    
    case "$runtime" in
        docker|colima|rancher-desktop)
            echo "docker"
            ;;
        podman)
            echo "podman"
            ;;
        *)
            echo "docker"  # Default fallback
            ;;
    esac
}

# Runtime compatibility check for k3d
check_k3d_compatibility() {
    local runtime="$1"
    
    case "$runtime" in
        docker|colima|rancher-desktop)
            # k3d works natively with Docker API
            return 0
            ;;
        podman)
            # k3d has experimental Podman support
            log_warning "k3d with Podman is experimental"
            log_info "You may need to use Podman's Docker compatibility socket"
            
            # Check if Podman Docker socket is available
            if podman info --format "{{.Host.RemoteSocket.Path}}" &> /dev/null; then
                log_info "Podman Docker socket available"
                return 0
            fi
            
            log_error "Podman Docker compatibility socket not available"
            log_info "Enable with: systemctl --user enable --now podman.socket"
            return 1
            ;;
        *)
            return 1
            ;;
    esac
}

# Get runtime installation instructions
get_install_instructions() {
    local runtime="$1"
    
    case "$runtime" in
        docker)
            echo "Install Docker Desktop from: https://docs.docker.com/get-docker/"
            if [[ "$(uname)" == "Darwin" ]]; then
                echo "Or via Homebrew: brew install --cask docker"
            fi
            ;;
        colima)
            echo "Install Colima:"
            echo "  macOS:  brew install colima"
            echo "  Linux:  See https://github.com/abiosoft/colima"
            ;;
        podman)
            echo "Install Podman:"
            echo "  macOS:  brew install podman"
            echo "  Linux:  sudo apt install podman  # Ubuntu/Debian"
            echo "          sudo dnf install podman  # Fedora/RHEL"
            ;;
        rancher-desktop)
            echo "Install Rancher Desktop:"
            echo "  macOS:  brew install --cask rancher"
            echo "  Or download from: https://rancherdesktop.io/"
            ;;
    esac
}

# Get runtime status
get_runtime_status() {
    local runtime="$1"
    
    case "$runtime" in
        docker)
            if docker info &> /dev/null 2>&1; then
                echo "running"
            else
                echo "stopped"
            fi
            ;;
        colima)
            if colima status &> /dev/null 2>&1; then
                echo "running"
            else
                echo "stopped"
            fi
            ;;
        podman)
            if detect_podman; then
                echo "running"
            else
                echo "stopped"
            fi
            ;;
        rancher-desktop)
            if docker info 2>/dev/null | grep -qi "rancher"; then
                echo "running"
            else
                echo "stopped"
            fi
            ;;
        *)
            echo "unknown"
            ;;
    esac
}

# Save runtime preference
save_runtime_preference() {
    local runtime="$1"
    local config_dir=$(dirname "$RUNTIME_CONFIG")
    
    mkdir -p "$config_dir"
    
    cat > "$RUNTIME_CONFIG" << EOF
# Container Runtime Configuration
# Auto-generated on $(date)

# Preferred runtime: docker, colima, podman, rancher-desktop
preferred_runtime: $runtime

# Runtime-specific settings
colima:
  cpu: 4
  memory: 8
  disk: 100

podman:
  machine_name: podman-machine-default
  rootful: false

docker:
  # Docker Desktop settings (configured via GUI)

rancher-desktop:
  # Rancher Desktop settings (configured via GUI)
EOF
    
    log_success "Saved runtime preference: $runtime"
}

# Load runtime preference
load_runtime_preference() {
    if [[ -f "$RUNTIME_CONFIG" ]]; then
        yq '.preferred_runtime // ""' "$RUNTIME_CONFIG" 2>/dev/null || echo ""
    fi
}

# Print runtime info
print_runtime_info() {
    local runtime="${1:-$(detect_active_runtime)}"
    
    echo "Runtime: $runtime"
    echo "Status: $(get_runtime_status "$runtime")"
    echo "Container Command: $(get_container_cmd "$runtime")"
    
    if [[ "$runtime" == "docker" ]] || [[ "$runtime" == "colima" ]]; then
        local mem_gb=$(docker info --format '{{.MemTotal}}' 2>/dev/null | awk '{print int($1/1024/1024/1024)}' || echo "unknown")
        echo "Memory: ${mem_gb}GB"
    fi
}

# Export functions for use in other scripts
export -f detect_active_runtime
export -f detect_available_runtimes
export -f start_runtime
export -f stop_runtime
export -f get_container_cmd
export -f check_k3d_compatibility
export -f get_runtime_status
export -f save_runtime_preference
export -f load_runtime_preference
