#!/usr/bin/env bash
# List all K3d clusters with their version information
# Usage: ./cluster-list.sh [--verbose]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$SCRIPT_DIR/common.sh"

VERBOSE="false"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --verbose|-v)
            VERBOSE="true"
            shift
            ;;
        --help|-h)
            echo "List all K3d clusters"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --verbose, -v    Show detailed information"
            echo "  --help           Show this help message"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Get current cluster from state
CURRENT_CLUSTER=$(get_current_cluster)
CURRENT_K8S=$(get_current_k8s_version)
CURRENT_KFP=$(get_current_kfp_version)

print_header "K3d Clusters"

# Check if any clusters exist
if ! command_exists k3d; then
    log_error "k3d is not installed"
    exit 1
fi

clusters=$(k3d cluster list --no-headers 2>/dev/null || true)
if [[ -z "$clusters" ]]; then
    log_info "No clusters found"
    exit 0
fi

# List clusters
echo ""
printf "%-20s %-10s %-12s %-10s %-10s\n" "NAME" "STATUS" "K8S VERSION" "KFP" "NODES"
printf "%-20s %-10s %-12s %-10s %-10s\n" "----" "------" "-----------" "---" "-----"

while IFS= read -r line; do
    name=$(echo "$line" | awk '{print $1}')
    nodes=$(echo "$line" | awk '{print $2}')
    
    # Mark current cluster
    marker=""
    k8s_ver=""
    kfp_ver=""
    if [[ "$name" == "$CURRENT_CLUSTER" ]]; then
        marker=" *"
        k8s_ver="$CURRENT_K8S"
        kfp_ver="$CURRENT_KFP"
    fi
    
    # Get status
    running=$(docker ps --filter "name=k3d-${name}" --format '{{.Status}}' | head -1)
    if [[ -n "$running" ]]; then
        status="Running"
    else
        status="Stopped"
    fi
    
    printf "%-20s %-10s %-12s %-10s %-10s\n" "${name}${marker}" "$status" "${k8s_ver:-unknown}" "${kfp_ver:-unknown}" "$nodes"
done <<< "$clusters"

echo ""
echo "* = current cluster (from cluster-state.yaml)"

if [[ "$VERBOSE" == "true" ]]; then
    echo ""
    print_header "Detailed Information"
    
    if [[ -n "$CURRENT_CLUSTER" && "$CURRENT_CLUSTER" != "null" ]]; then
        echo ""
        echo "Current cluster details:"
        STATE_FILE="$PROJECT_ROOT/config/cluster-state.yaml"
        if [[ -f "$STATE_FILE" ]]; then
            cat "$STATE_FILE"
        fi
        
        echo ""
        echo "Cluster nodes:"
        kubectl get nodes -o wide 2>/dev/null || log_warning "Could not get node information"
        
        echo ""
        echo "Kubeflow namespace status:"
        kubectl get pods -n kubeflow 2>/dev/null || log_warning "Kubeflow namespace not found or not accessible"
    fi
    
    echo ""
    echo "Docker containers for k3d:"
    docker ps --filter "name=k3d-" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null || true
fi
