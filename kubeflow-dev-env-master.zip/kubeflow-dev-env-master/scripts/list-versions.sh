#!/usr/bin/env bash
# List all available versions
# Simple wrapper around version-manager.sh for convenience

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

exec "$SCRIPT_DIR/version-manager.sh" list-all
