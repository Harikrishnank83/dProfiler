#!/bin/bash
#
# diagnose.sh - Diagnose and optionally fix common KFP issues
#
# Usage:
#   ./scripts/diagnose.sh           # Run diagnosis only
#   ./scripts/diagnose.sh --fix     # Diagnose and apply fixes
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh" 2>/dev/null || true

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

FIX_MODE=false
if [[ "$1" == "--fix" ]]; then
    FIX_MODE=true
fi

ISSUES_FOUND=0
ISSUES_FIXED=0

# Helper functions
print_header() {
    echo ""
    echo -e "${BLUE}=== $1 ===${NC}"
}

print_ok() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}⚠${NC} $1"
    ((ISSUES_FOUND++))
}

print_error() {
    echo -e "${RED}✗${NC} $1"
    ((ISSUES_FOUND++))
}

print_fix() {
    echo -e "${GREEN}→${NC} Applied fix: $1"
    ((ISSUES_FIXED++))
}

# Checks

check_docker() {
    print_header "Docker"
    
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed"
        echo "  Install from: https://docs.docker.com/get-docker/"
        return 1
    fi
    
    if ! docker info &> /dev/null; then
        print_error "Docker daemon is not running"
        if $FIX_MODE; then
            echo "  Attempting to start Docker..."
            if [[ "$OSTYPE" == "darwin"* ]]; then
                open -a Docker
                sleep 15
                if docker info &> /dev/null; then
                    print_fix "Started Docker Desktop"
                else
                    echo "  Please start Docker manually"
                fi
            else
                echo "  Run: sudo systemctl start docker"
            fi
        fi
        return 1
    fi
    
    print_ok "Docker is running"
    
    # Check Docker resources
    local mem_total=$(docker info --format '{{.MemTotal}}' 2>/dev/null || echo "0")
    local mem_gb=$((mem_total / 1024 / 1024 / 1024))
    if [[ $mem_gb -lt 6 ]]; then
        print_warn "Docker memory is low: ${mem_gb}GB (recommended: 8GB+)"
        echo "  Increase in Docker Desktop > Settings > Resources"
    else
        print_ok "Docker memory: ${mem_gb}GB"
    fi
}

check_k3d() {
    print_header "k3d"
    
    if ! command -v k3d &> /dev/null; then
        print_error "k3d is not installed"
        if $FIX_MODE; then
            echo "  Installing k3d..."
            if command -v brew &> /dev/null; then
                brew install k3d
                print_fix "Installed k3d via Homebrew"
            else
                curl -s https://raw.githubusercontent.com/k3d-io/k3d/main/install.sh | bash
                print_fix "Installed k3d via install script"
            fi
        else
            echo "  Install with: brew install k3d"
        fi
        return 1
    fi
    
    print_ok "k3d version: $(k3d version | head -1 | awk '{print $3}')"
}

check_kubectl() {
    print_header "kubectl"
    
    if ! command -v kubectl &> /dev/null; then
        print_error "kubectl is not installed"
        echo "  Install with: brew install kubectl"
        return 1
    fi
    
    print_ok "kubectl installed"
    
    if ! kubectl cluster-info &> /dev/null 2>&1; then
        print_warn "kubectl not connected to a cluster"
        
        # Check if k3d cluster exists
        if k3d cluster list 2>/dev/null | grep -q "kfp-dev"; then
            if $FIX_MODE; then
                k3d kubeconfig merge kfp-dev --kubeconfig-switch-context
                print_fix "Switched kubectl context to kfp-dev"
            else
                echo "  Run: k3d kubeconfig merge kfp-dev --kubeconfig-switch-context"
            fi
        else
            echo "  No kfp-dev cluster found. Create one first."
        fi
        return 1
    fi
    
    print_ok "kubectl connected to cluster"
}

check_cluster() {
    print_header "K3d Cluster"
    
    if ! k3d cluster list 2>/dev/null | grep -q "kfp-dev"; then
        print_error "Cluster 'kfp-dev' does not exist"
        echo "  Create with: make cluster-create"
        return 1
    fi
    
    local cluster_status=$(k3d cluster list 2>/dev/null | grep "kfp-dev" | awk '{print $2}')
    if [[ "$cluster_status" != "1/1" ]]; then
        print_warn "Cluster 'kfp-dev' may not be fully running: $cluster_status"
        if $FIX_MODE; then
            k3d cluster start kfp-dev
            print_fix "Started kfp-dev cluster"
        fi
    else
        print_ok "Cluster 'kfp-dev' is running"
    fi
    
    # Check nodes
    local nodes_ready=$(kubectl get nodes --no-headers 2>/dev/null | grep -c "Ready" || echo "0")
    local nodes_total=$(kubectl get nodes --no-headers 2>/dev/null | wc -l | tr -d ' ')
    if [[ "$nodes_ready" != "$nodes_total" ]]; then
        print_warn "Not all nodes are ready: $nodes_ready/$nodes_total"
    else
        print_ok "All nodes ready: $nodes_ready/$nodes_total"
    fi
}

check_kubeflow_namespace() {
    print_header "Kubeflow Namespace"
    
    if ! kubectl get namespace kubeflow &> /dev/null; then
        print_error "Namespace 'kubeflow' does not exist"
        echo "  Install Kubeflow Pipelines first"
        return 1
    fi
    
    local ns_status=$(kubectl get namespace kubeflow -o jsonpath='{.status.phase}' 2>/dev/null)
    if [[ "$ns_status" == "Terminating" ]]; then
        print_error "Namespace 'kubeflow' is stuck in Terminating"
        if $FIX_MODE; then
            echo "  Attempting to force delete..."
            kubectl get namespace kubeflow -o json | \
                jq '.spec.finalizers = []' | \
                kubectl replace --raw "/api/v1/namespaces/kubeflow/finalize" -f - &> /dev/null || true
            print_fix "Removed finalizers from namespace"
        else
            echo "  Run: ./scripts/diagnose.sh --fix"
        fi
        return 1
    fi
    
    print_ok "Namespace 'kubeflow' exists"
}

check_kubeflow_pods() {
    print_header "Kubeflow Pods"
    
    if ! kubectl get namespace kubeflow &> /dev/null; then
        echo "  Skipping - namespace not found"
        return 1
    fi
    
    local pods_info=$(kubectl get pods -n kubeflow --no-headers 2>/dev/null)
    local total_pods=$(echo "$pods_info" | wc -l | tr -d ' ')
    local running_pods=$(echo "$pods_info" | grep -c "Running" || echo "0")
    
    echo "  Total pods: $total_pods, Running: $running_pods"
    
    # Check for problematic pods
    local problem_pods=$(echo "$pods_info" | grep -E "Error|CrashLoopBackOff|ImagePullBackOff|Pending" || true)
    
    if [[ -n "$problem_pods" ]]; then
        echo ""
        echo "  Problem pods:"
        echo "$problem_pods" | while read line; do
            local pod_name=$(echo "$line" | awk '{print $1}')
            local pod_status=$(echo "$line" | awk '{print $3}')
            print_error "$pod_name: $pod_status"
        done
        
        # Specific fixes
        if echo "$problem_pods" | grep -q "minio.*ImagePullBackOff"; then
            if $FIX_MODE; then
                kubectl patch deployment minio -n kubeflow --type='json' -p='[
                  {"op": "replace", "path": "/spec/template/spec/containers/0/image", "value": "minio/minio:RELEASE.2023-06-19T19-52-50Z"},
                  {"op": "replace", "path": "/spec/template/spec/containers/0/command", "value": ["/bin/sh", "-c", "minio server /data --console-address :9001"]}
                ]' 2>/dev/null
                print_fix "Patched minio deployment with official image"
            else
                echo ""
                echo "  Minio image issue detected. Run with --fix to apply patch."
            fi
        fi
        
        if echo "$problem_pods" | grep -q "workflow-controller.*CrashLoopBackOff"; then
            if $FIX_MODE; then
                kubectl patch deployment workflow-controller -n kubeflow --type='json' -p='[
                  {"op": "replace", "path": "/spec/template/spec/containers/0/image", "value": "quay.io/argoproj/workflow-controller:v3.4.17"}
                ]' 2>/dev/null
                print_fix "Patched workflow-controller with upstream Argo image"
            else
                echo ""
                echo "  Workflow controller crash detected. Run with --fix to apply patch."
            fi
        fi
        
        if echo "$problem_pods" | grep -q "ml-pipeline-ui.*ImagePullBackOff"; then
            if $FIX_MODE; then
                kubectl scale deployment ml-pipeline-ui -n kubeflow --replicas=0 2>/dev/null
                print_fix "Scaled down ml-pipeline-ui (image not available)"
            else
                echo ""
                echo "  UI image not available. Run with --fix to disable UI."
            fi
        fi
        
        return 1
    else
        print_ok "All pods are running"
    fi
}

check_api_server() {
    print_header "KFP API Server"
    
    if ! kubectl get deployment ml-pipeline -n kubeflow &> /dev/null; then
        print_error "ml-pipeline deployment not found"
        return 1
    fi
    
    local ready=$(kubectl get deployment ml-pipeline -n kubeflow -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")
    if [[ "$ready" == "1" ]]; then
        print_ok "API server is ready"
        
        # Test API endpoint
        local test_result=$(kubectl exec -n kubeflow deployment/ml-pipeline -- wget -qO- http://localhost:8888/apis/v2beta1/healthz 2>/dev/null || echo "failed")
        if [[ "$test_result" == *"commit_sha"* ]]; then
            print_ok "API health check passed"
        else
            print_warn "API health check could not be verified"
        fi
    else
        print_error "API server is not ready (ready replicas: $ready)"
        
        # Get logs
        echo "  Recent logs:"
        kubectl logs -n kubeflow -l app=ml-pipeline --tail=5 2>/dev/null | sed 's/^/    /'
    fi
}

check_storage() {
    print_header "Storage (Minio)"
    
    if ! kubectl get deployment minio -n kubeflow &> /dev/null; then
        print_error "Minio deployment not found"
        return 1
    fi
    
    local ready=$(kubectl get deployment minio -n kubeflow -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")
    if [[ "$ready" == "1" ]]; then
        print_ok "Minio is ready"
    else
        print_error "Minio is not ready"
        
        # Check PVC
        local pvc_status=$(kubectl get pvc minio-pvc -n kubeflow -o jsonpath='{.status.phase}' 2>/dev/null)
        if [[ "$pvc_status" != "Bound" ]]; then
            print_warn "Minio PVC status: $pvc_status"
        fi
    fi
}

check_database() {
    print_header "Database (MySQL)"
    
    if ! kubectl get deployment mysql -n kubeflow &> /dev/null; then
        print_error "MySQL deployment not found"
        return 1
    fi
    
    local ready=$(kubectl get deployment mysql -n kubeflow -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")
    if [[ "$ready" == "1" ]]; then
        print_ok "MySQL is ready"
    else
        print_error "MySQL is not ready"
    fi
}

print_summary() {
    print_header "Summary"
    
    if [[ $ISSUES_FOUND -eq 0 ]]; then
        echo -e "${GREEN}All checks passed! Environment is healthy.${NC}"
    else
        echo -e "${YELLOW}Found $ISSUES_FOUND issue(s).${NC}"
        if [[ $ISSUES_FIXED -gt 0 ]]; then
            echo -e "${GREEN}Fixed $ISSUES_FIXED issue(s).${NC}"
        fi
        if [[ $((ISSUES_FOUND - ISSUES_FIXED)) -gt 0 ]] && ! $FIX_MODE; then
            echo ""
            echo "Run with --fix to attempt automatic fixes:"
            echo "  ./scripts/diagnose.sh --fix"
        fi
    fi
    
    echo ""
    echo "For detailed troubleshooting, see: docs/TROUBLESHOOTING.md"
}

# Main
echo "Kubeflow Development Environment Diagnostic Tool"
echo "================================================="
if $FIX_MODE; then
    echo -e "${YELLOW}Running in FIX mode - will attempt to fix issues${NC}"
fi

check_docker
check_k3d
check_kubectl
check_cluster
check_kubeflow_namespace
check_kubeflow_pods
check_storage
check_database
check_api_server

print_summary

exit $([[ $ISSUES_FOUND -eq 0 ]] && echo 0 || echo 1)
