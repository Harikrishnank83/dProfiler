#!/usr/bin/env bash
# Check system resources before/after installation
# Usage: ./check-resources.sh [--detailed]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Source common utilities
if [[ -f "$SCRIPT_DIR/common.sh" ]]; then
    source "$SCRIPT_DIR/common.sh"
fi

DETAILED=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --detailed)
            DETAILED=true
            shift
            ;;
        --help|-h)
            echo "Check system resources"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --detailed    Show detailed resource breakdown"
            echo "  --help        Show this help"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

print_header "System Resource Check"

# Check disk space
print_header "Disk Space" 40
df -h . | tail -1 | awk '{printf "Available: %s of %s (Used: %s, %s)\n", $4, $2, $3, $5}'

if command -v docker &> /dev/null && docker info &> /dev/null 2>&1; then
    echo ""
    echo "Docker System:"
    docker system df 2>/dev/null || echo "Unable to get Docker disk usage"
fi

echo ""

# Check memory
print_header "Memory" 40

if [[ "$(uname)" == "Darwin" ]]; then
    # macOS
    total_mem=$(sysctl -n hw.memsize 2>/dev/null | awk '{print int($1/1024/1024/1024)"GB"}')
    if [[ -n "$total_mem" ]]; then
        echo "Total system memory: $total_mem"
    fi
else
    # Linux
    total_mem=$(free -h | grep Mem | awk '{print $2}')
    available_mem=$(free -h | grep Mem | awk '{print $7}')
    echo "Total memory: $total_mem"
    echo "Available memory: $available_mem"
fi

# Check Docker memory allocation
if docker info &> /dev/null 2>&1; then
    docker_mem=$(docker info --format '{{.MemTotal}}' 2>/dev/null | awk '{print int($1/1024/1024/1024)"GB"}')
    echo "Docker allocated: $docker_mem"
    
    docker_mem_num=$(echo "$docker_mem" | grep -oE '[0-9]+')
    if [[ "$docker_mem_num" -lt 4 ]]; then
        echo -e "${RED}⚠ Warning: Docker memory is less than 4GB${NC}"
    elif [[ "$docker_mem_num" -lt 8 ]]; then
        echo -e "${YELLOW}ℹ Note: 8GB+ recommended for better performance${NC}"
    fi
fi

echo ""

# Check CPU
print_header "CPU" 40
if [[ "$(uname)" == "Darwin" ]]; then
    cores=$(sysctl -n hw.ncpu)
else
    cores=$(nproc)
fi
echo "CPU cores: $cores"

echo ""

# Check Docker images
if docker info &> /dev/null 2>&1; then
    print_header "Docker Images" 40
    
    # Count Kubeflow images
    kfp_count=$(docker images | grep -E "(ml-pipeline|kubeflow)" | wc -l | tr -d ' ')
    echo "Kubeflow images: $kfp_count"
    
    # Count local components
    component_count=$(docker images | grep "localhost:5000" | wc -l | tr -d ' ')
    echo "Local component images: $component_count"
    
    # Total images
    total_images=$(docker images | tail -n +2 | wc -l | tr -d ' ')
    echo "Total images: $total_images"
    
    if $DETAILED; then
        echo ""
        echo "Image breakdown:"
        docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}" | grep -E "(ml-pipeline|kubeflow|localhost:5000|mysql|minio|k3s)" | head -20
    fi
fi

echo ""

# Check running containers
if docker info &> /dev/null 2>&1; then
    print_header "Running Containers" 40
    
    # Count running containers
    running=$(docker ps -q | wc -l | tr -d ' ')
    echo "Running containers: $running"
    
    if $DETAILED && [[ "$running" -gt 0 ]]; then
        echo ""
        docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Size}}"
    fi
fi

echo ""

# Check Kubernetes if available
if command -v kubectl &> /dev/null && kubectl cluster-info &> /dev/null 2>&1; then
    print_header "Kubernetes" 40
    
    # Check pods
    kfp_pods=$(kubectl get pods -n kubeflow 2>/dev/null | tail -n +2 | wc -l | tr -d ' ')
    echo "Kubeflow pods: $kfp_pods"
    
    running_pods=$(kubectl get pods -n kubeflow 2>/dev/null | grep Running | wc -l | tr -d ' ')
    echo "Running pods: $running_pods"
    
    if $DETAILED && [[ "$kfp_pods" -gt 0 ]]; then
        echo ""
        echo "Pod resource usage:"
        kubectl top pods -n kubeflow 2>/dev/null || echo "Metrics server not available"
    fi
fi

echo ""

# Resource requirements summary
print_header "Installation Requirements" 40
echo "Minimum disk space: 10GB free"
echo "Recommended disk space: 20GB+ free"
echo "Minimum Docker memory: 4GB"
echo "Recommended Docker memory: 8GB"
echo ""
echo "Expected downloads:"
echo "  • Minimal install: ~1.6GB"
echo "  • Full install: ~3.5GB"
echo ""
echo "Expected disk usage after install:"
echo "  • Minimal: +2GB"
echo "  • Full: +4.5GB"

echo ""
print_header "Documentation" 40
echo "For detailed information, see:"
echo "  docs/DOCKER_IMAGES_AND_RESOURCES.md"

echo ""
log_success "Resource check complete"
