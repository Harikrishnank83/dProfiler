#!/usr/bin/env bash
# Master Installation Script for Kubeflow Development Environment
# Usage: ./install.sh --mode MODE --k8s VERSION --kfp VERSION

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/scripts/common.sh"

# Default values
MODE="dev"
K8S_VERSION=""
KFP_VERSION=""
MODULES=""
UPGRADE_MODULE=""
ADD_MODULE=""
DRY_RUN=false
SKIP_PREFLIGHT=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --mode)
            MODE="$2"
            shift 2
            ;;
        --k8s)
            K8S_VERSION="$2"
            shift 2
            ;;
        --kfp)
            KFP_VERSION="$2"
            shift 2
            ;;
        --modules)
            MODULES="$2"
            shift 2
            ;;
        --upgrade)
            UPGRADE_MODULE="$2"
            shift 2
            ;;
        --add-module)
            ADD_MODULE="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --skip-preflight)
            SKIP_PREFLIGHT=true
            shift
            ;;
        --help|-h)
            echo "Kubeflow Development Environment Installer"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --dry-run             Run pre-flight checks only without installing"
            echo "  --skip-preflight      Skip pre-flight checks (not recommended)"
            echo "  --mode MODE         Installation mode:"
            echo "                        full    - Everything (cluster, KFP, operators, components, dev tools)"
            echo "                        minimal - Just cluster and KFP"
            echo "                        dev     - Cluster, KFP, and dev tools"
            echo "                        ci      - Optimized for CI environments"
            echo "  --k8s VERSION       Kubernetes version (default: from versions.yaml)"
            echo "  --kfp VERSION       Kubeflow Pipelines version (default: from versions.yaml)"
            echo "  --modules LIST      Comma-separated list of modules to install"
            echo "                        (cluster, kubeflow, dask, ray, components, devtools)"
            echo "  --upgrade MODULE    Upgrade specific module"
            echo "  --add-module MODULE Add a module to existing installation"
            echo "  --help              Show this help"
            echo ""
            echo "Examples:"
            echo "  $0 --mode full --k8s 1.28.5 --kfp 2.1.0"
            echo "  $0 --mode minimal --k8s 1.28.5"
            echo "  $0 --modules cluster,kubeflow,dask --k8s 1.28.5"
            echo "  $0 --upgrade kubeflow --kfp 2.2.0"
            echo "  $0 --add-module ray"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Get default versions if not specified
if [[ -z "$K8S_VERSION" ]]; then
    K8S_VERSION=$("$SCRIPT_DIR/scripts/version-manager.sh" default-k8s 2>/dev/null || echo "1.28.5")
fi

if [[ -z "$KFP_VERSION" ]]; then
    KFP_VERSION=$("$SCRIPT_DIR/scripts/version-manager.sh" default-kfp 2>/dev/null || echo "2.1.0")
fi

# Handle upgrade
if [[ -n "$UPGRADE_MODULE" ]]; then
    log_info "Upgrading module: $UPGRADE_MODULE"
    case "$UPGRADE_MODULE" in
        kubeflow)
            "$SCRIPT_DIR/scripts/cluster-upgrade.sh" --kfp "$KFP_VERSION"
            ;;
        *)
            log_error "Unknown module: $UPGRADE_MODULE"
            exit 1
            ;;
    esac
    exit 0
fi

# Handle add module
if [[ -n "$ADD_MODULE" ]]; then
    log_info "Adding module: $ADD_MODULE"
    case "$ADD_MODULE" in
        dask)
            "$SCRIPT_DIR/scripts/install-operators.sh" --dask
            ;;
        ray)
            "$SCRIPT_DIR/scripts/install-operators.sh" --ray
            ;;
        components)
            "$SCRIPT_DIR/build/build-all.sh"
            ;;
        *)
            log_error "Unknown module: $ADD_MODULE"
            exit 1
            ;;
    esac
    exit 0
fi

print_header "Kubeflow Development Environment Installation"
echo ""
print_kv "Mode" "$MODE"
print_kv "K8s Version" "$K8S_VERSION"
print_kv "KFP Version" "$KFP_VERSION"
if [[ -n "$MODULES" ]]; then
    print_kv "Modules" "$MODULES"
fi
echo ""

# Determine modules to install based on mode
if [[ -z "$MODULES" ]]; then
    case "$MODE" in
        full)
            MODULES="deps,cluster,kubeflow,dask,ray,components,devtools"
            ;;
        minimal)
            MODULES="deps,cluster,kubeflow"
            ;;
        dev)
            MODULES="deps,cluster,kubeflow,devtools"
            ;;
        ci)
            MODULES="deps,cluster,kubeflow"
            ;;
        *)
            log_error "Unknown mode: $MODE"
            exit 1
            ;;
    esac
fi

# Convert modules to array
IFS=',' read -ra MODULE_ARRAY <<< "$MODULES"

# Installation functions
install_deps() {
    log_step "Installing dependencies..."
    "$SCRIPT_DIR/install/install-deps.sh"
}

install_cluster() {
    log_step "Creating Kubernetes cluster..."
    "$SCRIPT_DIR/scripts/cluster-create.sh" \
        --k8s "$K8S_VERSION" \
        --kfp "$KFP_VERSION" \
        --skip-kfp
}

install_kubeflow() {
    log_step "Installing Kubeflow Pipelines..."
    "$SCRIPT_DIR/scripts/install-kubeflow.sh" --version "$KFP_VERSION"
}

install_dask() {
    log_step "Installing Dask operator..."
    "$SCRIPT_DIR/scripts/install-operators.sh" --dask
}

install_ray() {
    log_step "Installing Ray operator..."
    "$SCRIPT_DIR/scripts/install-operators.sh" --ray
}

install_components() {
    log_step "Building ML components..."
    "$SCRIPT_DIR/build/build-all.sh" --tag latest
}

install_devtools() {
    log_step "Setting up development tools..."
    "$SCRIPT_DIR/install/install-dev-tools.sh"
}

# Run pre-flight checks
if ! $SKIP_PREFLIGHT; then
    log_info "Running pre-flight checks..."
    echo ""
    
    if $DRY_RUN; then
        "$SCRIPT_DIR/scripts/preflight-check.sh"
        exit $?
    else
        "$SCRIPT_DIR/scripts/preflight-check.sh"
        PREFLIGHT_EXIT=$?
        
        if [ $PREFLIGHT_EXIT -eq 2 ] || [ $PREFLIGHT_EXIT -eq 1 ]; then
            echo ""
            log_error "Critical issues found. Installation cannot proceed."
            echo "Run with --skip-preflight to bypass (not recommended)"
            exit 1
        elif [ $PREFLIGHT_EXIT -eq 3 ]; then
            log_warn "Warnings found, proceeding with installation..."
            sleep 2
        fi
    fi
    echo ""
fi

log_info "Starting Kubeflow Development Environment Installation"
log_info "Installation mode: $MODE"
echo ""

# Run installations
for module in "${MODULE_ARRAY[@]}"; do
    case "$module" in
        deps)
            install_deps
            ;;
        cluster)
            install_cluster
            ;;
        kubeflow)
            install_kubeflow
            ;;
        dask)
            install_dask
            ;;
        ray)
            install_ray
            ;;
        components)
            install_components
            ;;
        devtools)
            install_devtools
            ;;
        *)
            log_warning "Unknown module: $module (skipping)"
            ;;
    esac
done

# Verify installation
log_step "Verifying installation..."
"$SCRIPT_DIR/install/verify-installation.sh" || log_warning "Some verification checks failed"

# Print summary
print_header "Installation Complete"
echo ""
echo "Installed modules: $MODULES"
echo ""
echo "Next steps:"
echo "  1. Access KFP UI: make port-forward"
echo "  2. Open http://localhost:8080"
echo "  3. Deploy a pipeline: make deploy-pipeline PIPELINE=gbm-training"
echo ""
log_success "Installation completed successfully!"
