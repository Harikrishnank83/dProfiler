# Kubeflow Development Environment

**Production-grade local Kubeflow Pipelines setup for rapid ML development**

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)
[![Kubernetes](https://img.shields.io/badge/k8s-1.28%20%7C%201.29-blue)](https://kubernetes.io/)
[![Kubeflow](https://img.shields.io/badge/kubeflow-2.0%20%7C%202.1%20%7C%202.2-orange)](https://kubeflow.org/)

---

## 🎯 What is This?

A **developer-friendly, intelligent installation wizard** for Kubeflow Pipelines on local Kubernetes (k3d). Get ML pipelines running in **5-10 minutes** instead of hours of manual configuration.

### ✨ Key Features

- 🧙 **Intelligent Wizard** - Detects installed tools, skips unnecessary steps
- 📊 **Resource Transparency** - Shows disk/memory usage before installation
- 🎨 **Custom Images** - Full support for custom Docker images & registries
- 🔄 **Version Management** - Switch Kubernetes and Kubeflow versions easily
- 🚫 **UI Optional** - API-only mode for headless operation
- ❓ **Context-aware Help** - Type `help` at any prompt
- 🛠️ **Developer Tools** - Pre-configured for ML development

---

## 🚀 Quick Start

### 1. Check Resources (Optional but Recommended)

```bash
./scripts/check-resources.sh
```

**Requirements:**
- **Disk:** 10GB+ free (20GB+ recommended)
- **Memory:** 4GB+ Docker allocation (8GB+ recommended)
- **Downloads:** ~1.6GB (minimal) or ~3.5GB (full)

📊 **Detailed info:** [docs/DOCKER_IMAGES_AND_RESOURCES.md](docs/DOCKER_IMAGES_AND_RESOURCES.md)

### 2. Run the Intelligent Wizard

```bash
# Start Docker if not running
open -a Docker  # macOS
# or: systemctl start docker  # Linux

# Run the wizard (shows resource info automatically)
./install-wizard.sh
```

**Wizard features:**
- ✅ Detects installed tools (Docker, k3d, kubectl, etc.)
- ✅ Shows resource requirements and current system status
- ✅ Guides you through installation with clear steps
- ✅ Type `help` for context-specific assistance
- ✅ Type `exit` to quit gracefully anytime

### 3. Verify Installation

```bash
# Check cluster
kubectl get pods -n kubeflow

# Access UI (if installed)
./scripts/port-forward.sh
# Opens: http://localhost:8080

# Or use API-only mode
python pipelines/gbm-training-pipeline.py --run
```

---

## 📖 Documentation

### 🎓 Getting Started

| Guide | Description | Time |
|-------|-------------|------|
| **[START_HERE.md](START_HERE.md)** | 4-step quick start | 5-10 min |
| **[WIZARD_QUICKSTART.md](WIZARD_QUICKSTART.md)** | Wizard guide with examples | 5 min |
| **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** | One-page cheat sheet | Reference |

### 📊 Resource & Images

| Guide | Description |
|-------|-------------|
| **[docs/DOCKER_IMAGES_AND_RESOURCES.md](docs/DOCKER_IMAGES_AND_RESOURCES.md)** ⭐ | Complete guide to images, sizes, custom images, impact analysis |
| **[scripts/check-resources.sh](scripts/check-resources.sh)** | Check disk/memory before installation |

### 🏢 Enterprise & Container Runtimes

| Guide | Description |
|-------|-------------|
| **[docs/CONTAINER_RUNTIMES.md](docs/CONTAINER_RUNTIMES.md)** ⭐ **NEW** | Docker Desktop alternatives (Colima, Podman, Rancher) - Save $18K+/year! |
| **[docs/COLIMA_VS_DOCKER_DESKTOP.md](docs/COLIMA_VS_DOCKER_DESKTOP.md)** | Detailed Colima comparison |
| **[MULTI_RUNTIME_SUPPORT.md](MULTI_RUNTIME_SUPPORT.md)** | Implementation guide & migration |

### 🛠️ Advanced Topics

| Guide | Description |
|-------|-------------|
| **[docs/KFP_WITHOUT_UI.md](docs/KFP_WITHOUT_UI.md)** | Build & run pipelines without UI |
| **[docs/MONITORING_AND_DEBUGGING.md](docs/MONITORING_AND_DEBUGGING.md)** | Debug pipelines with SDK, kubectl, Argo |
| **[docs/UNIFIED_GBM_ARCHITECTURE.md](docs/UNIFIED_GBM_ARCHITECTURE.md)** | Unified ML framework architecture |
| **[docs/USER_GUIDE.md](docs/USER_GUIDE.md)** | Complete user guide |

### 📚 Complete Index

See **[INDEX.md](INDEX.md)** for the complete documentation structure.

---

## 💡 Installation Modes

The wizard offers **4 installation modes**:

### 1. Express (Recommended for First-Time Users)
- Full Kubeflow Pipelines with UI
- Sample components
- Development tools
- **Time:** 5-10 minutes

### 2. Minimal (Core Only)
- Kubeflow Pipelines with UI
- No additional components
- **Time:** 3-5 minutes

### 3. Custom (Advanced Users)
- Choose specific modules
- Type `help` to see available modules
- Full customization

### 4. API-Only (Headless)
- Kubeflow Pipelines backend only
- No UI (saves resources)
- Perfect for CI/CD, scripting
- **Time:** 3-5 minutes

---

## 🎨 Custom Images Support

**Question:** Can I use custom Docker images?  
**Answer:** ✅ **YES! Fully supported!**

### What You Can Customize

| Level | Support | Impact on KFP |
|-------|---------|---------------|
| **Component base images** | ✅ Full | ✅ None |
| **Custom registries** | ✅ Full | ✅ None |
| **Different images per component** | ✅ Full | ✅ None |
| **KFP platform images** | ✅ Advanced | ⚠️ Must match version |
| **Infrastructure (MySQL, MinIO)** | ✅ Full | ⚠️ Test thoroughly |

### Examples

**Change component base:**
```dockerfile
# components/Dockerfile.base
FROM your-registry.com/python:3.10-hardened
```

**Use custom registry:**
```bash
./build/build-all.sh --registry your-registry.com/ml
```

**GPU images for training:**
```dockerfile
# components/gbm-trainer/Dockerfile
FROM nvidia/cuda:11.8-cudnn8-runtime-ubuntu22.04
```

**Impact:** ✅ **No impact on Kubeflow platform!**

📖 **Complete guide:** [docs/DOCKER_IMAGES_AND_RESOURCES.md](docs/DOCKER_IMAGES_AND_RESOURCES.md)

---

## 📊 Resource Usage

### What Will Be Downloaded

| Component | Size |
|-----------|------|
| Kubeflow Pipelines images | ~660MB |
| Supporting services (MySQL, MinIO, k3s) | ~940MB |
| **Total (Minimal)** | **~1.6GB** |
| ML components (optional) | +1.92GB |
| **Total (Full)** | **~3.5GB** |

### Disk Space

| Configuration | After Install |
|---------------|---------------|
| Minimal | +2GB |
| Full | +4.5GB |

### Memory Usage

| State | Usage |
|-------|-------|
| Idle (no pipelines) | ~960MB |
| Running pipeline | +1-2GB |

**Check your system:**
```bash
./scripts/check-resources.sh --detailed
```

---

## 🌟 Features

### Intelligent Detection
- ✅ Detects Docker, k3d, kubectl, Helm, Python
- ✅ Shows what's installed, what's missing
- ✅ Skips unnecessary installation steps
- ✅ Shows resource requirements upfront

### Version Management
```bash
# List available versions
./scripts/list-versions.sh

# Switch versions
./scripts/version-manager.sh --k8s 1.29 --kubeflow 2.2.0
```

### Interactive Help
```bash
# In wizard
> help           # Context-specific help
> exit           # Graceful exit (no Ctrl+C needed)
```

### UI Optional
```bash
# Install with UI (default)
./install-wizard.sh
# Choose: Express, Minimal, or Custom

# Install without UI
./install-wizard.sh
# Choose: API-Only mode

# Build pipelines without UI
python pipelines/gbm-training-pipeline.py --compile
python pipelines/gbm-training-pipeline.py --run
```

### Custom Images
- ✅ Component base images
- ✅ Private registries
- ✅ GPU images
- ✅ Air-gapped deployments

---

## 🧪 Example Pipeline

```python
from kfp import dsl

@dsl.component
def train_model(dataset: str, model_type: str):
    # Your training logic
    pass

@dsl.pipeline(name="My Pipeline")
def my_pipeline(dataset: str = "iris"):
    train_task = train_model(dataset=dataset, model_type="xgboost")

# Compile
from kfp import compiler
compiler.Compiler().compile(my_pipeline, 'pipeline.yaml')

# Run (with or without UI!)
import kfp
client = kfp.Client(host='http://localhost:8080')
run = client.create_run_from_pipeline_func(my_pipeline)
print(f"Run: {run.run_id}")
```

---

## 🛠️ Common Commands

```bash
# Resource check
./scripts/check-resources.sh

# Install
./install-wizard.sh

# Port forward (access UI)
./scripts/port-forward.sh

# List clusters
./scripts/cluster-list.sh

# Diagnose issues
./scripts/diagnose.sh

# Build components
make build-all

# Run pipeline
python pipelines/gbm-training-pipeline.py --run
```

---

## 📖 Help & Documentation

### Quick Help
```bash
# Wizard help
./install-wizard.sh
# Type 'help' at any prompt

# Script help
./scripts/check-resources.sh --help
./build/build-component.sh --help
```

### Documentation

- **[START_HERE.md](START_HERE.md)** - Begin here
- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - Cheat sheet
- **[docs/DOCKER_IMAGES_AND_RESOURCES.md](docs/DOCKER_IMAGES_AND_RESOURCES.md)** - Images & resources
- **[docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)** - Fix common issues
- **[docs/FAQ.md](docs/FAQ.md)** - Frequently asked questions
- **[INDEX.md](INDEX.md)** - Complete index

---

## 🎯 Architecture

```
┌─────────────────────────────────────────────────┐
│         Kubeflow Development Environment         │
├─────────────────────────────────────────────────┤
│                                                  │
│  ┌──────────────┐    ┌──────────────┐          │
│  │    ML User    │───▶│    Wizard    │          │
│  └──────────────┘    └──────┬───────┘          │
│                             │                    │
│         ┌───────────────────┼──────────┐        │
│         ▼                   ▼          ▼        │
│  ┌──────────┐   ┌──────────────┐  ┌─────┐     │
│  │ Resource │   │  Kubeflow    │  │ K3d │     │
│  │  Check   │   │  Pipelines   │  │(K8s)│     │
│  └──────────┘   └──────┬───────┘  └──┬──┘     │
│                        │              │         │
│         ┌──────────────┼──────────────┘         │
│         ▼              ▼                         │
│  ┌──────────┐   ┌──────────┐                   │
│  │   ML     │   │ Artifact │                    │
│  │Components│   │ Storage  │                    │
│  └──────────┘   └──────────┘                   │
│                                                  │
└─────────────────────────────────────────────────┘
```

---

## 🤝 Contributing

See **[CONTRIBUTING.md](CONTRIBUTING.md)** for development setup and guidelines.

---

## 📝 License

Apache 2.0 License - see [LICENSE](LICENSE)

---

## 🙏 Credits

Built on top of:
- [Kubeflow Pipelines](https://www.kubeflow.org/docs/components/pipelines/)
- [k3d](https://k3d.io/) - k3s in Docker
- [Kubernetes](https://kubernetes.io/)

---

## ⭐ Quick Links

- **New here?** → [START_HERE.md](START_HERE.md)
- **Check resources** → `./scripts/check-resources.sh`
- **Install** → `./install-wizard.sh`
- **Custom images?** → [docs/DOCKER_IMAGES_AND_RESOURCES.md](docs/DOCKER_IMAGES_AND_RESOURCES.md)
- **No UI?** → [docs/KFP_WITHOUT_UI.md](docs/KFP_WITHOUT_UI.md)
- **Need help?** → [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)
- **All docs** → [INDEX.md](INDEX.md)

---

**Get started in 5-10 minutes!**

```bash
./scripts/check-resources.sh  # Check your system
./install-wizard.sh           # Install everything
```
