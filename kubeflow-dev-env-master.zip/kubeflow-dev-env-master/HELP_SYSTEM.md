# Wizard Help System Guide

**Interactive Help at Every Step**

---

## Overview

The Kubeflow installation wizard now includes a comprehensive context-sensitive help system. Get detailed information about options, modules, and configurations without leaving the wizard!

---

## How to Get Help

### At Any Prompt

Type any of these commands:
- `help` - Show context-specific help
- `?` - Same as help
- `h` - Quick help alias

### To Exit

Type any of these commands instead of Ctrl+C:
- `exit` - Quit the wizard
- `quit` - Same as exit
- `q` - Quick exit alias

---

## Available Help Sections

### 1. General Help

**When:** Type `help` at any prompt

**Shows:**
- Available commands
- Navigation tips
- How to use defaults
- Exit instructions

**Example:**
```
Enter your choice (1-5) (type 'help' or 'exit'): help

━━━ Help ━━━

Available commands:
  help or ?  - Show this help
  exit or q  - Quit the wizard

Navigation:
  • Press Enter to use default values [shown in brackets]
  • Type your choice and press Enter
  • Type 'help' for context-specific help
```

---

### 2. Installation Mode Help

**When:** At mode selection (Step 2)

**Trigger:** Type `help` when choosing installation mode

**Shows:**
- Detailed description of each mode
- What each mode installs
- Time estimates
- Best use cases

**Example:**
```
Enter your choice (1-5) (type 'help' or 'exit'): help

━━━ Installation Modes Help ━━━

1) Full Mode
   Installs: Cluster + KFP + Dask + Ray + Components + Dev Tools
   Time: ~15-20 minutes
   Best for: First-time users, complete environment

2) Dev Mode ← Recommended
   Installs: Cluster + KFP + Dev Tools (includes KFP SDK)
   Time: ~5-10 minutes
   Best for: Developers, most common use case

3) Minimal Mode
   Installs: Cluster + KFP only
   Time: ~5 minutes
   Best for: Quick testing, minimal footprint

4) API-Only Mode
   Installs: Cluster + KFP backend + Dev Tools (no UI emphasis)
   Time: ~5-10 minutes
   Best for: Automated workflows, CI/CD, programmatic use
   Note: Use KFP SDK instead of web UI

5) Custom Mode
   Installs: Your choice of modules
   Time: Varies
   Best for: Advanced users with specific needs
```

---

### 3. Custom Modules Help

**When:** In custom mode, when selecting modules

**Trigger:** Type `help` when prompted for modules

**Shows:**
- All available modules
- What each module does
- Which are required vs optional
- Example combinations

**Example:**
```
Enter comma-separated list of modules [deps,cluster,kubeflow] (type 'help' or 'exit'): help

━━━ Available Modules Help ━━━

Available modules:

  deps       - Install dependencies (k3d, kubectl, Helm, yq)
             Required for: fresh systems

  cluster    - Create Kubernetes cluster (k3d)
             Required for: running Kubeflow

  kubeflow   - Install Kubeflow Pipelines (API + UI)
             Required for: ML pipelines

  dask       - Install Dask operator
             Optional: for distributed computing

  ray        - Install Ray operator
             Optional: for distributed ML

  components - Build ML pipeline components
             Optional: pre-built examples

  devtools   - Install development tools (Python packages, KFP SDK)
             Recommended for: development work

Example combinations:
  • Minimal: deps,cluster,kubeflow
  • Dev: deps,cluster,kubeflow,devtools
  • Full: deps,cluster,kubeflow,dask,ray,components,devtools

Tip: Your system already has some dependencies installed.
     You can skip 'deps' if you already have Docker, k3d, kubectl, etc.
```

---

### 4. Version Compatibility Help

**When:** At version selection (Step 3)

**Trigger:** Type `help` when choosing K8s or KFP version

**Shows:**
- Version compatibility matrix
- Recommended combinations
- Version format explanation

**Example:**
```
Kubernetes version [1.28.5] (type 'help' or 'exit'): help

━━━ Version Compatibility Help ━━━

Kubernetes and Kubeflow Pipelines version compatibility:

  K8s Version │ KFP 2.0.5 │ KFP 2.1.0 │ KFP 2.2.0
  ────────────┼───────────┼───────────┼──────────
  1.26        │     ✅    │     ✅    │    ❌
  1.27        │     ✅    │     ✅    │    ✅
  1.28        │     ✅    │     ✅    │    ✅     ← Recommended
  1.29        │     ❌    │     ✅    │    ✅

Recommendations:
  • K8s 1.28.5 + KFP 2.1.0 (best compatibility)
  • K8s 1.29 for latest features (KFP 2.1.0+ only)

Version format:
  • K8s: Major.Minor.Patch (e.g., 1.28.5)
  • KFP: Major.Minor.Patch (e.g., 2.1.0)
```

---

### 5. UI Selection Help

**When:** Deciding whether to include Kubeflow UI

**Trigger:** Type `help` when asked "Include Kubeflow UI?"

**Shows:**
- What the UI provides
- When you need it
- When you don't need it
- Alternative methods

**Example:**
```
Include Kubeflow UI? [Y/n] (type 'help' or 'exit'): help

━━━ Kubeflow UI Help ━━━

What is the Kubeflow UI?
  • Web interface at http://localhost:8080
  • Visual pipeline editor and dashboard
  • Run monitoring and artifact viewing

Do you need the UI?

  YES - Include UI if you want to:
    • Use visual pipeline editor
    • View runs in a dashboard
    • Explore pipelines interactively
    • Learn Kubeflow concepts visually

  NO - Skip UI emphasis if you want to:
    • Use KFP SDK (Python) exclusively
    • Automate deployments (CI/CD)
    • Work programmatically
    • Use kubectl/Argo CLI for monitoring

Note: Even without UI, you get full KFP functionality via SDK!
See: docs/KFP_WITHOUT_UI.md for complete guide
```

---

### 6. Confirmation Help

**When:** Final confirmation before installation

**Trigger:** Type `help` when asked to proceed

**Shows:**
- What will happen
- Options available
- Time estimates
- Notes about installation

**Example:**
```
Proceed with installation? [Y/n] (type 'help' or 'exit'): help

━━━ Installation Confirmation Help ━━━

This is your last chance to review before installation begins.

What will happen:
  • Selected modules will be installed
  • Kubernetes cluster will be created (if selected)
  • Kubeflow Pipelines will be deployed (if selected)
  • Development tools will be set up (if selected)

Options:
  • Type 'y' or 'yes' to proceed with installation
  • Type 'n' or 'no' to cancel and exit
  • Type 'help' to see this message again
  • Type 'exit' to quit

Installation time:
  • Approximately 5-10 minutes

Note: Installation time may be faster if dependencies are already installed.
```

---

## Exit Commands

### Graceful Exit

Instead of Ctrl+C, use these commands to exit cleanly:

```bash
# At any prompt, type:
exit    # Exit the wizard
quit    # Same as exit
q       # Quick exit

# Result:
Installation cancelled. Exiting...
```

### Why Use Exit Commands?

**Benefits:**
- ✅ Clean shutdown
- ✅ No error messages
- ✅ Clearer user intention
- ✅ Better for automation/scripts

**Still available:**
- Ctrl+C during long operations (like waiting for Docker)
- Used as emergency stop

---

## Complete Workflow Example

```bash
./install-wizard.sh

# Wizard starts
🚀 Kubeflow Development Environment Setup Wizard 🚀

💡 Type 'help' at any prompt for assistance
🚪 Type 'exit' to quit at any time

# Step 2: Mode selection
Choose what you want to install:
  1) Full
  2) Dev
  3) Minimal
  4) API-Only
  5) Custom

Enter your choice (1-5) (type 'help' or 'exit'): help

# Shows detailed mode descriptions
[Help text appears]

Enter your choice (1-5) (type 'help' or 'exit'): 5

# Custom mode selected
Available modules: deps, cluster, kubeflow, dask, ray, components, devtools
Type 'help' to see module descriptions

Enter comma-separated list of modules [deps,cluster,kubeflow] (type 'help' or 'exit'): help

# Shows module help
[Module descriptions appear]

Enter comma-separated list of modules [deps,cluster,kubeflow] (type 'help' or 'exit'): cluster,kubeflow,devtools

Include Kubeflow UI? [Y/n] (type 'help' or 'exit'): help

# Shows UI help
[UI information appears]

Include Kubeflow UI? [Y/n] (type 'help' or 'exit'): n

# Continue with installation...
```

---

## Help System Features

### Context-Sensitive

Help is tailored to your current step:
- Mode selection → Mode descriptions
- Module selection → Module details
- Version selection → Compatibility info
- Confirmation → What will happen

### Non-Intrusive

- Help is available but not forced
- Subtle hints: "Type 'help' for details"
- Doesn't clutter the main interface

### Always Available

Every interactive prompt supports:
- `help` - Get detailed help
- `exit` - Quit gracefully
- `?` - Quick help
- `q` - Quick exit

---

## Tips and Tricks

### 1. Explore Before Deciding

```bash
# Don't know what mode to choose?
Enter your choice (1-5): help
# Read all mode descriptions
Enter your choice (1-5): 2  # Now decide
```

### 2. Learn Module Options

```bash
# Not sure which modules to include?
Enter modules: help
# See complete module list with descriptions
Enter modules: cluster,kubeflow,devtools
```

### 3. Check Compatibility

```bash
# Want to use latest version?
K8s version [1.28.5]: help
# See compatibility matrix
K8s version [1.28.5]: 1.29
KFP version [2.1.0]: help
# Verify it works
KFP version [2.1.0]: 2.1.0
```

### 4. Exit Cleanly

```bash
# Changed your mind?
Enter your choice: exit
# Clean exit, no errors
```

---

## Keyboard Shortcuts Summary

| Command | Action | Available |
|---------|--------|-----------|
| `help` | Show help | All prompts |
| `?` | Quick help | All prompts |
| `h` | Help alias | All prompts |
| `exit` | Quit wizard | All prompts |
| `quit` | Same as exit | All prompts |
| `q` | Quick exit | All prompts |
| `Enter` | Use default | When default shown |
| `Ctrl+C` | Emergency stop | During operations |

---

## Enhanced Banner

The wizard now shows helpful reminders:

```
╔═══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║     🚀 Kubeflow Development Environment Setup Wizard 🚀              ║
║                                                                       ║
║     Intelligent installation that adapts to your system               ║
║                                                                       ║
║     💡 Type 'help' at any prompt for assistance                      ║
║     🚪 Type 'exit' to quit at any time                               ║
║                                                                       ║
╚═══════════════════════════════════════════════════════════════════════╝
```

---

## Benefits

### For New Users
- ✅ Learn as you go
- ✅ Understand options before choosing
- ✅ No need to read docs first
- ✅ Guided decision making

### For Experienced Users
- ✅ Quick reference without leaving wizard
- ✅ Verify compatibility on the fly
- ✅ Customize with confidence
- ✅ Faster than checking docs

### For Everyone
- ✅ Clean exit option
- ✅ Context-aware help
- ✅ No interrupting the flow
- ✅ Better user experience

---

## Comparison

### Before (without help system):

```
Enter your choice (1-5): 5
Enter modules: ???
# User has to exit, read docs, come back
```

### After (with help system):

```
Enter your choice (1-5): help
# [Shows detailed descriptions]
Enter your choice (1-5): 5

Enter modules: help
# [Shows module list with details]
Enter modules: cluster,kubeflow,devtools
```

---

## Advanced Usage

### Automation-Friendly

Help doesn't interfere with non-interactive mode:

```bash
# Still works without interaction
./install-wizard.sh --non-interactive

# Still works with dry-run
./install-wizard.sh --dry-run
```

### Script Integration

```bash
# Can be used in scripts
echo -e "5\nhelp\ncluster,kubeflow\nn\ny" | ./install-wizard.sh
```

---

## Related Documentation

- **Quick Start:** `START_HERE.md`
- **Complete Guide:** `WIZARD_QUICKSTART.md`
- **API Workflow:** `docs/KFP_WITHOUT_UI.md`
- **All Docs:** `INDEX.md`

---

## Summary

The wizard help system provides:

✅ **Context-sensitive help** at every step  
✅ **Detailed module descriptions** for custom mode  
✅ **Version compatibility information** for safe choices  
✅ **Clean exit commands** instead of Ctrl+C  
✅ **Non-intrusive design** with subtle hints  
✅ **Always available** with `help` or `?`  

**You never need to leave the wizard to get information!** 💡

---

**Start the wizard and try typing `help` at any prompt!**

```bash
./install-wizard.sh
```
